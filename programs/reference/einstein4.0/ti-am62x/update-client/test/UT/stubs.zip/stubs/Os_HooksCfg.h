/******************************************************************************
**              CONFIDENTIAL VISTEON CORPORATION
**
** This is an unpublished work of authorship, which contains trade secrets,
** created in 2012. Visteon Corporation owns all rights to this work and
** intends to maintain it in confidence to preserve its trade secret status.
** Visteon Corporation reserves the right, under the copyright laws of the
** United States or those of any other country that may have  jurisdiction,
** to protect this work as an unpublished work, in the event of an
** inadvertent or deliberate unauthorized publication. Visteon Corporation
** also reserves its rights under all copyright laws to protect this work as
** a published work, when appropriate. Those having access to this work may
** not copy it, use it, modify it or disclose the information contained in
** it without the written authorization of Visteon Corporation
**
******************************************************************************/

/******************************************************************************

File Name        :  Os_HooksCfg.h
Module Short Name:  Os_HooksCfg.h
VOBName          :  
Author           :  
Description      :  Generated File
Organization     :  Driver Information Software Section,
                    Visteon Corporation

******************************************************************************/

#ifndef OS_HOOKSCFG_H
#define OS_HOOKSCFG_H


/*****************************************************************************
*                            Include files                                   *
*****************************************************************************/
                                                                              
#include "Stubs.h"
                                                                              
                                                                              
/*****************************************************************************
*                                 Macro Definitions                          *
*----------------------------------------------------------------------------*
* Definition of macro shall be followed by a comment that explains the       *
* purpose of the macro.                                                      *
*****************************************************************************/


#define OsCfgStartUpHook()       
#define OsCfgShutdownHook()       EcuM_Shutdown()
#define OsCfgPreTaskHook()       PreTaskHook()
#define OsCfgPostTaskHook()       PostTaskHook()
#define OsCfgPreISRHook(x)       UserPreISRHook(x)
#define OsCfgPostISRHook(x)       UserPostISRHook(x)
#define OsCfgErrorHook(x)       
#define OsCfgProtectionHook(x)       PRO_SHUTDOWN
#define OsCfgCriticalSectionStartHook()       
#define OsCfgCriticalSectionStoptHook()       
#define OsCfgCheckSelfTest()       SELF_TEST_ACTIVE

#endif    /* */
/* end of file */
/****************************************************************
Created Time: 3/4/2024 1:30:21 PM
****************************************************************/
