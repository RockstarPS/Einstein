/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *          File:  Rte_Type.h
 *        Config:  Traveo2.dpa
 *   ECU-Project:  Kombi
 *
 *     Generator:  MICROSAR RTE Generator Version 4.19.0
 *                 RTE Core Version 1.19.0
 *       License:  CBD1800851
 *
 *   Description:  Header file containing user defined AUTOSAR types and RTE structures
 *********************************************************************************************************************/

/* double include prevention */
#ifndef _RTE_TYPE_H
#define _RTE_TYPE_H

#include "Rte.h"
#include "Std_Types.h"
#include "Platform_Types.h"
/**********************************************************************************************************************
 * Data type definitions
 *********************************************************************************************************************/

# define Rte_TypeDef_t_uint8_x_256
typedef uint8 t_uint8_x_256[256];

# define Rte_TypeDef_UInt8
typedef uint8 UInt8;

# define Rte_TypeDef_UInt16
typedef uint16 UInt16;

# define Rte_TypeDef_Boolean
typedef boolean Boolean;

# define Rte_TypeDef_ComMExt_IpduGroupId
typedef uint8 ComMExt_IpduGroupId;

# define Rte_TypeDef_dtRef_VOID
typedef void * dtRef_VOID;

# define Rte_TypeDef_dtRef_const_VOID
typedef const void * dtRef_const_VOID;

# define Rte_TypeDef_teDIDOperation
typedef uint8 teDIDOperation;

# define Rte_TypeDef_teDTCOperation
typedef uint8 teDTCOperation;

# define Rte_TypeDef_teDiagFilterBypassMode
typedef uint8 teDiagFilterBypassMode;

# define Rte_TypeDef_teDiagOpStatus
typedef uint8 teDiagOpStatus;

# define Rte_TypeDef_teRoutineOperation
typedef uint8 teRoutineOperation;

# define Rte_TypeDef_DIDOperation
typedef uint8 DIDOperation;

# define Rte_TypeDef_RIDOperation
typedef uint8 RIDOperation;

# define Rte_TypeDef_DiagWriteDIDT
typedef uint32 DiagWriteDIDT;

# define Rte_TypeDef_Dcm_MsgType
typedef uint8 *Dcm_MsgType;

# define Rte_TypeDef_Csm_ResultType
typedef uint8 Csm_ResultType;

# define Rte_TypeDef_Dcm_SesCtrlType
typedef uint8 Dcm_SesCtrlType;

# define Rte_TypeDef_Dem_DTCFormatType
typedef uint8 Dem_DTCFormatType;

# define Rte_TypeDef_Dem_DTCKindType
typedef uint8 Dem_DTCKindType;

# define Rte_TypeDef_Dem_DTCOriginType
typedef uint8 Dem_DTCOriginType;

# define Rte_TypeDef_Dem_DTCSeverityType
typedef uint8 Dem_DTCSeverityType;

# define Rte_TypeDef_Dem_UdsStatusByteType
typedef uint8 Dem_UdsStatusByteType;

# define Rte_TypeDef_WdgM_CheckpointIdType
typedef uint16 WdgM_CheckpointIdType;

# define Rte_TypeDef_WdgM_SupervisedEntityIdType
typedef uint16 WdgM_SupervisedEntityIdType;

# define Rte_TypeDef_NvM_BlockIdType
typedef uint16 NvM_BlockIdType;

# define Rte_TypeDef_NvM_RequestResultType
typedef uint8 NvM_RequestResultType;
# define Rte_TypeDef_Dcm_NegativeResponseCodeType
typedef uint8 Dcm_NegativeResponseCodeType;

# define Rte_TypeDef_Dcm_OpStatusType
typedef uint8 Dcm_OpStatusType;

# define Rte_TypeDef_Dcm_CommunicationModeType
typedef uint8 Dcm_CommunicationModeType;

# define Rte_TypeDef_Dcm_ConfirmationStatusType
typedef uint8 Dcm_ConfirmationStatusType;

# define Rte_TypeDef_ECmpCmd
typedef uint8 ECmpCmd;
# define Rte_TypeDef_Dcm_ProtocolType
typedef uint8 Dcm_ProtocolType;

# define Rte_TypeDef_Dcm_RequestKindType
typedef uint8 Dcm_RequestKindType;

#  define Rte_TypeDef_Dcm_Data12ByteType
typedef uint8 Dcm_Data12ByteType[12];

#  define Rte_TypeDef_Dcm_Data16ByteType
typedef uint8 Dcm_Data16ByteType[16];

#  define Rte_TypeDef_Dcm_SecLevelType
typedef uint8 Dcm_SecLevelType;

# define Rte_TypeDef_Csm_ReturnType
typedef enum
{
   CSM_E_OK,
   CSM_E_NOT_OK,
   CSM_E_BUSY,
   CSM_E_SMALL_BUFFER,
   CSM_E_ENTROPY_EXHAUSTION
} Csm_ReturnType;

# define Rte_TypeDef_HTimer
typedef uint8 HTimer;

# define Rte_TypeDef_NvM_ServiceIdType
typedef uint8 NvM_ServiceIdType;

# define Rte_TypeDef_Rte_DT_Arr_u8_4_0
typedef uint8 Rte_DT_Arr_u8_4_0;

# define Rte_TypeDef_Arr_u8_4
typedef Rte_DT_Arr_u8_4_0 Arr_u8_4[4];

# define Rte_TypeDef_Rte_DT_Arr_u8_16_0
typedef uint8 Rte_DT_Arr_u8_16_0;

# define Rte_TypeDef_Arr_u8_16
typedef Rte_DT_Arr_u8_16_0 Arr_u8_16[16];

# define Rte_TypeDef_Rte_DT_Arr_u8_64_0
typedef uint8 Rte_DT_Arr_u8_64_0;

# define Rte_TypeDef_Arr_u8_64
typedef Rte_DT_Arr_u8_64_0 Arr_u8_64[64];

# define Rte_TypeDef_t_uint8_x_16
typedef uint8 t_uint8_x_16[16];

# define Rte_TypeDef_t_uint8_x_4
typedef uint8 t_uint8_x_4[4];

# define Rte_TypeDef_t_uint8_x_64
typedef uint8 t_uint8_x_64[64];

# define Rte_TypeDef_NV_Data_DummyEntity
typedef struct
{
  Arr_u8_16 DummyEntity_Value;
} NV_Data_DummyEntity;

# define Rte_TypeDef_NV_Data_SecurityByte
typedef struct
{
  Arr_u8_4 SecurityByte_Value;
} NV_Data_SecurityByte;

# define Rte_TypeDef_NV_Data_Nonce_00
typedef struct
{
  Arr_u8_16 Nonce_00_Value;
} NV_Data_Nonce_00;

# define Rte_TypeDef_NV_Data_Tester_SN_00
typedef struct
{
  Arr_u8_64 Tester_SN_00_Value;
} NV_Data_Tester_SN_00;

# define Rte_TypeDef_NV_Data_Last_Reproduction_Date_00
typedef struct
{
  Arr_u8_16 Last_Reproduction_Date_00_Data;
} NV_Data_Last_Reproduction_Date_00;

# define Rte_TypeDef_NV_Data_Nonce_01
typedef struct
{
  Arr_u8_16 Nonce_01_Value;
} NV_Data_Nonce_01;

# define Rte_TypeDef_NV_Data_Tester_SN_01
typedef struct
{
  Arr_u8_64 Tester_SN_01_Value;
} NV_Data_Tester_SN_01;

# define Rte_TypeDef_NV_Data_Last_Reproduction_Date_01
typedef struct
{
  Arr_u8_16 Last_Reproduction_Date_01_Data;
} NV_Data_Last_Reproduction_Date_01;

# define Rte_TypeDef_NV_Data_Nonce_02
typedef struct
{
  Arr_u8_16 Nonce_02_Value;
} NV_Data_Nonce_02;

# define Rte_TypeDef_NV_Data_Tester_SN_02
typedef struct
{
  Arr_u8_64 Tester_SN_02_Value;
} NV_Data_Tester_SN_02;

# define Rte_TypeDef_NV_Data_Last_Reproduction_Date_02
typedef struct
{
  Arr_u8_16 Last_Reproduction_Date_02_Data;
} NV_Data_Last_Reproduction_Date_02;

# define Rte_TypeDef_NV_Data_Nonce_03
typedef struct
{
  Arr_u8_16 Nonce_03_Value;
} NV_Data_Nonce_03;

# define Rte_TypeDef_NV_Data_Tester_SN_03
typedef struct
{
  Arr_u8_64 Tester_SN_03_Value;
} NV_Data_Tester_SN_03;

# define Rte_TypeDef_NV_Data_Last_Reproduction_Date_03
typedef struct
{
  Arr_u8_16 Last_Reproduction_Date_03_Data;
} NV_Data_Last_Reproduction_Date_03;

# define Rte_TypeDef_NV_Data_SignVerifyResult
typedef struct
{
  Arr_u8_16 SignVerifyResult_Data;
} NV_Data_SignVerifyResult;

# define Rte_TypeDef_NV_Data_ActivePartition
typedef struct
{
  Arr_u8_4 ActivePartition_Data;
} NV_Data_ActivePartition;

# define Rte_TypeDef_Rte_DT_DIAG_DID_0202_Data_ref_0
typedef uint8 Rte_DT_DIAG_DID_0202_Data_ref_0;

# define Rte_TypeDef_Rte_DT_DIAG_DID_0220_Data_ref_0
typedef uint8 Rte_DT_DIAG_DID_0220_Data_ref_0;

# define Rte_TypeDef_Rte_DT_DIAG_DID_0230_Data_ref_0
typedef uint8 Rte_DT_DIAG_DID_0230_Data_ref_0;

# define Rte_TypeDef_Rte_DT_SignVerifyResult_Data_ref_0
typedef uint8 Rte_DT_SignVerifyResult_Data_ref_0;

# define Rte_TypeDef_Rte_DT_ActivePartition_Data_ref_0
typedef uint8 Rte_DT_ActivePartition_Data_ref_0;

# define Rte_TypeDef_Rte_DT_SecurityByte_Data_ref_0
typedef uint8 Rte_DT_SecurityByte_Data_ref_0;

# define Rte_TypeDef_PartitionIndexType
typedef uint8 PartitionIndexType;

# define Rte_TypeDef_TargetIndexType
typedef uint8 TargetIndexType;

# define Rte_TypeDef_DIAG_DID_0202_Data_ref
typedef Rte_DT_DIAG_DID_0202_Data_ref_0 DIAG_DID_0202_Data_ref[16];

# define Rte_TypeDef_DIAG_DID_0220_Data_ref
typedef Rte_DT_DIAG_DID_0220_Data_ref_0 DIAG_DID_0220_Data_ref[64];

# define Rte_TypeDef_DIAG_DID_0230_Data_ref
typedef Rte_DT_DIAG_DID_0230_Data_ref_0 DIAG_DID_0230_Data_ref[16];

# define Rte_TypeDef_SignVerifyResult_Data_ref
typedef Rte_DT_SignVerifyResult_Data_ref_0 SignVerifyResult_Data_ref[4];

# define Rte_TypeDef_ActivePartition_Data_ref
typedef Rte_DT_ActivePartition_Data_ref_0 ActivePartition_Data_ref[4];

# define Rte_TypeDef_CryptoBuffer_t_ref
typedef struct {
    uint32 BuffLen;
    uint8 InputBuffer[32];
    uint8 *OutputBufferPtr;
} CryptoBuffer_t;

# define Rte_TypeDef_LogicalBlockInfo_t_ref
typedef struct {
  UInt8 NonceWriteSts;
  UInt8 SNValueWriteSts;
}LogicalBlockInfo_t;

# define Rte_TypeDef_ActiveLogicalBlockInfo_t_ref
typedef struct {
  UInt8 ActiveBlockId;
  LogicalBlockInfo_t Status;
}ActiveLogicalBlockInfo_t;

/**********************************************************************************************************************
 * Per-Instance Memory User Types
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Constant value definitions
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte_Pim (Per-Instance Memory)
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Component Data Structures and Port Data Structures
 *********************************************************************************************************************/

/**********************************************************************************************************************
 *  LOCAL DATA TYPES AND STRUCTURES
 *********************************************************************************************************************/
typedef unsigned int Rte_BitType;

/**********************************************************************************************************************
 * type and extern declarations of RTE internal variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Rte Init State Variable
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Calibration Parameters (SW-C local and calibration component calibration parameters)
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Buffers for unqueued S/R
 *********************************************************************************************************************/
typedef struct
{
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_SecurityByte : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Nonce_00 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Tester_SN_00 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Last_Reproduction_Date_00 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Nonce_01 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Tester_SN_01 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Last_Reproduction_Date_01 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Nonce_02 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Tester_SN_02 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Last_Reproduction_Date_02 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Nonce_03 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Tester_SN_03 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_Last_Reproduction_Date_03 : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_SignVerifyResult : 1;
  Rte_BitType Rte_DirtyFlag_NvBlockSwComponentType_NVBlockDescriptor_ActivePartition : 1;
} Rte_DirtyFlagsType;
/**********************************************************************************************************************
 * Buffer for inter-runnable variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Internal C/S connections
 *********************************************************************************************************************/
#endif


