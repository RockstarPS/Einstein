/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

# ifndef UPD_AbstractInstaller_H
# define UPD_AbstractInstaller_H

# include "UPDi_types.h"
# include "UPDd.h"

//=====================================================================================================================
//  CONSTANTS & TYPES
//=====================================================================================================================
struct sUPDiAbstractInstaller;
struct sUPDiInstallSession;

typedef Std_ReturnType(*tpfGetExtension)(const struct sUPDiAbstractInstaller* this, tUPDiDataFormatType* pDataFormat);
typedef Std_ReturnType(*tpfInstallErase)(const struct sUPDiAbstractInstaller* this, tUPDiInstallSession* pSession, uint32 Size);
typedef Std_ReturnType(*tpfInstallStart)(const struct sUPDiAbstractInstaller* this, tUPDiInstallSession* pSession, uint32 Size);
typedef Std_ReturnType(*tpfInstallData)(const struct sUPDiAbstractInstaller* this, tUPDiInstallSession* pSession, uint8* Data, uint32 Size);
typedef Std_ReturnType(*tpfInstallExit)(const struct sUPDiAbstractInstaller* this, tUPDiInstallSession* pSession);
typedef Std_ReturnType(*tpfSerialize)(const struct sUPDiAbstractInstaller* this, uint32 SizeIn, uint8* data);
typedef Std_ReturnType(*tpfDeserialize)(const struct sUPDiAbstractInstaller* this, uint32 SizeIn, uint8* data);

typedef const struct 
{ 
    tpfGetExtension GetExtension;
    tpfInstallErase InstallErase;
    tpfInstallStart InstallStart;
    tpfInstallData InstallData;
    tpfInstallExit InstallExit;
    tpfSerialize Serialize;
    tpfDeserialize Deserialize;
} tUPDiAbstractInstaller_Vtbl;

typedef const struct sUPDiAbstractInstaller
{ 
    tUPDiAbstractInstaller_Vtbl* Vtbl;
} tUPDiAbstractInstaller;

//=====================================================================================================================
//  Interfaces
//=====================================================================================================================
Std_ReturnType UPDAbstractInstaller_GetDataFormat(tUPDiAbstractInstaller* this, tUPDiDataFormatType* pDataFormat );
Std_ReturnType UPDAbstractInstaller_InstallErase(tUPDiAbstractInstaller* this, tUPDiInstallSession* pSession, uint32 Size);
Std_ReturnType UPDAbstractInstaller_InstallStart(tUPDiAbstractInstaller* this, tUPDiInstallSession* pSession, uint32 Size);
Std_ReturnType UPDAbstractInstaller_InstallData(tUPDiAbstractInstaller* this, tUPDiInstallSession* pSession, uint8* Data, uint32 Size);
Std_ReturnType UPDAbstractInstaller_InstallExit(tUPDiAbstractInstaller* this, tUPDiInstallSession* pSession);

Std_ReturnType UPDAbstractInstaller_Serialize(tUPDiAbstractInstaller* this, uint32 SizeIn, uint8* Data);
Std_ReturnType UPDAbstractInstaller_Deserialize(tUPDiAbstractInstaller* this, uint32 SizeIn, uint8* Data);

# endif /*UPD_AbstractInstaller_H*/
