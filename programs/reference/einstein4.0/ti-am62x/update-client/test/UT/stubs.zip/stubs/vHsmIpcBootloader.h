/***************************************************************************/
/**
 * \copyright
 *       VISTEON CORPORATION CONFIDENTIAL
 *       ________________________________
 *       [2020] Visteon Corporation
 *       All Rights Reserved.
 *       NOTICE: This is an unpublished work of authorship, which contains trade
 *               secrets. Visteon Corporation owns all rights to this work and
 *               intends to maintain it in confidence to preserve its trade
 *               secret status. Visteon Corporation reserves the right, under
 *               the copyright laws of the United States or those of any other
 *               country that may have jurisdiction, to protect this work as an
 *               unpublished work, in the event of an inadvertent or deliberate
 *               unauthorized publication. Visteon Corporation also reserves
 *               its rights under all copyright laws to protect this work as a
 *               published work, when appropriate. Those having access to this
 *               work may not copy it, use it, modify it, or disclose the
 *               information contained in it without the written authorization
 *               of Visteon Corporation.
 *
 * \file vHsmIpcBootloader.h
 *
 * \brief
 *  IPC and Crypto interfaces for bootloader in M7
 *
 * \version 1.0.0
 * |Version | Date       | Author   | Task Id | Description                           |
 * |--------|------------|----------|---------|---------------------------------------|
 * |1.00.00 | 12/Feb/'21 | bjayara2  | xxxxxx  | Initial version                      |
 * \authors
 *          Name                     | CDSID     | Location
 *          ------------------------ | --------- | --------
 *          Akshay Krishna Upendran  | akrish10  | VTSC, Chennai, India
 *          Banumathi Jayaraman      | bjayara2  | VTSC, Chennai, India
 *          Geetha A Krishna         | kgeethaa  | VTSC, Bengaluru, India
 *          Shanmugam Karthik        | kshanmu4  | VTSC, Chennai, India
 ******************************************************************************/
#ifndef V_HSM_IPC_BOOTLOADER_H
#define V_HSM_IPC_BOOTLOADER_H
/******************************************************************************
 *  INCLUDES
 *****************************************************************************/
#include "Std_Types.h"

/*
 * \enum Csm_ReturnType
 * \brief Enumeration of the return values of the CSM.
 *
 *//**
 * \var Csm_ReturnType::CSM_E_OK
 * \brief Operation successful.
 *//**
 * \var Csm_ReturnType::CSM_E_NOT_OK
 * \brief Operation failed.
 *//**
 * \var Csm_ReturnType::CSM_E_BUSY
 * \brief Service is busy at the moment.
 *//**
 * \var Csm_ReturnType::CSM_E_SMALL_BUFFER
 * \brief Result buffer is too small to hold the complete result.
 *//**
 * \var Csm_ReturnType::CSM_E_ENTROPY_EXHAUSTION
 * \brief PRNG or random number generator cannot generate
 *        bytes at the moment.
 */




typedef struct
{
  /* !LINKSTO CRYSHE_21, 1
   */
  uint8 priority;
}
Crypto_She_SymDecryptConfigType;

#define REFLASH_SUCCESS   ((uint8)0)
#define REFLASH_FAILED    ((uint8)1)
/******************************************************************************
 *  PUBLIC FUNCTION DECLARATIONS
 *****************************************************************************/
/* Typedefs for Callback functions */
typedef FUNC (void, CRY_CODE) (*RsaNotifyCallback)(uint32 p_resultData_U32);
/**
 ******************************************************************************
 ** \fn vHsmIpc_Init
 **
 ** IPC driver Init, to be invoked from bootloader before placing any IPC jobs
 **
 ** This function returns None
 **
 ** \param [in] None
 *****************************************************************************/
FUNC (void, CRY_CODE) vHsmIpc_Init(void);

FUNC(void, CRY_CODE) Crypto_Init(void);
/**
 ******************************************************************************
 ** \fn vHsmIpc_DeInit
 **
 ** IPC driver DeInit to be invoked before going to low power mode/ shutdown
 ** when access to IPC is to be stopped
 **
 ** This function returns None
 **
 ** \param [in] None
 *****************************************************************************/
FUNC (void, CRY_CODE) vHsmIpc_DeInit(void);

/**
 ******************************************************************************
 ** \fn vHsmResetRequest
 **
 ** Reset request sent to M0P from M7 at tne end of a reflash event / any other
 ** reset request from tester/ reflash tool
 **
 ** \return Std_ReturnType<br>
 ** This function returns void
 **
 ** \param [in] None
 *****************************************************************************/
FUNC (void, CRY_CODE) vHsmResetRequest(void);

/**
 ******************************************************************************
 ** \fn CySldIpc_Isr_IpcDrv_Cat2
 **
 ** To be invoked in polling mechanism just before the periodic function
 ** vHsmIpc_HostManager_PeriodicCheck
 **
 ** \return Std_ReturnType<br>
 ** This function returns:
 ** - None
 **
 ** \param [in] None
 *****************************************************************************/
FUNC (void, CRY_CODE) CySldIpc_Isr_IpcDrv_Cat2(void);

/**
 ********************************************************************************
 ** \fn vHsmIpc_HostManager_PeriodicCheck
 **
 ** IPC Host Manager periodic check called every 4ms for periodically processing the IPC
 ** messages
 **
 ** This function returns None
 **
 ** \param [in] None
 *********************************************************************************/
FUNC (void, CRY_CODE) vHsmIpc_HostManager_PeriodicCheck(void);

FUNC (void, CRY_CODE) dummy_main(void);

FUNC (void, CRY_CODE) Cry_she_main(void);


/**
 ******************************************************************************
 ** \fn Cry_Hsm_RsaVerifyMainFunction
 **
 ** Rsa sign verify main function to track the state machine with M0P execution
 ** Use to transfer data to M0P from M7 for RSA verify crypto job and get
 ** back the response from M0P
 *****************************************************************************/
FUNC(void,CRY_CODE) Cry_Hsm_RsaVerifyMainFunction(void);
/**
 *********************************************************************************************
 ** \fn Cry_SheCmdDecCbcAdapterStart
 **
 ** \brief 
 **
 **
 ** \param [in] cfgPtr
 ** \param [in] keyPtr
 ** \param [in] initVectorPtr
 ** \param [in] initVectorLength
 ** 
 ** This function returns Csm_ReturnType
 **                 
 **
 ********************************************************************************************/
FUNC(Csm_ReturnType,CRY_CODE) Cry_SheCmdDecCbcAdapterStart(
  P2CONST(void,           AUTOMATIC, CRY_APPL_DATA) cfgPtr,
  P2CONST(Csm_SymKeyType, AUTOMATIC, CRY_APPL_DATA) keyPtr,
  P2CONST(uint8,          AUTOMATIC, CRY_APPL_DATA) initVectorPtr,
      VAR(uint32,         AUTOMATIC               ) initVectorLength);
/** \brief Stream encrypted data.
 **
 ** This function streams encrypted data into the SHE.
 **
 ** \param[in] iputTextPtr Pointer to encrypted data.
 ** \param[in] iputTextLength Length of encrypted data.
 ** \param[out] oputTextPtr oputTextLengthPtr to result buffer.
 ** \param[in|out] plainTextLengthPtr Pointer to length of buffer for
 **                                   result which will be overwritten
 **                                   with the length of the decrypted
 **                                   data.
 **
 ** \returns Error value.
 ** \retval   CSM_E_OK      If the update was successfully requested.
 ** \retval   CSM_E_NOT_OK  If the service has not been started.
 ** \retval   CSM_E_SMALL_BUFFER If the result buffer is too small for the
 **                              decrypted data.
 ** \retval   CSM_E_BUSY    If this service is already starting or updating.
 **/
FUNC(Csm_ReturnType,CRY_CODE) Cry_SheCmdDecCbcAdapterUpdate
(
  P2CONST(void,   AUTOMATIC, CRY_APPL_DATA) cfgid,
  P2CONST(uint8,  AUTOMATIC, CRY_APPL_DATA) iputTextPtr,
      VAR(uint32, AUTOMATIC               ) iputTextLength,
    P2VAR(uint8,  AUTOMATIC, CRY_APPL_DATA) oputTextPtr,
    P2VAR(uint32, AUTOMATIC, CRY_APPL_DATA) oputTextLengthPtr
);
/** \brief  Stream data to be encrypted.
 **
 ** This function streams data to be encrypted into the SHE.
 **
 ** \param[in]      iputTextPtr        A pointer to the start of an array which contains the
 **                                    constant plain text that shall be encrypted.
 ** \param[in]      iputTextLength     Length of the constant plain text in bytes.
 ** \param[out]     oputTextPtr        A pointer to the start of an array where the encrypted
 **                                    text will be stored.
 ** \param[in,out]  oputTextLengthPtr  Holds a pointer to a memory location in which the length
 **                                    information is stored. On calling this function this
 **                                    parameter shall contain the size of the buffer provided
 **                                    by oputTextPtr. When the request has finished, the amount
 **                                    of data that has been encrypted shall be stored.
 **
 ** \returns  Error value.
 **
 ** \retval   CSM_E_OK            If the update was successfully requested.
 ** \retval   CSM_E_NOT_OK        If the service has not been started.
 ** \retval   CSM_E_BUSY          If this service is already starting or updating.
 ** \retval   CSM_E_SMALL_BUFFER  If the result buffer is too small for the
 **                               encrypted data.
 **/
FUNC(Csm_ReturnType,CRY_CODE) Cry_SheCmdEncCbcAdapterUpdate
(
  P2CONST(void,   AUTOMATIC, CRY_APPL_DATA) cfgid,
  P2CONST(uint8,  AUTOMATIC, CRY_APPL_DATA) iputTextPtr,
      VAR(uint32, AUTOMATIC               ) iputTextLength,
    P2VAR(uint8,  AUTOMATIC, CRY_APPL_DATA) oputTextPtr,
    P2VAR(uint32, AUTOMATIC, CRY_APPL_DATA) oputTextLengthPtr
);
/** \brief  Start the symmetric encryption.
 **
 ** This function starts the SymEncrypt service which will
 ** encrypt blocks of data.
 **
 ** \param[in]      cfgPtr            The service configuration.
 ** \param[in]      keyPtr            Pointer to the key to be used.
 ** \param[in]      initVectorPtr     Holds a pointer to the initialization vector which
 **                                   has to be used during the symmetrical encryption
 **                                   computation.
 ** \param[in]      initVectorLength  Holds the length of the initialisation vector
 **                                   which has to be used during the symmetrical
 **                                   encryption computation.
 **
 ** \returns  Error value.
 **
 ** \retval   CSM_E_OK      If the service can be started.
 ** \retval   CSM_E_NOT_OK  If the key, init vector length or configuration are invalid.
 ** \retval   CSM_E_BUSY    If another instance of this service is already
 **                         running.
 **/
FUNC(Csm_ReturnType,CRY_CODE) Cry_SheCmdEncCbcAdapterStart
(
  P2CONST(void,           AUTOMATIC, CRY_APPL_DATA) cfgPtr,
  P2CONST(Csm_SymKeyType, AUTOMATIC, CRY_APPL_DATA) keyPtr,
  P2CONST(uint8,          AUTOMATIC, CRY_APPL_DATA) initVectorPtr,
      VAR(uint32,         AUTOMATIC               ) initVectorLength
);
/** \brief  Finish encrypt.
 **
 ** This function finishes the encryption.
 **
 ** \param[out]     oputTextPtr        Parameter is not used in this implementation.
 ** \param[in,out]  oputTextLengthPtr  Is always set to 0.
 **
 ** \returns  Error value.
 **
 ** \retval   CSM_E_OK            If the finish was successfully requested.
 ** \retval   CSM_E_NOT_OK        If the service has not been started.
 ** \retval   CSM_E_BUSY          If this service is already starting or updating.
 **/
FUNC(Csm_ReturnType,CRY_CODE) Cry_SheCmdEncCbcAdapterFinish
(
  P2CONST(void, AUTOMATIC, CRY_APPL_DATA) cfgid,
  P2VAR(uint8,  AUTOMATIC, CRY_APPL_DATA) oputTextPtr,
  P2VAR(uint32, AUTOMATIC, CRY_APPL_DATA) oputTextLengthPtr
);
/** \brief  Finish  decrypt.
 **
 ** This function finishes the decryption.
 **
 ** \returns  Error value.
 **
 ** \retval   CSM_E_OK      If the finish was successfully requested.
 ** \retval   CSM_E_NOT_OK  If the service has not been started.
 ** \retval   CSM_E_BUSY    If this service is already starting or updating.
 **/
FUNC(Csm_ReturnType,CRY_CODE) Cry_SheCmdDecCbcAdapterFinish
(
  P2CONST(void, AUTOMATIC, CRY_APPL_DATA) cfgid,
  P2VAR(uint8,  AUTOMATIC, CRY_APPL_DATA) oputTextPtr,
  P2VAR(uint32, AUTOMATIC, CRY_APPL_DATA) oputTextLengthPtr
);
FUNC(Csm_ReturnType,CRY_CODE) Crypto_She_SymDecrypt(
			P2CONST(void,           AUTOMATIC, CRY_APPL_DATA) cfgPtr, 
			P2CONST(Csm_SymKeyType, AUTOMATIC, CRY_APPL_DATA) keyPtr,
			P2CONST(uint8,          AUTOMATIC, CRY_APPL_DATA) initVectorPtr,
			    VAR(uint32,         AUTOMATIC               ) initVectorLength, 
			P2CONST(uint8,          AUTOMATIC, CRY_APPL_DATA) iputTextPtr,
		      VAR(uint32,         AUTOMATIC               ) iputTextLength,
		    P2VAR(uint8,          AUTOMATIC, CRY_APPL_DATA) oputTextPtr,
		    P2VAR(uint32,         AUTOMATIC, CRY_APPL_DATA) oputTextLengthPtr);
/**
 *********************************************************************************************
 ** \fn Crypto_She_SymDecryptUpdate
 **
 ** \brief 
 **
 **
 ** \param [in] iputTextPtr
 ** \param [in] iputTextLength
 ** \param [in] oputTextPtr
 ** \param [in] oputTextLengthPtr
 ** 
 ** This function returns Csm_ReturnType
 **                 
 **
 ********************************************************************************************/
FUNC(Csm_ReturnType,CRY_CODE) Crypto_She_SymDecryptUpdate(
  P2CONST(uint8,  AUTOMATIC, CRY_APPL_DATA) iputTextPtr,
      VAR(uint32, AUTOMATIC               ) iputTextLength,
    P2VAR(uint8,  AUTOMATIC, CRY_APPL_DATA) oputTextPtr,
    P2VAR(uint32, AUTOMATIC, CRY_APPL_DATA) oputTextLengthPtr);
/**
 *********************************************************************************************
 ** \fn Crypto_She_SymDecryptFinish
 **
 ** \brief 
 ** 
 **
 ** \param [in] oputTextPtr
 ** \param [in] oputTextLengthPtr
 ** 
 ** This function returns Csm_ReturnType
 **                 
 **
 ********************************************************************************************/
FUNC(Csm_ReturnType,CRY_CODE) Crypto_She_SymDecryptFinish(
  P2VAR(uint8,  AUTOMATIC, CRY_APPL_DATA) oputTextPtr,
  P2VAR(uint32, AUTOMATIC, CRY_APPL_DATA) oputTextLengthPtr);
/**
 ******************************************************************************
 ** \fn Cry_Hsm_HashCalc
 **
 ** Hash function - get the found hash to the buffer provided as pointer
 **
 ** This function returns Std_ReturnType
 ** - E_OK if request could be performed.
 ** - E_NOT_OK if not.
 ** \param [in] cfgPtr - configuration containing the priority
 **             p_dataPtr_PU8  - input buffer pointer on which hash
 **                              to be obtained
 **             p_dataLength_U32 - number of bytes on which hash to be calculated
 **             p_resultPtr_PU8  - pointer to update the hash to
 **             p_resultLengthPtr_PU32  - length of the hash to update
 **             p_truncationAllowed_BOOL  - truncation is allowed or not
 **                                       if the length present in the request
 **                                       is less than the hash length calculated
 *****************************************************************************/
FUNC(Csm_ReturnType,CRY_CODE) Cry_Hsm_HashCalc
(
                P2CONST(void,AUTOMATIC,CRY_APPL_DATA) cfgPtr,
                const uint8 * p_dataPtr_PU8 ,
               uint32 p_dataLength_U32,
               uint8 *      p_resultPtr_PU8 ,
               uint32 *     p_resultLengthPtr_PU32 ,
               boolean      p_truncationAllowed_BOOL
);

/** \brief Initialize CryShe module.
 **
 ** This function initializes the module. It has to be called before
 ** any services of this module are used.
 **/
FUNC(void,CRY_CODE) Cry_She_Init(void);


/**
 *********************************************************************************************
 ** \fn Cry_She_SymDecryptMainFunction
 **
 ** \brief 
 ** 
 **
 ** \param [in] NONE
 ** 
 ** This function returns NONE
 **                 
 **
 ********************************************************************************************/
FUNC(void,CRY_CODE) Cry_She_SymDecryptMainFunction(void);

/**
 ******************************************************************************
 ** \fn vHsmEraseRequestToM0P
 **
 ** Erase request sent to M0P for erasing HSM, Intelligence of 
 ** which bank to erase is with HSM; Callback from HSM will give the status
 ** of the erase 
 ** This function returns None
 **
 *******************************************************************************/
FUNC (void, CRY_CODE) vHsmEraseRequestToM0P(void);

/**
 ******************************************************************************
 ** \fn vHsmStartReflashRequestToM0P
 **
 ** Start reflash request along with the decrypted data for reflash with no
 ** start address as the start address gets arrived by HSM itself; Callback from HSM will 
 ** give the status of the reflash start request 
 **
 ** This function returns None
 ** \param [in] p_payloadPtr_U8P      Pointer to the data chunk to be reflashed 
 ** \param [in] p_payloadSize_U16     Size of the data chunk
 **
 *******************************************************************************/
FUNC (void, CRY_CODE) vHsmStartReflashRequestToM0P(uint8 *p_payloadPtr_U8P, 
                                                   uint16 p_payloadSize_U16);

/**
 ******************************************************************************
 ** \fn vHsmUpdateReflashRequestToM0P
 **
 ** Update reflash request along with the decrypted data for reflash;
 ** Callback from HSM will give the status of the reflash update request 
 **
 ** This function returns None
 ** \param [in] p_payloadPtr_U8P      Pointer to the data chunk to be reflashed 
 ** \param [in] p_payloadSize_U16     Size of the data chunk
 **
 *******************************************************************************/
FUNC (void, CRY_CODE) vHsmUpdateReflashRequestToM0P(uint8 *p_payloadPtr_U8P, 
                                                    uint16 p_payloadSize_U16);

/**
 ******************************************************************************
 ** \fn vHsmFinishReflashRequestToM0P
 **
 ** Finish reflash request to be called to HSM to get the status of the reflash 
 ** sequence done - start and update reflash status; Callback from HSM will give 
 ** the status of the total reflash request 
 **
 ** This function returns None
 ** \param [in] void
 **
 *******************************************************************************/
FUNC (void, CRY_CODE) vHsmFinishReflashRequestToM0P(void);

/**
 ******************************************************************************
 ** \fn vHsmBLReflashFailUpdateToM0P
 **
 ** Reflash failed in M7 must be informed to M0P for reverting back to the old
 ** partition in execution
 ** This function returns None
 ** \param [in] p_reflashFailSts_U8 - 1 - REFLASH_FAILED - Failed in reflashing 
 **                                       other segments
 **                                   0 - REFLASH_SUCCESS - no failue in reflash
 ** 
 *******************************************************************************/
FUNC (void, CRY_CODE) vHsmBLReflashFailUpdateToM0P(uint8 p_reflashFailSts_U8);

/**
 ******************************************************************************
 ** \fn vHsmFblKeyRequest
 **
 ** Request for a key from HSM side to be used in FBL for decrypt of the download
 ** This function returns E_OK when the key could be obtained from the HSM
 **                       E_NOT_OK when the key could not be obtained from HSM
 ** \param [in] void
 **
 *******************************************************************************/
FUNC (Std_ReturnType, CRY_CODE)vHsmFblKeyRequest( uint8 * p_keyData_U8P);

FUNC(Csm_ReturnType, CRY_CODE)Cry_SheCmdExtendSeedStart(P2CONST(void, AUTOMATIC, CRY_APPL_DATA) cfgPtr);
FUNC(Csm_ReturnType, CRY_CODE) Cry_SheCmdExtendSeedUpdate(P2CONST(uint8, AUTOMATIC, CRY_APPL_DATA) seedPtr, uint32 seedLength);
FUNC(Csm_ReturnType, CRY_CODE) Cry_SheCmdExtendSeedFinish(void);
FUNC(void, CRY_CODE) Cry_She_RandomSeedMainFunction(void);
FUNC(Csm_ReturnType, CRY_CODE)Call_Cry_SheCmdRnd
        (P2CONST(void, AUTOMATIC, CRY_APPL_DATA) cfgPtr,
        P2VAR(uint8, AUTOMATIC, CRY_APPL_DATA) resultPtr,
        uint32 resultLength_U32);
FUNC(void, CRY_CODE) Crypto_She_RandomGenerateMainFunction(void);

FUNC(Csm_ReturnType,CRY_CODE) Cry_RsaVerify
(
  P2VAR(uint8, AUTOMATIC, CRY_APPL_DATA) p_startAdd_U8P,
  VAR(uint32,  AUTOMATIC) p_size_U32,
  P2VAR(uint8, AUTOMATIC, CRY_APPL_DATA) p_signStartAdd_U8P,
  VAR(uint32,  AUTOMATIC) p_sizeOfSign_U32,
  P2VAR(uint32, AUTOMATIC, CRY_APPL_DATA) p_result_U32P
);

FUNC(Csm_ReturnType,CRY_CODE) Cry_RsaVerifyStart
(
  P2CONST(void,           AUTOMATIC, CRY_APPL_DATA) cfgPtr,
  P2CONST(Csm_SymKeyType, AUTOMATIC, CRY_APPL_DATA) keyPtr,
  P2CONST(uint8, AUTOMATIC, CRY_APPL_DATA) publicKey,
  VAR(uint16, AUTOMATIC) publicKeySize
);
#endif /* V_HSM_IPC_BOOTLOADER_H */
/* EOF */
