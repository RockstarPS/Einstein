/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

# ifndef UPD_IoAdapter_H
# define UPD_IoAdapter_H

# include "UPDi_types.h"

//=====================================================================================================================
/* CONSTANTS & TYPES */
//=====================================================================================================================


//=====================================================================================================================
//  User Public functions
//=====================================================================================================================
Std_ReturnType UPDIoAdapter_Idle(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget);
Std_ReturnType UPDIoAdapter_Hash(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget, tUPDiPartition* pPartition, uint32 Offset, uint32 Size, tUPDiHashingContext* HashingContext);
Std_ReturnType UPDIoAdapter_Read (tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget, tUPDiPartition* pPartition, uint32 Offset, uint32 Size);
Std_ReturnType UPDIoAdapter_Write(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget, tUPDiPartition* pPartition, uint32 Offset, uint32 Size, uint8* Data);
Std_ReturnType UPDIoAdapter_Erase(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget, tUPDiPartition* pPartition,uint32 targetAddress,uint32 size);

boolean UPDIoAdapter_IsBusy(tUPDiIoAdapter* this); // indicate if some IO operation are pending
Std_ReturnType UPDIoAdapter_Init(void);
Std_ReturnType UPDIoAdapter_Task(void);
Std_ReturnType UPDIoAdapter_SetIdle(void);

# endif /*UPD_IoAdapter_H*/
