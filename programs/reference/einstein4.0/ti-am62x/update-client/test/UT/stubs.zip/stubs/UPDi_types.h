/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

#ifndef UPDi_Types_H
#define UPDi_Types_H

#include "Std_Types.h"
#include "system.h"
#include "Dcm_Types.h"

//=====================================================================================================================
/* CONSTANTS & TYPES */
//=====================================================================================================================
typedef enum
{
    eUPDiUpdate_BankInvalid,
    eUPDiUpdate_BankActive,
    eUPDiUpdate_BankInactive,
} tUPDBank;

typedef enum
{
    /*Level 1 states*/
    eUPDiUpdate_Idle = 0x0100,
    eUPDiUpdate_Updating = 0x0200,
    eUPDiUpdate_Activation = 0x0300,
    eUPDiUpdate_Activated = 0x0400,
    eUPDiUpdate_RollingBack = 0x0500,
    eUPDiUpdate_UpdateFailed = 0x0600,
    eUPDiUpdate_Level1Mask = 0xFF00,

    /*Level 2, Activation inner states*/
    eUPDiUpdate_Act_CopyngAndVerifyng = eUPDiUpdate_Activation + 0x01,
    eUPDiUpdate_Act_WaitReprogReboot = eUPDiUpdate_Activation + 0x02,
    eUPDiUpdate_Act_ExtternalUpdate = eUPDiUpdate_Activation + 0x03,
    eUPDiUpdate_Act_WaitAppReboot = eUPDiUpdate_Activation + 0x04,

    /*Level 2, RollingBack inner states*/
    eUPDiUpdate_RB_WaitReprogReboot = eUPDiUpdate_Activation + 0x02,
    eUPDiUpdate_RB_ExtternalUpdate = eUPDiUpdate_Activation + 0x03,
    eUPDiUpdate_RB_WaitAppReboot = eUPDiUpdate_Activation + 0x04,
} tUPDUpdateState;

typedef enum
{
    /*for Polynomial 0x04C11DB7 (standard for Ethernet and Arm)*/
    eUPDiHash_Crc32 = 0x01, 
    eUPDiHash_Sha256 = 0x02
} tUPDHashingTypes;

typedef enum
{
    eUPDiTarget_Uninst = 0x100,
    eUPDiTarget_UninstMask = 0xF00,
    eUPDiTarget_UninstFailed = 0xF10,
    eUPDiTarget_UninstErasing = 0x110,
    eUPDiTarget_UninstIdle = 0x120,
    eUPDiTarget_UninstIdleMask = 0xFF0,
    eUPDiTarget_UninstIdleBackup = 0x121,
    eUPDiTarget_UninstIdleUndef = 0x122,
    eUPDiTarget_UninstIdleEmpty = 0x123,
    eUPDiTarget_UninstInstalling = 0x130,
    eUPDiTarget_UninstCopiyng = 0x140,
    eUPDiTarget_Uninstalled = 0x160,
    eUPDiTarget_Installing = 0x200,
    eUPDiTarget_Installed = 0x260,
    eUPDiTarget_Reading = 0x230,
    eUPDiTarget_InstMask = 0xF00,
    eUPDiTarget_InstVerfiyng = 0x210,
    eUPDiTarget_InstVerfied = 0x220,
    eUPDiTarget_InstVerfiedMask = 0x220,
    eUPDiTarget_InstVerfiedUndeployed = 0x221,
    eUPDiTarget_InstVerfiedDeploying = 0x222,
    eUPDiTarget_InstVerfiedDeployed = 0x223,
} tUPDiTargetState;

typedef enum
{
    eUPDiMode_Reprog,
    eUPDiMode_App
} tUPDiMode;

typedef enum
{
    eUPDiIoReq_Hash,
    eUPDiIoReq_Read,
    eUPDiIoReq_Write,
    eUPDiIoReq_Erase,
    eUPDiIoReq_Init,
    eUPDiIoReq_Decrypt,
    eUPDiIoReq_SignVerify,
    eUPDiIoReq_Idle
} tUPDiIoReqType;

typedef enum
{
    eUPDiDataFormat_Invalid = 0x00u,
    eUPDiDataFormat_Raw = 0x01u,
    eUPDiDataFormat_Cmp = 0x02u,
    eUPDiDataFormat_Enc = 0x04u,
    eUPDiDataFormat_CmpRaw = 0x03u,
    eUPDiDataFormat_EncRaw = 0x05u,
    eUPDiDataFormat_CmpEncRaw = 0x07u,    
}tUPDiDataFormatType;

struct sUPDiTarget;
struct sUPDiIoAdapter;
struct sUPDiAbstractInstaller;
struct sUPDiInstallSession;
struct sUPDTarget;
struct sUPDIoAdapterVtbl;
struct sUPDIoAdapter;

typedef uint16 tUPDiSessionID;

typedef const struct sUPDiPartition
{
    uint32 Address;
    uint32 Size;
    struct sUPDiIoAdapter* IoAdapter;
} tUPDiPartition;

typedef struct sUPDiBuffer
{
    uint8* Addr;
    uint16 CurrPos;
    uint16 ChunkSize;
    uint32 Size;
} tUPDiBuffer;

typedef const struct sUPDiBufferSet
{
    uint8* Addr;
    uint32 Buffersize;
}tUPDiBufferSet;

typedef const struct sUPDiBufferPool
{
    tUPDiBufferSet Root;
    tUPDiBufferSet NestedRoot;
    tUPDiBufferSet Child;
}tUPDiBufferPool;

typedef struct sUPDiInstallSession
{
    const struct sUPDiAbstractInstaller* RootInstaller;
    const struct sUPDiTarget* Target;
    uint32  PartitionInstalled; // one bit per partition for the curent Target, 
                                // when the bit is set the partition installation is done or pending in the IoAdapter queue
    uint32  InstalledSize;      // remaining size to be processed
    uint32  PackageSize;        // root package size
    boolean IsActive;
    tUPDiDataFormatType DataFormat;
} tUPDiInstallSession;

typedef uint8 tUPDiSha256[32];

typedef struct sUPDiHashingContext
{
    tUPDHashingTypes HashingTypes; // Bit field, several hash types can be required
    uint32 Crc32;
    uint8 Sha256[32];
} tUPDiHashingContext;

typedef struct sUPDiIoReq
{
    uint32 Address;
    uint32 Size;
    const struct sUPDiTarget* pTarget;
    tUPDiIoReqType ReqType;
    tUPDiHashingContext* pHashingContext;
    struct sUPDiIoAdapter* pIoAdapter;
} tUPDiIoReq;

typedef Std_ReturnType(*tpfProcessReq)(tUPDiIoReq* Req);

typedef const struct sUPDiIoAdapterVtbl
{ 
    tpfProcessReq ProcessReq;
} tUPDiIoAdapterVtbl;

typedef struct
{
    uint32 PendingCalls;  /*Bit filed, one bit per target*/
    uint16 NextToProduce; /*next empty slot in the FIFO*/
    uint16 NextToConsume; /*next slot o the FIFO to be consumed, if it is equal to NextToProduce the FIFO is empty*/
    uint8* AdapterBuffer;
} tUPDiIoAdapterRam;

typedef struct sUPDiIoAdapter
{
    tUPDiIoAdapterVtbl* Vtbl;
    tUPDiIoAdapterRam* Ram;
} tUPDiIoAdapter;

typedef struct sUPDdManifest
{
    uint32 GoldenCrc; // Define the expected value of the CRC32, CRC ploynomial is Polynomial 0x04C11DB7h
    uint8  GoldenSha256[32];
    uint8  VersionMajor;
    uint8  VersionMinor;
} tUPDdManifest;

typedef struct sUPDiTargetRam
{
    tUPDdManifest ActiveManifest;    // Reserved for future use in GIP Side
    tUPDdManifest InactiveManifest;  // Reserved for future use in GIP Side
    tUPDiTargetState State;
    uint16 nextPartitionIndex; // for erase, copy, deploy or crc iterations
    uint32 nextByte;// for erase, copy, deploy or crc iterations
    uint8 nextTargetIndex;
} tUPDiTargetRam;

typedef const struct sUPDiPartitionGroup
{
    tUPDiPartition* BankA;
    tUPDiPartition* BankB;
    tUPDiPartition* BankExt;
} tUPDiPartitionGroup;

typedef const struct sUPDiTarget
{ 
    tUPDiTargetRam* Ram;
    const char* Name;
    uint8 GroupsCount; 
    tUPDiPartitionGroup* Groups; 
} tUPDiTarget;

typedef const struct
{
    tUPDiMode Mode;
    uint16 TargetsCount;
    tUPDiTarget** Targets;
    uint16 IoAdaptersCount;
    tUPDiIoAdapter** IoAdapters;
    uint16 InstallersCount;
    const struct sUPDiAbstractInstaller** Installers;
    tUPDiInstallSession* Sessions;
    uint16 SessionsCount;
    tUPDiBufferPool* Buffer;
} tUPDiUpdateCdd;

#endif 
