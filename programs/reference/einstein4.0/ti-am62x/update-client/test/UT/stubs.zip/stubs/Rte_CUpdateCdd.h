/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CBacklightCdd.h
 *           Config:  Toyota_38xd.dpa
 *      ECU-Project:  Toyota_38xd
 *
 *        Generator:  MICROSAR RTE Generator Version 4.29.0
 *                    RTE Core Version 1.29.0
 *          License:  CBD2200498
 *
 *      Description:  Application header file for SW-C <CBacklightCdd>
 *********************************************************************************************************************/

/* double include prevention */
#ifndef RTE_CUPDATECDD_H
# define RTE_CUPDATECDD_H

# ifndef RTE_CORE
#  ifdef RTE_APPLICATION_HEADER_FILE
#   error Multiple application header files included.
#  endif
#  define RTE_APPLICATION_HEADER_FILE
#  ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#   define RTE_PTR2ARRAYBASETYPE_PASSING
#  endif
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CUpdateCdd_Type.h"
# include "Rte_DataHandleType.h"

/**********************************************************************************************************************
 * Runnable entities
 *********************************************************************************************************************/
# ifndef RTE_CORE

    #  define RTE_RUNNABLE_CUPD_UpdateCdd_Impl_MainFunction CUPD_UpdateCdd_Impl_MainFunction
    #  define RTE_RUNNABLE_CUPD_UpdateCdd_Impl_OnCommand CUPD_UpdateCdd_Impl_OnCommand
    #  define RTE_RUNNABLE_UpdateCdd_GenericRequestTransferExit UpdateCdd_GenericRequestTransferExit
    #  define RTE_RUNNABLE_UpdateCdd_GenericTransferDataHandler UpdateCdd_GenericTransferDataHandler
    #  define RTE_RUNNABLE_UpdateCdd_GenericRequestDownloadHandler UpdateCdd_GenericRequestDownloadHandler
    #  define RTE_RUNNABLE_UpdateCdd_GenericRequestEraseHandler UpdateCdd_GenericRequestEraseHandler
    #  define RTE_RUNNABLE_UpdateCdd_GenericRequest_Verify_RSA_SignatureValue UpdateCdd_GenericRequest_Verify_RSA_SignatureValue
    #  define RTE_RUNNABLE_UPD_Task UPD_Task
    




# endif /* !defined(RTE_CORE) */

Std_ReturnType UPD_Task(void);
void CUPD_UpdateCdd_Impl_MainFunction(void); /* PRQA S 0850, 3451 */ /* MD_MSR_19.8, MD_Rte_3451 */
Std_ReturnType CUPD_UpdateCdd_Impl_OnCommand(ECmpCmd cmdP); /* PRQA S 0850 */ /* MD_MSR_19.8 */

Std_ReturnType UpdateCdd_GenericRequestTransferExit(Dcm_OpStatusType opStatus,Dcm_MsgContextType *msgContext,uint8* errCode);
Std_ReturnType UpdateCdd_GenericTransferDataHandler(Dcm_OpStatusType opStatus,Dcm_MsgContextType *msgContext,uint8* errCode);
Std_ReturnType UpdateCdd_GenericRequestDownloadHandler(Dcm_OpStatusType opStatus,Dcm_MsgContextType *msgContext, uint8* errCode);
Std_ReturnType UpdateCdd_GenericRequest_Verify_RSA_SignatureValue (Dcm_OpStatusType opStatus, uint8 *pMsgContext, Dcm_NegativeResponseCodeType *ErrorCode);
Std_ReturnType UpdateCdd_GenericRequestEraseHandler(Dcm_OpStatusType opStatus,uint8* pMsgContext,Dcm_NegativeResponseCodeType *ErrorCode);

FUNC(Std_ReturnType, Dcm_App_CODE) Dcm_App_GetActiveLogicalBlockInfo(ActiveLogicalBlockInfo_t *Data);
#  define Rte_Call_CS_DcmApp_GetActiveLogicalBlockInfo Dcm_App_GetActiveLogicalBlockInfo

FUNC(Std_ReturnType, RTE_MDL_DATAADAPTER_APPL_CODE) Mdl_DataAdapter_GetNonce_00(P2VAR(Rte_DT_DIAG_DID_0202_Data_ref_0, AUTOMATIC, RTE_MDL_DATAADAPTER_APPL_VAR) pNvmData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
#  define Rte_Call_rpNonce_00_GetNonce_00 Mdl_DataAdapter_GetNonce_00

FUNC(Std_ReturnType, RTE_MDL_DATAADAPTER_APPL_CODE) Mdl_DataAdapter_GetNonce_01(P2VAR(Rte_DT_DIAG_DID_0202_Data_ref_0, AUTOMATIC, RTE_MDL_DATAADAPTER_APPL_VAR) pNvmData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
#  define Rte_Call_rpNonce_01_GetNonce_01 Mdl_DataAdapter_GetNonce_01

FUNC(Std_ReturnType, RTE_MDL_DATAADAPTER_APPL_CODE) Mdl_DataAdapter_GetNonce_02(P2VAR(Rte_DT_DIAG_DID_0202_Data_ref_0, AUTOMATIC, RTE_MDL_DATAADAPTER_APPL_VAR) pNvmData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
#  define Rte_Call_rpNonce_02_GetNonce_02 Mdl_DataAdapter_GetNonce_02

FUNC(Std_ReturnType, RTE_MDL_DATAADAPTER_APPL_CODE) Mdl_DataAdapter_GetNonce_03(P2VAR(Rte_DT_DIAG_DID_0202_Data_ref_0, AUTOMATIC, RTE_MDL_DATAADAPTER_APPL_VAR) pNvmData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
#  define Rte_Call_rpNonce_03_GetNonce_03 Mdl_DataAdapter_GetNonce_03

FUNC(Std_ReturnType, RTE_MDL_DATAADAPTER_APPL_CODE) Mdl_DataAdapter_GetSecurityByte(P2VAR(Rte_DT_DIAG_DID_0202_Data_ref_0, AUTOMATIC, RTE_MDL_DATAADAPTER_APPL_VAR) pNvmData); /* PRQA S 0850 */ /* MD_MSR_19.8 */
#  define Rte_Call_rpSecurityByte_GetSecurityByte Mdl_DataAdapter_GetSecurityByte

FUNC(Std_ReturnType, RTE_MDL_CRYPTOADAPTER_APPL_CODE)Mdl_CryptoAdapter_Rsa_Verify(uint8* pDataAddr, uint8* SignaturePtr, uint32 SignatureSize, uint32 DataSize);
#  define Rte_Call_CS_RsaSignVerify_GetRsaSignVerify Mdl_CryptoAdapter_Rsa_Verify

FUNC(Std_ReturnType, RTE_FBL_APP_APPL_CODE) Fbl_App_GetInActivePartitionIndex(TargetIndexType pTgtIndex, PartitionIndexType* pPartitionIndex);
#  define Rte_Call_rpInActivePartitionIndex_GetInActivePartitionIndex Fbl_App_GetInActivePartitionIndex

FUNC(Std_ReturnType, RTE_FBL_APP_APPL_CODE) Fbl_App_SwitchActivePartition(void);
#  define Rte_Call_CS_UPD_SwitchActivePartition Fbl_App_SwitchActivePartition

# ifndef RTE_CORE
/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

#  define RTE_E_TI_Backlight_NotifyDispaly_E_NOT_OK (1U)

#  define RTE_E_TI_Backlight_Service_E_NOT_OK (1U)

#  define RTE_E_TI_Backlight_Status_E_NOT_OK (1U)

#  define RTE_E_TI_IOHWAB_GetDIn_E_NOT_OK (1U)

#  define RTE_E_TI_IOHWAB_PWM_E_NOT_OK (1U)

#  define RTE_E_TI_IOHWAB_SetDout_E_NOT_OK (1U)

#  define RTE_E_if_CS_ModeOnCommand_E_NOT_OK (1U)
# endif /* !defined(RTE_CORE) */

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* RTE_CBACKLIGHTCDD_H */

/**********************************************************************************************************************
 MISRA 2012 violations and justifications
 *********************************************************************************************************************/

/* module specific MISRA deviations:
   MD_Rte_0624:  MISRA rule: Rule8.3
     Reason:     This MISRA violation is a consequence from the RTE requirements [SWS_Rte_01007] [SWS_Rte_01150].
                 The typedefs are never used in the same context.
     Risk:       No functional risk. Only a cast to uint8* is performed.
     Prevention: Not required.

   MD_Rte_0786:  MISRA rule: Rule5.5
     Reason:     Same macro and idintifier names in first 63 characters are required to meet AUTOSAR spec.
     Risk:       No functional risk.
     Prevention: Not required.

   MD_Rte_3449:  MISRA rule: Rule8.5
     Reason:     Schedulable entities are declared by the RTE and also by the BSW modules.
     Risk:       No functional risk.
     Prevention: Not required.

   MD_Rte_3451:  MISRA rule: Rule8.5
     Reason:     Schedulable entities are declared by the RTE and also by the BSW modules.
     Risk:       No functional risk.
     Prevention: Not required.

*/
