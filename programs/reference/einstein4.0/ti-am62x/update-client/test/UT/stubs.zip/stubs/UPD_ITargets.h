/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/
# ifndef UPD_ITargets_H
# define UPD_ITargets_H

# include "UPD.h"

//=====================================================================================================================
//  Update interface
//=====================================================================================================================
Std_ReturnType UPD_ITargets_GetManifest(tUPDiSessionID pSession, tUPDBank Bank);
Std_ReturnType UPD_ITargets_GetTargetState(tUPDiSessionID pSession, tUPDBank Bank);
Std_ReturnType UPD_ITargets_AreAllTargetsVerfied(boolean* pVerified, tUPDBank Bank);
Std_ReturnType UPD_ITargets_VerifyAllTargets(tUPDHashingTypes HashingTypes, tUPDBank Bank);

# endif /*UPD_ITargets_H*/


