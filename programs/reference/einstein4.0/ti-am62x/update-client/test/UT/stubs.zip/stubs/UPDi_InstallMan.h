/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

# ifndef UPD_InstallMan_H
# define UPD_InstallMan_H

# include "UPD.h"

//=====================================================================================================================
/* Global variables */
//=====================================================================================================================

//=====================================================================================================================
/* Public installation interface */
//=====================================================================================================================
/*FOTA or Wired update*/
Std_ReturnType UPDInstallMan_TransferStart(uint32 PackageSize, tUPDiSessionID pSessionID);
Std_ReturnType UPDInstallMan_TransferData(tUPDiSessionID SessionID, uint32 Size, uint8* data);
Std_ReturnType UPDInstallMan_TransferExit(tUPDiSessionID SessionID);
Std_ReturnType UPDInstallMan_Erase(uint32 PackageSize, tUPDiSessionID pSessionID);
Std_ReturnType UPDInstallMan_AllocBuffer(tUPDiDataFormatType pCurrInstallDataFormat, tUPDiInstallSession* pSession, tUPDiBuffer* pInputBuff, tUPDiBuffer* pOutputBuff);

/*FOTA only*/
/*copy related inactive partitions to active partitions.*/
Std_ReturnType UPDInstallMan_CopyLast(char* TargetName); 
/*For all Uninstalled targets, copy all inactive partitions to active partitions*/
Std_ReturnType UPDInstallMan_CopyLastToAllUninstalled(void);
/* Suspend the installation session*/
Std_ReturnType UPDInstallMan_Suspend(tUPDiSessionID Id);
/*Suspend the installation session .*/
Std_ReturnType UPDInstallMan_SuspendAll(void);
/*Resume an installation session*/
Std_ReturnType UPDInstallMan_Resume(char* PackageName);

//=====================================================================================================================
//  Management interface
//=====================================================================================================================
void UPDInstallMan_Init(void);
Std_ReturnType UPDInstallMan_Deserialize(uint32 SizeIn, uint8* data);
Std_ReturnType UPDInstallMan_Serialize(uint32 SizeIn, uint8* data);


# endif /*UPD_InstallMan_H*/
