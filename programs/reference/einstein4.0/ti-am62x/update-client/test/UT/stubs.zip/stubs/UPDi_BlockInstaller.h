/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

# ifndef UPD_BlockInstaller_H
# define UPD_BlockInstaller_H

//=====================================================================================================================
//  CONSTANTS & TYPES
//=====================================================================================================================
typedef struct sUPDiBlockInstaller_Ram
{ 
    /*partition under installation, NULL if installation is not running*/
    const struct sUPDiPartition* pPartition; 
    /*next byte to be installed*/
    tUPDiBuffer InBuffer;
    tUPDiBuffer OutBuffer;
} tUPDiBlockInstaller_Ram;

typedef const struct sUPDiBlockInstaller
{ 
    tUPDiAbstractInstaller_Vtbl* Vtbl; 
    tUPDiBlockInstaller_Ram* Ram; 
} tUPDiBlockInstaller;

extern tUPDiAbstractInstaller_Vtbl UPDBlockInstaller_Vtbl;

//=====================================================================================================================
//  Interface
//=====================================================================================================================
Std_ReturnType UPDBlockInstaller_GetDataFormat(tUPDiBlockInstaller* this, tUPDiDataFormatType* pDataFormat);
Std_ReturnType UPDBlockInstaller_InstallErase(tUPDiBlockInstaller* this, tUPDiInstallSession* pSession, uint32 Size);
Std_ReturnType UPDBlockInstaller_InstallStart(tUPDiBlockInstaller* this, tUPDiInstallSession* pSession, uint32 Size);
Std_ReturnType UPDBlockInstaller_InstallData(tUPDiBlockInstaller* this, tUPDiInstallSession* pSession, uint8* Data, uint32 Size);
Std_ReturnType UPDBlockInstaller_InstallExit(tUPDiBlockInstaller* this, tUPDiInstallSession* pSession);

Std_ReturnType UPDBlockInstaller_Serialize(tUPDiBlockInstaller* this, uint32 SizeIn, uint8* data);
Std_ReturnType UPDBlockInstaller_Deserialize(tUPDiBlockInstaller* this, uint32 SizeIn, uint8* data);

# endif /*UPD_BlockInstaller_H*/
