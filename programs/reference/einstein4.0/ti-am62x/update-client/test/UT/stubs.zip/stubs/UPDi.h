/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

# ifndef UPDi_H
# define UPDi_H

# include "UPD.h"
# include  "Std_Types.h"
# include "UPDi_types.h"
# include "UPDi_UpdateMan.h"
# include "UPDi_InstallMan.h"
# include "UPDi_IoAdapter.h"
# include "UPDi_AbstractInstaller.h"
# include "UPDi_BlockInstaller.h"
# include "UPDi_Target.h"
# include "UPDd.h"
# include "UPD_Cfg.h"

//=====================================================================================================================
/* User interface */
//=====================================================================================================================
Std_ReturnType UPDi_GetManifest(const char* TargetName, tUPDBank Bank);
Std_ReturnType UPDi_GetTargetState(const char* TargetName, tUPDBank Bank);

//=====================================================================================================================
/* Internal CDD accessors */
//=====================================================================================================================
/* Installers accessors */
tUPDiAbstractInstaller* UPDi_AcquireInstaller(tUPDiInstallSession* pSession, tUPDiDataFormatType pCurrDataFormat);
void UPDi_ReleaseInstaller(tUPDiAbstractInstaller* pInstaller);

/* Sessions accessors */
tUPDiInstallSession* UPDi_GetSession(uint16 Index);
uint16                UPDi_GetSessionCount(void);

/* Target accessors */
tUPDiTarget* UPDi_GetTarget(uint16 Index);
uint16 UPDi_GetTargetCount(void);
Std_ReturnType UPDUpdateCdd_GetManifest(const char* TargetName, tUPDBank Bank);
void UPDUpdateCdd_Task(void); 

//=====================================================================================================================
/* Deployment functions - To be defined by the children class */
//=====================================================================================================================
boolean UPDi_CheckDependencies(tUPDBank Bank);
boolean UPDi_VerifyHashes(tUPDiTarget* pTarget, tUPDBank Bank, tUPDiHashingContext* pHashingContext, boolean FirstVerificationAfterInstall);

void    UPDi_DecodeManifestData(char* KeyName, char* KeyValue, tUPDdManifest* pManifest);
void    UPDi_InitializeManifest(tUPDdManifest* pManifest);
void    UPDi_LockResource(void);
void    UPDi_UnlockResource(void);
void    UPDi_NotifyTargetChange(void);
void    UPDi_NotifyUpdateChange(void);
Std_ReturnType UPDi_GetInactiveBank(tUPDiPartitionGroup* this, tUPDiPartition* pBank);

void                UPDUpdateCdd_Init(void);
boolean             UPDUpdateCdd_IsBusy(void);
void                UPDUpdateCdd_ReleaseInstaller(tUPDiAbstractInstaller* pInstaller);
tUPDiInstallSession* UPDUpdateCdd_GetSession(uint16 Index);
uint16              UPDUpdateCdd_GetSessionCount(void);
tUPDiTarget*        UPDUpdateCdd_GetTarget(uint16 Index);
uint16              UPDUpdateCdd_GetTargetCount(void);
Std_ReturnType      UPDUpdateCdd_GetTargetState(const char* TargetName, tUPDBank Bank);
tUPDBank            UPDUpdateMan_GetBank(tUPDiPartition* Partition);

//=====================================================================================================================
/* tUPDiUpdateCdd configuration */
//=====================================================================================================================

# endif /*UPDi_H*/
