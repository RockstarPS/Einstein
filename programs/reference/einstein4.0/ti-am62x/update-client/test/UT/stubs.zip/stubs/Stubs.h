#ifndef STUBS_H
#define STUBS_H

#include "Std_Types.h"
#include "Rte_Type.h"

extern void BacklightCfgCdd_Init(void);
extern void CDD_GetApmTimerCount(uint32* Timer);
/**< Mode for the Watchdog Interface */

//#warning "Gpt not configured for Apm"
//#define GptConf_GptChannelConfiguration_GptChCfg_60MHzFRT  0U

extern void PreTaskHook( void );
extern void PostTaskHook( void );
extern void UserPreISRHook(uint32 x);
extern void UserPostISRHook(uint32 x);


# define Rte_TypeDef_UInt32
typedef uint32 UInt32;

# define Rte_TypeDef_EDisplayPower
typedef uint8 EDisplayPower;

 # define Rte_TypeDef_SDisplaySetPower
typedef struct
{
  UInt32 displayId;
  EDisplayPower state;
} SDisplaySetPower; 

# define Rte_TypeDef_EDmnChangeReqStatus_t
typedef uint8 EDmnChangeReqStatus_t;

# define Rte_TypeDef_EcuMExt_WakeupReasonType
typedef sint32 EcuMExt_WakeupReasonType;

# define Rte_TypeDef_EUclLinkState_t
typedef uint8 EUclLinkState_t;

# define Rte_TypeDef_EDmnOverallState_t
typedef uint8 EDmnOverallState_t;

 # define Rte_TypeDef_EDmnHealthState_t
typedef uint8 EDmnHealthState_t;


typedef uint8 NetworkHandleType;


/* below stubs added by anil */

// typedef enum
// {
//    CSM_E_OK,
//    CSM_E_NOT_OK,
//    CSM_E_BUSY,
//    CSM_E_SMALL_BUFFER,
//    CSM_E_ENTROPY_EXHAUSTION,
//    CSM_E_KEY_NOT_AVAILABLE
// }
// Csm_ReturnType;

extern void Mcu_NotificationFunction_HvLvd2(void);

#define DioConf_DioChannel_DO_MCU_EXTMEM_RESET 0


/* IoHwAb_DIn_Cfg.c  */

#  ifndef eIO_DIN_DI_AL_HAZARD
#   define eIO_DIN_DI_AL_HAZARD (0U)
#  endif

#  ifndef eIO_DIN_DI_AH_IGNITION
#   define eIO_DIN_DI_AH_IGNITION (1U)
#  endif

#  ifndef eIO_DIN_DI_SMPS_3V3_PG
#   define eIO_DIN_DI_SMPS_3V3_PG (2U)
#  endif

#  ifndef eIO_DIN_STOP_LAMP_MCU
#   define eIO_DIN_STOP_LAMP_MCU (3U)
#  endif

#  ifndef eIO_DIN_DI_AL_BRAKE_LEVEL
#   define eIO_DIN_DI_AL_BRAKE_LEVEL (4U)
#  endif

#  ifndef eIO_DIN_DI_AL_OIL_W
#   define eIO_DIN_DI_AL_OIL_W (5U)
#  endif

#  ifndef eIO_DIN_DI_AL_DRV_SEAT_BUCKLE
#   define eIO_DIN_DI_AL_DRV_SEAT_BUCKLE (6U)
#  endif

#  ifndef eIO_DIN_DI_AL_WASHER_LEVEL_SW
#   define eIO_DIN_DI_AL_WASHER_LEVEL_SW (7U)
#  endif

#  ifndef eIO_DIN_ODO_TripKnobInput
#   define eIO_DIN_ODO_TripKnobInput (8U)
#  endif

#  ifndef eIO_DIN_DI_AL_VACUUM
#   define eIO_DIN_DI_AL_VACUUM (9U)
#  endif

#  ifndef eIO_DIN_DI_LCD_BL_PWR_FAULT
#   define eIO_DIN_DI_LCD_BL_PWR_FAULT (10U)
#  endif

#  ifndef eIO_DIN_DI_AL_FUEL_LID_EFI_ECU
#   define eIO_DIN_DI_AL_FUEL_LID_EFI_ECU (11U)
#  endif

#  ifndef eIO_DIN_DI_TT_SHIFT_ERR
#   define eIO_DIN_DI_TT_SHIFT_ERR (12U)
#  endif

#  ifndef eIO_DIN_MAX
#   define eIO_DIN_MAX (13U)
#  endif

/* IoHwAb_DOut_Cfg.c  */

#  ifndef eIO_DOUT_DO_5VSW2_3V3_EN
#   define eIO_DOUT_DO_5VSW2_3V3_EN (0U)
#  endif

#  ifndef eIO_DOUT_PARK_BRAKE_TT_OUT
#   define eIO_DOUT_PARK_BRAKE_TT_OUT (1U)
#  endif

#  ifndef eIO_DOUT_DO_SYC1
#   define eIO_DOUT_DO_SYC1 (2U)
#  endif

#  ifndef eIO_DOUT_SEAT_BELT_TT_MCUOUT
#   define eIO_DOUT_SEAT_BELT_TT_MCUOUT (3U)
#  endif

#  ifndef eIO_DOUT_TURN_LEFT_TT_MCUOUT
#   define eIO_DOUT_TURN_LEFT_TT_MCUOUT (4U)
#  endif

#  ifndef eIO_DOUT_DO_LCD_BL_PWR_EN
#   define eIO_DOUT_DO_LCD_BL_PWR_EN (5U)
#  endif

#  ifndef eIO_DOUT_DO_3V3_DISP_SW_EN
#   define eIO_DOUT_DO_3V3_DISP_SW_EN (6U)
#  endif

#  ifndef eIO_DOUT_AMP_SHTD
#   define eIO_DOUT_AMP_SHTD (7U)
#  endif

#  ifndef eIO_DOUT_FUEL_RHEO_SUP_EN
#   define eIO_DOUT_FUEL_RHEO_SUP_EN (8U)
#  endif

#  ifndef eIO_DOUT_DO_LCD_STBYB
#   define eIO_DOUT_DO_LCD_STBYB (9U)
#  endif

#  ifndef eIO_DOUT_SBATT2_EN
#   define eIO_DOUT_SBATT2_EN (10U)
#  endif

#  ifndef eIO_DOUT_BRAKE_TT_MCUOUT
#   define eIO_DOUT_BRAKE_TT_MCUOUT (11U)
#  endif

#  ifndef eIO_DOUT_AIRBAG_TT_MCUOUT
#   define eIO_DOUT_AIRBAG_TT_MCUOUT (12U)
#  endif

#  ifndef eIO_DOUT_TURN_RIGHT_TT_MCUOUT
#   define eIO_DOUT_TURN_RIGHT_TT_MCUOUT (13U)
#  endif

#  ifndef eIO_DOUT_DO_SMPS_5V_SW_EN
#   define eIO_DOUT_DO_SMPS_5V_SW_EN (14U)
#  endif

#  ifndef eIO_DOUT_PCS_OFF_TT_MCUOUT
#   define eIO_DOUT_PCS_OFF_TT_MCUOUT (15U)
#  endif

#  ifndef eIO_DOUT_ABS_TT_MCUOUT
#   define eIO_DOUT_ABS_TT_MCUOUT (16U)
#  endif

#  ifndef eIO_DOUT_SLIP_TT_MCUOUT
#   define eIO_DOUT_SLIP_TT_MCUOUT (17U)
#  endif

#  ifndef eIO_DOUT_VCS_OFF_TT_MCUOUT
#   define eIO_DOUT_VCS_OFF_TT_MCUOUT (18U)
#  endif

#  ifndef eIO_DOUT_ECB_EPB_TT_MCUOUT
#   define eIO_DOUT_ECB_EPB_TT_MCUOUT (19U)
#  endif

#  ifndef eIO_DOUT_Flasher_FL_RL_OUT
#   define eIO_DOUT_Flasher_FL_RL_OUT (20U)
#  endif

#  ifndef eIO_DOUT_Flasher_DEN1
#   define eIO_DOUT_Flasher_DEN1 (21U)
#  endif

#  ifndef eIO_DOUT_Flasher_DSEL1
#   define eIO_DOUT_Flasher_DSEL1 (22U)
#  endif

#  ifndef eIO_DOUT_Flasher_FR_RR_OUT
#   define eIO_DOUT_Flasher_FR_RR_OUT (23U)
#  endif

#  ifndef eIO_DOUT_DO_LCD_RST
#   define eIO_DOUT_DO_LCD_RST (24U)
#  endif

#  ifndef eIO_DOUT_DO_SMPS_1V2_EN
#   define eIO_DOUT_DO_SMPS_1V2_EN (25U)
#  endif

#  ifndef eIO_DO_MAX
#   define eIO_DO_MAX (26U)
#  endif

/* IoHwAb_Pwm_Cfg.c */

#  ifndef eIO_PWM_HOLD_TT_MCUOUT
#   define eIO_PWM_HOLD_TT_MCUOUT (0U)
#  endif

#  ifndef eIO_PWM_HIGH_BEAM_TT_MCUOUT
#   define eIO_PWM_HIGH_BEAM_TT_MCUOUT (1U)
#  endif

#  ifndef eIO_PWM_FUEL_TEMP_GAUG_TEXT_PWM_OUT
#   define eIO_PWM_FUEL_TEMP_GAUG_TEXT_PWM_OUT (2U)
#  endif

#  ifndef eIO_PWM_PWM_OUT_ILL2
#   define eIO_PWM_PWM_OUT_ILL2 (3U)
#  endif

#  ifndef eIO_PWM_PWM_OUT_ILL1
#   define eIO_PWM_PWM_OUT_ILL1 (4U)
#  endif

#  ifndef eIO_PWM_BG_Dimming_PWM
#   define eIO_PWM_BG_Dimming_PWM (5U)
#  endif

#  ifndef eIO_PWM_PWM_GREEN_TT_DIMMING
#   define eIO_PWM_PWM_GREEN_TT_DIMMING (6U)
#  endif

#  ifndef eIO_PWM_CXPI_CLK
#   define eIO_PWM_CXPI_CLK (7U)
#  endif

#  ifndef eIO_PWM_PWM_LCD_BL_DIMMING
#   define eIO_PWM_PWM_LCD_BL_DIMMING (8U)
#  endif

#  ifndef eIO_PWM_MAX
#   define eIO_PWM_MAX (9U)
#  endif

/* IoHwAb_Adc_Cfg.c */

#  ifndef eIO_ADC_ADC_FUEL_5V_MON
#   define eIO_ADC_ADC_FUEL_5V_MON (0U)
#  endif

#  ifndef eIO_ADC_ADC_FUEL_MAIN
#   define eIO_ADC_ADC_FUEL_MAIN (1U)
#  endif

#  ifndef eIO_ADC_IGN_AD
#   define eIO_ADC_IGN_AD (2U)
#  endif

#  ifndef eIO_ADC_FUEL_SEND_SUB_MICRO_AD
#   define eIO_ADC_FUEL_SEND_SUB_MICRO_AD (3U)
#  endif

#  ifndef eIO_ADC_AI_BATTERY
#   define eIO_ADC_AI_BATTERY (4U)
#  endif

#  ifndef eIO_ADC_AI_LCD_NTC
#   define eIO_ADC_AI_LCD_NTC (5U)
#  endif

#  ifndef eIO_ADC_AI_TEMP_RTC
#   define eIO_ADC_AI_TEMP_RTC (6U)
#  endif

#  ifndef eIO_ADC_Flasher_Diag_sense_1
#   define eIO_ADC_Flasher_Diag_sense_1 (7U)
#  endif

#  ifndef eIO_ADC_STR_SW2_ADIN
#   define eIO_ADC_STR_SW2_ADIN (8U)
#  endif

#  ifndef eIO_ADC_STR_SW1_ADIN
#   define eIO_ADC_STR_SW1_ADIN (9U)
#  endif

#  ifndef eIO_ADC_RHEO_SW_IN_ADIN
#   define eIO_ADC_RHEO_SW_IN_ADIN (10U)
#  endif

#  ifndef eIO_ADC_ADC_RHEO_5V_MON_ADIN
#   define eIO_ADC_ADC_RHEO_5V_MON_ADIN (11U)
#  endif

#  ifndef eIO_ADC_Flasher_Diag_sense_2
#   define eIO_ADC_Flasher_Diag_sense_2 (12U)
#  endif

#  ifndef eIO_ADC_AdcChannel_Vdb
#   define eIO_ADC_AdcChannel_Vdb (13U)
#  endif

#  ifndef eIO_ADC_AdcChannel_Vtemp
#   define eIO_ADC_AdcChannel_Vtemp (14U)
#  endif

#  ifndef eIO_ADC_MAX
#   define eIO_ADC_MAX (15U)
#  endif

#define CanConf_CanHardwareObject_0_CanHardwareObject_RxStd_1_0x780_to_7FF 1u

#define CanConf_CanHardwareObject_0_CanHardwareObject_RxStd_0_0x780_to_7FF 0u

void IcuSignalNotification_DI_AL_HAZARD(void);
void IcuSignalNotification_DI_AH_IGNITION(void);
void IcuSignalNotification_DI_AL_FUEL_LID_EFI_ECU(void);
void IcuSignalNotification_DI_LCD_BL_PWR_FAULT(void);
void IcuSignalNotification_CAN_RX(void);
void IcuSignalNotification_CXPI_RX(void);
void IcuSignalNotification_TT_SHIFT_ERR(void);

void Mcu_NotificationFunction_HvLvd2(void);

/* above stubs added by anil */

#endif


#define DW1_CHANNEL_83 0

#  ifndef eSnd_NoChimeID
#   define eSnd_NoChimeID (0U)
#  endif

#  ifndef eSND_PCS_Cont_BZR
#   define eSND_PCS_Cont_BZR (1U)
#  endif

#  ifndef eSND_PCS_PBA_Notify_BZR
#   define eSND_PCS_PBA_Notify_BZR (2U)
#  endif

#  ifndef eSND_PCS_ALM_Notify_BZR
#   define eSND_PCS_ALM_Notify_BZR (3U)
#  endif

#  ifndef eSND_PCS_BRK_Inspect_BZR
#   define eSND_PCS_BRK_Inspect_BZR (4U)
#  endif

#  ifndef eSND_PCS_RAD_Adjust_BZR
#   define eSND_PCS_RAD_Adjust_BZR (5U)
#  endif

#  ifndef eSND_PCS_CAM_Adjust_BZR
#   define eSND_PCS_CAM_Adjust_BZR (6U)
#  endif

#  ifndef eSND_BRKBZ2_BZR
#   define eSND_BRKBZ2_BZR (7U)
#  endif

#  ifndef eSND_BRKBZ3_BZR
#   define eSND_BRKBZ3_BZR (8U)
#  endif

#  ifndef eSND_BRKBZ4_BZR
#   define eSND_BRKBZ4_BZR (9U)
#  endif

#  ifndef eSND_Ready_BZR
#   define eSND_Ready_BZR (10U)
#  endif

#  ifndef eSND_PCS_Alert_BZR
#   define eSND_PCS_Alert_BZR (11U)
#  endif

#  ifndef eSND_ACC1_BZR
#   define eSND_ACC1_BZR (12U)
#  endif

#  ifndef eSND_URSM_Approach_BZR
#   define eSND_URSM_Approach_BZR (13U)
#  endif

#  ifndef eSND_LCA_Alert_BZR
#   define eSND_LCA_Alert_BZR (14U)
#  endif

#  ifndef eSND_PKSB_Alert_BZR
#   define eSND_PKSB_Alert_BZR (15U)
#  endif

#  ifndef eSND_SEA_Open_BZR
#   define eSND_SEA_Open_BZR (16U)
#  endif

#  ifndef eSND_Cleson_FFS_BZR
#   define eSND_Cleson_FFS_BZR (17U)
#  endif

#  ifndef eSND_Cleson_FFM_BZR
#   define eSND_Cleson_FFM_BZR (18U)
#  endif

#  ifndef eSND_Cleson_RRS_BZR
#   define eSND_Cleson_RRS_BZR (19U)
#  endif

#  ifndef eSND_Cleson_RRM_BZR
#   define eSND_Cleson_RRM_BZR (20U)
#  endif

#  ifndef eSND_RCTA_Small_BZR
#   define eSND_RCTA_Small_BZR (21U)
#  endif

#  ifndef eSND_RCTA_Medium_BZR
#   define eSND_RCTA_Medium_BZR (22U)
#  endif

#  ifndef eSND_RCTA_Large_BZR
#   define eSND_RCTA_Large_BZR (23U)
#  endif

#  ifndef eSND_Cleson_FRS_BZR
#   define eSND_Cleson_FRS_BZR (24U)
#  endif

#  ifndef eSND_Cleson_FRM_BZR
#   define eSND_Cleson_FRM_BZR (25U)
#  endif

#  ifndef eSND_Cleson_RCTA_BZR
#   define eSND_Cleson_RCTA_BZR (26U)
#  endif

#  ifndef eSND_PCS_Ped_LRTurn_BZR
#   define eSND_PCS_Ped_LRTurn_BZR (27U)
#  endif

#  ifndef eSND_FCTA_Alert_BZR
#   define eSND_FCTA_Alert_BZR (28U)
#  endif

#  ifndef eSND_Emergency_Stop9_BZR
#   define eSND_Emergency_Stop9_BZR (29U)
#  endif

#  ifndef eSND_Emergency_Stop6_BZR
#   define eSND_Emergency_Stop6_BZR (30U)
#  endif

#  ifndef eSND_Emergency_Stop8_BZR
#   define eSND_Emergency_Stop8_BZR (31U)
#  endif

#  ifndef eSND_Emergency_Stop5_BZR
#   define eSND_Emergency_Stop5_BZR (32U)
#  endif

#  ifndef eSND_Emergency_Stop3_BZR
#   define eSND_Emergency_Stop3_BZR (33U)
#  endif

#  ifndef eSND_Cleson_FFL_BZR
#   define eSND_Cleson_FFL_BZR (34U)
#  endif

#  ifndef eSND_Cleson_RRL_BZR
#   define eSND_Cleson_RRL_BZR (35U)
#  endif

#  ifndef eSND_Cleson_FRL_BZR
#   define eSND_Cleson_FRL_BZR (36U)
#  endif

#  ifndef eSND_LTA_Hands_Off_Pattern6_BZR
#   define eSND_LTA_Hands_Off_Pattern6_BZR (37U)
#  endif

#  ifndef eSND_ENG_PWR_PUSH_BZR
#   define eSND_ENG_PWR_PUSH_BZR (38U)
#  endif

#  ifndef eSND_FCTA_Step_Stop_BZR
#   define eSND_FCTA_Step_Stop_BZR (39U)
#  endif

#  ifndef eSND_SCB_Operation_BZR
#   define eSND_SCB_Operation_BZR (40U)
#  endif

#  ifndef eSND_BSM_Warning_BZR
#   define eSND_BSM_Warning_BZR (41U)
#  endif

#  ifndef eSND_Lane_Dep_Alert4_BZR
#   define eSND_Lane_Dep_Alert4_BZR (42U)
#  endif

#  ifndef eSND_URSM_Brake_BZR
#   define eSND_URSM_Brake_BZR (43U)
#  endif

#  ifndef eSND_Emergency_Stop2_BZR
#   define eSND_Emergency_Stop2_BZR (44U)
#  endif

#  ifndef eSND_Emergency_Stop4_BZR
#   define eSND_Emergency_Stop4_BZR (45U)
#  endif

#  ifndef eSND_Emergency_Stop1_BZR
#   define eSND_Emergency_Stop1_BZR (46U)
#  endif

#  ifndef eSND_Smartkey_System6_BZR
#   define eSND_Smartkey_System6_BZR (47U)
#  endif

#  ifndef eSND_PDA_Warning_BZR
#   define eSND_PDA_Warning_BZR (48U)
#  endif

#  ifndef eSND_RSA_ADAS3_BZR
#   define eSND_RSA_ADAS3_BZR (49U)
#  endif

#  ifndef eSND_Cleson_FFXL_BZR
#   define eSND_Cleson_FFXL_BZR (50U)
#  endif

#  ifndef eSND_Cleson_RRXL_BZR
#   define eSND_Cleson_RRXL_BZR (51U)
#  endif

#  ifndef eSND_Cleson_FRXL_BZR
#   define eSND_Cleson_FRXL_BZR (52U)
#  endif

#  ifndef eSND_BRLV_BZR
#   define eSND_BRLV_BZR (53U)
#  endif

#  ifndef eSND_Reservoir_Level_Warning_BZR
#   define eSND_Reservoir_Level_Warning_BZR (54U)
#  endif

#  ifndef eSND_EPS_Stop_BZR
#   define eSND_EPS_Stop_BZR (55U)
#  endif

#  ifndef eSND_EngineStall_WhileDrive_BZR
#   define eSND_EngineStall_WhileDrive_BZR (56U)
#  endif

#  ifndef eSND_Enginestall_Run_BZR
#   define eSND_Enginestall_Run_BZR (57U)
#  endif

#  ifndef eSND_Stepping_ACC_N_BZR
#   define eSND_Stepping_ACC_N_BZR (58U)
#  endif

#  ifndef eSND_HS_P_Range_Warning_BZR
#   define eSND_HS_P_Range_Warning_BZR (59U)
#  endif

#  ifndef eSND_High_WaterTemp_BZR
#   define eSND_High_WaterTemp_BZR (60U)
#  endif

#  ifndef eSND_Accel_HoldWrn_BZR
#   define eSND_Accel_HoldWrn_BZR (61U)
#  endif

#  ifndef eSND_RSA_ADAS2_BZR
#   define eSND_RSA_ADAS2_BZR (62U)
#  endif

#  ifndef eSND_HV_System_Ready_Off_BZR
#   define eSND_HV_System_Ready_Off_BZR (63U)
#  endif

#  ifndef eSND_Emergency_Stop7_BZR
#   define eSND_Emergency_Stop7_BZR (64U)
#  endif

#  ifndef eSND_LowOil_Pressure_BZR
#   define eSND_LowOil_Pressure_BZR (65U)
#  endif

#  ifndef eSND_Hybrid_SysMalfunction_Alert2_BZR
#   define eSND_Hybrid_SysMalfunction_Alert2_BZR (66U)
#  endif

#  ifndef eSND_BCS_Malfunction_BZR
#   define eSND_BCS_Malfunction_BZR (67U)
#  endif

#  ifndef eSND_Hybrid_SysMalfunction_Alert3_BZR
#   define eSND_Hybrid_SysMalfunction_Alert3_BZR (68U)
#  endif

#  ifndef eSND_Hybrid_SysMalfunction_Alert4_BZR
#   define eSND_Hybrid_SysMalfunction_Alert4_BZR (69U)
#  endif

#  ifndef eSND_EPB_Dragging_BZR
#   define eSND_EPB_Dragging_BZR (70U)
#  endif

#  ifndef eSND_IG_OFF_BZR
#   define eSND_IG_OFF_BZR (71U)
#  endif

#  ifndef eSND_SportShift_Reject_BZR
#   define eSND_SportShift_Reject_BZR (72U)
#  endif

#  ifndef eSND_Shiftposition_BZR
#   define eSND_Shiftposition_BZR (73U)
#  endif

#  ifndef eSND_ACC2_BZR
#   define eSND_ACC2_BZR (74U)
#  endif

#  ifndef eSND_LTA_Cancel_BZR
#   define eSND_LTA_Cancel_BZR (75U)
#  endif

#  ifndef eSND_LCA_Cancel_BZR
#   define eSND_LCA_Cancel_BZR (76U)
#  endif

#  ifndef eSND_Hybrid_EVMode_Alert_BZR
#   define eSND_Hybrid_EVMode_Alert_BZR (77U)
#  endif

#  ifndef eSND_Hybrid_EVMode_Alert2_BZR
#   define eSND_Hybrid_EVMode_Alert2_BZR (78U)
#  endif

#  ifndef eSND_Hybrid_EVMode_Alert3_BZR
#   define eSND_Hybrid_EVMode_Alert3_BZR (79U)
#  endif

#  ifndef eSND_Hybrid_EVMode_Alert4_BZR
#   define eSND_Hybrid_EVMode_Alert4_BZR (80U)
#  endif

#  ifndef eSND_Hybrid_EVMode_Alert5_BZR
#   define eSND_Hybrid_EVMode_Alert5_BZR (81U)
#  endif

#  ifndef eSND_Hybrid_EVMode_Alert6_BZR
#   define eSND_Hybrid_EVMode_Alert6_BZR (82U)
#  endif

#  ifndef eSND_Hybrid_EVMode_Alert7_BZR
#   define eSND_Hybrid_EVMode_Alert7_BZR (83U)
#  endif

#  ifndef eSND_Hybrid_EVMode_Alert8_BZR
#   define eSND_Hybrid_EVMode_Alert8_BZR (84U)
#  endif

#  ifndef eSND_Hybrid_EVMode_Alert9_BZR
#   define eSND_Hybrid_EVMode_Alert9_BZR (85U)
#  endif

#  ifndef eSND_SEA_Control_BZR
#   define eSND_SEA_Control_BZR (86U)
#  endif

#  ifndef eSND_TSMODE_Reject_BZR
#   define eSND_TSMODE_Reject_BZR (87U)
#  endif

#  ifndef eSND_TSMODE_Accept_BZR
#   define eSND_TSMODE_Accept_BZR (88U)
#  endif

#  ifndef eSND_EngineStop_whenstopped_BZR
#   define eSND_EngineStop_whenstopped_BZR (89U)
#  endif

#  ifndef eSND_Enginestall_Stop_BZR
#   define eSND_Enginestall_Stop_BZR (90U)
#  endif

#  ifndef eSND_LTA_HandsOff_Pattern5_BZR
#   define eSND_LTA_HandsOff_Pattern5_BZR (91U)
#  endif

#  ifndef eSND_Smartkey_System4_BZR
#   define eSND_Smartkey_System4_BZR (92U)
#  endif

#  ifndef eSND_Smartkey_System1_BZR
#   define eSND_Smartkey_System1_BZR (93U)
#  endif

#  ifndef eSND_User_N_Position_BZR
#   define eSND_User_N_Position_BZR (94U)
#  endif

#  ifndef eSND_Stop_Start_System_BZR
#   define eSND_Stop_Start_System_BZR (95U)
#  endif

#  ifndef eSND_Lane_Dep_Alert2_BZR
#   define eSND_Lane_Dep_Alert2_BZR (96U)
#  endif

#  ifndef eSND_ACC3_BZR
#   define eSND_ACC3_BZR (97U)
#  endif

#  ifndef eSND_AT_Reverse_BZR
#   define eSND_AT_Reverse_BZR (98U)
#  endif

#  ifndef eSND_ACC4_BZR
#   define eSND_ACC4_BZR (99U)
#  endif

#  ifndef eSND_ACC6_BZR
#   define eSND_ACC6_BZR (100U)
#  endif

#  ifndef eSND_RSA_ADAS1_BZR
#   define eSND_RSA_ADAS1_BZR (101U)
#  endif

#  ifndef eSND_Monitor_Warning2_BZR
#   define eSND_Monitor_Warning2_BZR (102U)
#  endif

#  ifndef eSND_Drowsiness_Notification_BZR
#   define eSND_Drowsiness_Notification_BZR (103U)
#  endif

#  ifndef eSND_SPEED_ALARM_VAR2_BZR
#   define eSND_SPEED_ALARM_VAR2_BZR (104U)
#  endif

#  ifndef eSND_MNE_BZR
#   define eSND_MNE_BZR (105U)
#  endif

#  ifndef eSND_Driving_with_Door_Ajar_BZR
#   define eSND_Driving_with_Door_Ajar_BZR (106U)
#  endif

#  ifndef eSND_BRKBZ7_BZR
#   define eSND_BRKBZ7_BZR (107U)
#  endif

#  ifndef eSND_BRKBZ8_BZR
#   define eSND_BRKBZ8_BZR (108U)
#  endif

#  ifndef eSND_BRKBZ1_BZR
#   define eSND_BRKBZ1_BZR (109U)
#  endif

#  ifndef eSND_HV_UnitOverHeated_BZR
#   define eSND_HV_UnitOverHeated_BZR (110U)
#  endif

#  ifndef eSND_Hybrid_SysMalfunction_Alert5_BZR
#   define eSND_Hybrid_SysMalfunction_Alert5_BZR (111U)
#  endif

#  ifndef eSND_IG_OFF_While_Driving_BZR
#   define eSND_IG_OFF_While_Driving_BZR (112U)
#  endif

#  ifndef eSND_Hybrid_SysMalfunction_Alert6_BZR
#   define eSND_Hybrid_SysMalfunction_Alert6_BZR (113U)
#  endif

#  ifndef eSND_LTA_HandsOff_Pattern4_BZR
#   define eSND_LTA_HandsOff_Pattern4_BZR (114U)
#  endif

#  ifndef eSND_LTA_HandsOff_Pattern7_BZR
#   define eSND_LTA_HandsOff_Pattern7_BZR (115U)
#  endif

#  ifndef eSND_Speed_Alarm_VAR1_BZR
#   define eSND_Speed_Alarm_VAR1_BZR (116U)
#  endif

#  ifndef eSND_GPF_System_BZR
#   define eSND_GPF_System_BZR (117U)
#  endif

#  ifndef eSND_Engine_Malfunction_BZR
#   define eSND_Engine_Malfunction_BZR (118U)
#  endif

#  ifndef eSND_LTA_HandsOff_Pattern3_BZR
#   define eSND_LTA_HandsOff_Pattern3_BZR (119U)
#  endif

#  ifndef eSND_Monitor_Warning1_BZR
#   define eSND_Monitor_Warning1_BZR (120U)
#  endif

#  ifndef eSND_EPS_Limit_BZR
#   define eSND_EPS_Limit_BZR (121U)
#  endif

#  ifndef eSND_Hybrid_SysMalfunction_Alert1_BZR
#   define eSND_Hybrid_SysMalfunction_Alert1_BZR (122U)
#  endif

#  ifndef eSND_URSM_End_BZR
#   define eSND_URSM_End_BZR (123U)
#  endif

#  ifndef eSND_LCA_Accept_BZR
#   define eSND_LCA_Accept_BZR (124U)
#  endif

#  ifndef eSND_URSM_Cancel_BZR
#   define eSND_URSM_Cancel_BZR (125U)
#  endif

#  ifndef eSND_Master_Caution_BZR
#   define eSND_Master_Caution_BZR (126U)
#  endif

#  ifndef eSND_KEY_REMAINER_BZR
#   define eSND_KEY_REMAINER_BZR (127U)
#  endif

#  ifndef eSND_Light_Remainder_BZR
#   define eSND_Light_Remainder_BZR (128U)
#  endif

#  ifndef eSND_ACC7_BZR
#   define eSND_ACC7_BZR (129U)
#  endif

#  ifndef eSND_Lane_Departure_Alert1_BZR
#   define eSND_Lane_Departure_Alert1_BZR (130U)
#  endif

#  ifndef eSND_Traction_Battery_Inspect_BZR
#   define eSND_Traction_Battery_Inspect_BZR (131U)
#  endif

#  ifndef eSND_TPMS_Warning_BZR
#   define eSND_TPMS_Warning_BZR (132U)
#  endif

#  ifndef eSND_Lane_Departure_Alert3_BZR
#   define eSND_Lane_Departure_Alert3_BZR (133U)
#  endif

#  ifndef eSND_SmartKey_System3_BZR
#   define eSND_SmartKey_System3_BZR (134U)
#  endif

#  ifndef eSND_Traction_InvCircuit_Short_BZR
#   define eSND_Traction_InvCircuit_Short_BZR (135U)
#  endif

#  ifndef eSND_BATCOO_BZR
#   define eSND_BATCOO_BZR (136U)
#  endif

#  ifndef eSND_Smartkey_System2_BZR
#   define eSND_Smartkey_System2_BZR (137U)
#  endif

#  ifndef eSND_RSA_Limit_BZR
#   define eSND_RSA_Limit_BZR (138U)
#  endif

#  ifndef eSND_BRKBZ9_BZR
#   define eSND_BRKBZ9_BZR (139U)
#  endif

#  ifndef eSND_BRKBZ5_BZR
#   define eSND_BRKBZ5_BZR (140U)
#  endif

#  ifndef eSND_BRKBZ6_BZR
#   define eSND_BRKBZ6_BZR (141U)
#  endif

#  ifndef eSND_LTA_HandsOff_Pattern1_BZR
#   define eSND_LTA_HandsOff_Pattern1_BZR (142U)
#  endif

#  ifndef eSND_Brake_Hold_StandBy_BZR
#   define eSND_Brake_Hold_StandBy_BZR (143U)
#  endif

#  ifndef eSND_Brake_Hold_StandBy3_BZR
#   define eSND_Brake_Hold_StandBy3_BZR (144U)
#  endif

#  ifndef eSND_Brake_Hold_StandBy4_BZR
#   define eSND_Brake_Hold_StandBy4_BZR (145U)
#  endif

#  ifndef eSND_Brake_Hold_StandBy5_BZR
#   define eSND_Brake_Hold_StandBy5_BZR (146U)
#  endif

#  ifndef eSND_Brake_Hold_StandBy6_BZR
#   define eSND_Brake_Hold_StandBy6_BZR (147U)
#  endif

#  ifndef eSND_Brake_Hold_StandBy7_BZR
#   define eSND_Brake_Hold_StandBy7_BZR (148U)
#  endif

#  ifndef eSND_Brake_Hold_StandBy8_BZR
#   define eSND_Brake_Hold_StandBy8_BZR (149U)
#  endif

#  ifndef eSND_Brake_Hold_StandBy9_BZR
#   define eSND_Brake_Hold_StandBy9_BZR (150U)
#  endif

#  ifndef eSND_Brake_Hold_StandBy2_BZR
#   define eSND_Brake_Hold_StandBy2_BZR (151U)
#  endif

#  ifndef eSND_LTA_HandsOff_Pattern2_BZR
#   define eSND_LTA_HandsOff_Pattern2_BZR (152U)
#  endif

#  ifndef eSND_ACC5_BZR
#   define eSND_ACC5_BZR (153U)
#  endif

#  ifndef eSND_Personal_Setting1_BZR
#   define eSND_Personal_Setting1_BZR (154U)
#  endif

#  ifndef eSND_Personal_Setting2_BZR
#   define eSND_Personal_Setting2_BZR (155U)
#  endif

#  ifndef eSND_Personal_Setting3_BZR
#   define eSND_Personal_Setting3_BZR (156U)
#  endif

#  ifndef eSND_Smartkey_System5_BZR
#   define eSND_Smartkey_System5_BZR (157U)
#  endif

#  ifndef eSND_Flasher_ON_BZR
#   define eSND_Flasher_ON_BZR (158U)
#  endif

#  ifndef eSND_Flasher_OFF_BZR
#   define eSND_Flasher_OFF_BZR (159U)
#  endif

#  ifndef eSND_SBR_Legally_Req_BZR
#   define eSND_SBR_Legally_Req_BZR (160U)
#  endif

#  ifndef eSND_SBR_Level2_BZR
#   define eSND_SBR_Level2_BZR (161U)
#  endif

#  ifndef eSND_SBR_Level1_BZR
#   define eSND_SBR_Level1_BZR (162U)
#  endif

#  ifndef eSND_SBR_UnBuckled_Notify_BZR
#   define eSND_SBR_UnBuckled_Notify_BZR (163U)
#  endif

#  ifndef eSND_Count
#   define eSND_Count (164U)
#  endif

#  ifndef eSndChnStat_Idle
#   define eSndChnStat_Idle (0U)
#  endif

#  ifndef eSndChnStat_Tone
#   define eSndChnStat_Tone (1U)
#  endif

#  ifndef eSndChnStat_DeadTime
#   define eSndChnStat_DeadTime (2U)
#  endif

#  ifndef eSndChnStat_DmaFault
#   define eSndChnStat_DmaFault (3U)
#  endif

#  ifndef eSndChnStat_SafetyChimeFailed
#   define eSndChnStat_SafetyChimeFailed (4U)
#  endif

#  ifndef eSndChnStat_ValidatingCrc
#   define eSndChnStat_ValidatingCrc (5U)
#  endif

#  ifndef eSndChnStat_ValidatingDMAChannel
#   define eSndChnStat_ValidatingDMAChannel (6U)
#  endif

#  ifndef eSndChnStat_ValidatingChime
#   define eSndChnStat_ValidatingChime (7U)
#  endif

#  ifndef eSndChnStat_Max
#   define eSndChnStat_Max (8U)
#  endif

#  ifndef eSndCdd_InterruptType_None
#   define eSndCdd_InterruptType_None (0U)
#  endif

#  ifndef eSndCdd_InterruptType_TypeA
#   define eSndCdd_InterruptType_TypeA (1U)
#  endif

#  ifndef eSndCdd_InterruptType_TypeB
#   define eSndCdd_InterruptType_TypeB (2U)
#  endif

#  ifndef eSndCdd_InterruptType_TypeDA
#   define eSndCdd_InterruptType_TypeDA (3U)
#  endif

#  ifndef eSndCdd_InterruptType_TypeDB
#   define eSndCdd_InterruptType_TypeDB (4U)
#  endif

#  ifndef eSndCdd_InterruptType_Immidiate
#   define eSndCdd_InterruptType_Immidiate (5U)
#  endif

#  ifndef eSndCdd_InterruptType_Tone
#   define eSndCdd_InterruptType_Tone (6U)
#  endif

#  ifndef eSndCdd_InterruptType_SoundUnit
#   define eSndCdd_InterruptType_SoundUnit (7U)
#  endif

# define Rte_TypeDef_ESndChnStat
typedef uint8 ESndChnStat;

#  ifndef eSND_Diag_1
#   define eSND_Diag_1 (1U)
#  endif

#  ifndef eSND_Diag_2
#   define eSND_Diag_2 (2U)
#  endif

#  ifndef eSND_Diag_3
#   define eSND_Diag_3 (3U)
#  endif
#  ifndef eSND_Diag_4
#   define eSND_Diag_4 (4U)
#  endif
#  ifndef eSND_Diag_5
#   define eSND_Diag_5 (5U)
#  endif
#  ifndef eSND_Diag_6
#   define eSND_Diag_6 (6U)
#  endif
#  ifndef eSND_Diag_7
#   define eSND_Diag_7 (7U)
#  endif
#  ifndef eSND_Diag_8
#   define eSND_Diag_8 (8U)
#  endif
#  ifndef eSND_Diag_9
#   define eSND_Diag_9 (9U)
#  endif
#  ifndef eSND_Diag_10
#   define eSND_Diag_10 (10U)
#  endif
#  ifndef eSND_Diag_11
#   define eSND_Diag_11 (11U)
#  endif
#  ifndef eSND_Diag_12
#   define eSND_Diag_12 (12U)
#  endif
#  ifndef eSND_Diag_13
#   define eSND_Diag_13 (13U)
#  endif

/* temporory perpouse */

#  ifndef eIO_DOUT_DO_MCU_TFT_BLPWR_EN
#   define eIO_DOUT_DO_MCU_TFT_BLPWR_EN (3U)
#  endif

/* temporory perpouse */





