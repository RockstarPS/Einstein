/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/
# ifndef UPDd_H
# define UPDd_H

void UPDd_AdapterInit (void);

// extern void  UPDd_SetDefaultManifest(tUPDdManifest* pManifest); 
extern Std_ReturnType  UPDd_RequestNvmWrite(uint8 address,uint8 size,uint8 *data);
extern Std_ReturnType UPDd_RequestNvmRead(uint8 address,uint8 size,uint8 *data);
extern uint32 UpDdi_GetEraseSize(uint32 address);
extern Std_ReturnType UPDd_GetInitialIV(uint8* IVBufferAddr);
Std_ReturnType UPDd_GetInactiveBank(tUPDiPartitionGroup* this, tUPDiPartition* pBank);


# endif /*UPDd_H*/
