/******************************************************************************
**              CONFIDENTIAL VISTEON CORPORATION
**
** This is an unpublished work of authorship, which contains trade secrets,
** created in 2012. Visteon Corporation owns all rights to this work and
** intends to maintain it in confidence to preserve its trade secret status.
** Visteon Corporation reserves the right, under the copyright laws of the
** United States or those of any other country that may have  jurisdiction,
** to protect this work as an unpublished work, in the event of an
** inadvertent or deliberate unauthorized publication. Visteon Corporation
** also reserves its rights under all copyright laws to protect this work as
** a published work, when appropriate. Those having access to this work may
** not copy it, use it, modify it or disclose the information contained in
** it without the written authorization of Visteon Corporation
**
******************************************************************************/

/******************************************************************************

File Name        :  Os_Cfg.h
Module Short Name:  Os_Cfg.h
VOBName          :  
Author           :  
Description      :  Generated File
Organization     :  Driver Information Software Section,
                    Visteon Corporation

******************************************************************************/

#ifndef OS_CFG_H
#define OS_CFG_H


/*****************************************************************************
*                            Include files                                   *
*****************************************************************************/
                                                                              
#include "OsMain.h"


                                                                              
                                                                              
/*****************************************************************************
*                                 Macro Definitions                          *
*----------------------------------------------------------------------------*
* Definition of macro shall be followed by a comment that explains the       *
* purpose of the macro.                                                      *
*****************************************************************************/

#define OS_CFG_OS_STATUS               OS_STATUS_EXTENDED

#define MOS_VERSION_INFO_API           STD_ON

#define MOS_USE_SCHED_LOG              STD_OFF

#define OS_TESTING_LOCAL               STD_OFF



/******** OS Hook Routines are Enabled *************************************/
#define OS_CFG_SUPPORT_DBG_HOOKS
#define OS_ENABLE_OSAPI_ERR_HOOK

#define OS_API_ERROR_HOOK(x,y)          //pouplate user defined error hook here


/******** OS MemMap are Enabled *******************************/
#define OS_CFG_MEMMAP_ENABLED


/* OS SC3 Functionalities is STD_ON or STD_OFF */
#define OS_CFG_MEMORY_PROTECTION     STD_ON

#define OS_CFG_MPU_SWITCH_APP        STD_ON

#define OS_CFG_MPU_SWITCH_OBJ        STD_OFF


#define OsNumberOfCores             1U
#define OsNumberOfApplications      2U
#define OsNumberOfTrustedFns        1U
#define OS_CFG_TRUSTED_CALL_ID_0     0
#define OsMaxAccessGroupIds         2U
#define OsNumberOfMPURegions_0      15
#define OsNumberOfMPURegions_1      15


/* CoreId Type */
#define OS_CFG_CORE_CORE_0        OsCoreAsr0
#define OsCoreAsr0             0UL
#define OS_CFG_CORE_COREINVALID               1UL


/* Application Type  */
#define OS_CFG_OSAPPLICATION_TRUSTEDSYSTEM            0UL
#define OS_CFG_OSAPPLICATION_QM            1UL
#define OS_CFG_APPLICATION_INVALID      0xFFU


/* AccessRightsIdType */
#define OS_CFG_MPU_REGION_0      0UL
#define OS_CFG_MPU_REGION_1      1UL
#define OS_CFG_MPU_REGION_INVALID       0xFFFFFFFFU


#define OS_CFG_MPU_STACK_REGION_NUM     0


/* Num of applications in core */
#define OsNumberOfApplicationsCore0        2


/* OsApp count accessing given resource */
#define OsNumberOfApplicationsSchedRes0    2


#define OsNumberOfTasks              5U
#define OsNumberOfAlarms             3U
#define OsMaxPriorityLevel           5U
#define OsNumberOfAutoStartTasks     2
#define osMaxCounterId               2U
#define OsNumberOfIsr                2U
#define OsMaxNumOfObjectId           (OsNumberOfTasks + OsNumberOfIsr)
#define OsNumberOfRes                1U


/* Resource IDs */


#define OsCounter_0                         ((CounterType) 0)
#define OsCounter_1                         ((CounterType) 1)


#define osdTimerReloadValue          
#define osdTimerChannel              
#define CC_TYPE                      ECC1
#define OS_MS2TICKS_SystemTimer(x)     ( (TickType) (((((uint32)(x)) * 1) + 0) / 1) )


/*****************************************************************************
*                        Task Ids                                            *
*****************************************************************************/
#define InitTask                  ((TaskType)0)
#define OsTask_IdleTask                  ((TaskType)1)
#define OsTask_NvM_EventPeriodic_0                  ((TaskType)2)
#define OsTask_Wdg_EventPeriodic_0                  ((TaskType)3)
#define OsTask_Bsw_EventPeriodic_0                  ((TaskType)4)


/* Object Names */
/* Task Object Names */
#define Object_InitTask            ((ObjectIdType)0)
#define Object_OsTask_IdleTask            ((ObjectIdType)1)
#define Object_OsTask_NvM_EventPeriodic_0            ((ObjectIdType)2)
#define Object_OsTask_Wdg_EventPeriodic_0            ((ObjectIdType)3)
#define Object_OsTask_Bsw_EventPeriodic_0            ((ObjectIdType)4)


/* Isr Object Names */
#define Object_SystemTimerISR            ((ObjectIdType)5)
#define Object_CAN0_ISR            ((ObjectIdType)6)
#define Object_ObjectIdMax        ((ObjectIdType)7)


/* Object Ids */
#define Os_Object_Id_0          Object_InitTask
#define Os_Object_Id_1          Object_OsTask_IdleTask
#define Os_Object_Id_2          Object_OsTask_NvM_EventPeriodic_0
#define Os_Object_Id_3          Object_OsTask_Wdg_EventPeriodic_0
#define Os_Object_Id_4          Object_OsTask_Bsw_EventPeriodic_0
#define Os_Object_Id_5          Object_SystemTimerISR
#define Os_Object_Id_6          Object_CAN0_ISR


/* Alarms */

#define   Rte_Al_TE2_OsTask_Bsw_EventPeriodic_0_0_10ms (0U)
#define   Rte_Al_TE2_OsTask_NvM_EventPeriodic_0_0_10ms (1U)
#define   Rte_Al_TE2_OsTask_Wdg_EventPeriodic_0_0_500ms (2U)


/* Events */

# define Rte_Ev_Cyclic2_OsTask_Bsw_EventPeriodic_0_0_10ms     ((EventMaskType)1ULL)
# define Rte_Ev_Cyclic2_OsTask_NvM_EventPeriodic_0_0_10ms  ((EventMaskType)2ULL)
# define Rte_Ev_Run_NvBlockSwComponentType_NvBlockSwComponentTypeRunnable   ((EventMaskType)4ULL)
# define Rte_Ev_Cyclic2_OsTask_Wdg_EventPeriodic_0_0_500ms  ((EventMaskType)8ULL)


/* Schedule Tables */
#define MainScheduleTable_OsTask_NvM_Stack (0U)
/*****************************************************************************
*                           Auto Start Task Ids                              *
******************************************************************************/
#define OsTaskAutoStart_0                InitTask
#define OsTaskAutoStart_1                OsTask_IdleTask


/*****************************************************************************
*                                  Task Table                                *
******************************************************************************/


/********************* Task 0*********************/

#define osStartAddressTask_0                (osTaskFuncRefType)&InitTaskfunc
#define osStackStartAddressTask_0           (osStackPtrType)osdInitTask_TOP
#define osStackSizeTask_0                   sizeof(osTaskStackOsApplication0)
#define osPrioTask_0                        3
#define osMaxActivationCount_0              1
#define osCategoryTask_0                    TASK_NONPREEMPTIVE
#define osTypeTask_0                        TASK_BASIC


/********************* Task 1*********************/

#define osStartAddressTask_1                (osTaskFuncRefType)&OsTask_IdleTaskfunc
#define osStackStartAddressTask_1           (osStackPtrType)osdOsTask_IdleTask_TOP
#define osStackSizeTask_1                   sizeof(osTaskStackOsApplication1)
#define osPrioTask_1                        4
#define osMaxActivationCount_1              1
#define osCategoryTask_1                    TASK_PREEMPTIVE
#define osTypeTask_1                        TASK_BASIC


/********************* Task 2*********************/

#define osStartAddressTask_2                (osTaskFuncRefType)&OsTask_NvM_EventPeriodic_0func
#define osStackStartAddressTask_2           (osStackPtrType)osdOsTask_NvM_EventPeriodic_0_TOP
#define osStackSizeTask_2                   sizeof(osTaskStackOsApplication2)
#define osPrioTask_2                        2
#define osMaxActivationCount_2              1
#define osCategoryTask_2                    TASK_NONPREEMPTIVE
#define osTypeTask_2                        TASK_EXTENDED


/********************* Task 3*********************/

#define osStartAddressTask_3                (osTaskFuncRefType)&OsTask_Wdg_EventPeriodic_0func
#define osStackStartAddressTask_3           (osStackPtrType)osdOsTask_Wdg_EventPeriodic_0_TOP
#define osStackSizeTask_3                   sizeof(osTaskStackOsApplication3)
#define osPrioTask_3                        0
#define osMaxActivationCount_3              1
#define osCategoryTask_3                    TASK_NONPREEMPTIVE
#define osTypeTask_3                        TASK_EXTENDED


/********************* Task 4*********************/

#define osStartAddressTask_4                (osTaskFuncRefType)&OsTask_Bsw_EventPeriodic_0func
#define osStackStartAddressTask_4           (osStackPtrType)osdOsTask_Bsw_EventPeriodic_0_TOP
#define osStackSizeTask_4                   sizeof(osTaskStackOsApplication4)
#define osPrioTask_4                        1
#define osMaxActivationCount_4              1
#define osCategoryTask_4                    TASK_NONPREEMPTIVE
#define osTypeTask_4                        TASK_EXTENDED


/*****************************************************************************
*                                 Alarm Table                                *
******************************************************************************/


/********************** Alarm 0 ***********************/
#define osCbkOfAlarm_0                    NULL
#define osTaskIdOfAlarm_0                 OsTask_Bsw_EventPeriodic_0
#define osActionOfAlarm_0                 ALARM_SET_EVENT_ACTION
#define osEventIdOfAlarm_0                Rte_Ev_Cyclic2_OsTask_Bsw_EventPeriodic_0_0_10ms
/********************** Alarm 1 ***********************/
#define osCbkOfAlarm_1                    NULL
#define osTaskIdOfAlarm_1                 OsTask_NvM_EventPeriodic_0
#define osActionOfAlarm_1                 ALARM_SET_EVENT_ACTION
#define osEventIdOfAlarm_1                Rte_Ev_Cyclic2_OsTask_NvM_EventPeriodic_0_0_10ms
/********************** Alarm 2 ***********************/
#define osCbkOfAlarm_2                    NULL
#define osTaskIdOfAlarm_2                 OsTask_Wdg_EventPeriodic_0
#define osActionOfAlarm_2                 ALARM_SET_EVENT_ACTION
#define osEventIdOfAlarm_2                Rte_Ev_Cyclic2_OsTask_Wdg_EventPeriodic_0_0_500ms


/*****************************************************************************
*                               Isr Stack Table                              *
******************************************************************************/


#define osStackStartAddressIsr_0           (osStackPtrType)osdSystemTimerISR_TOP
#define osStackSizeIsr_0                   (osStackDataType)sizeof(osLevelStackCore0Level1)

#define osStackStartAddressIsr_1           (osStackPtrType)osdCAN0_ISR_TOP
#define osStackSizeIsr_1                   (osStackDataType)sizeof(osLevelStackCore0Level1)



/*****************************************************************************
*                               Isr Configs                                  *
******************************************************************************/
/********************** Isr 0***********************/
#define osIsrId_SystemTimerISR 0UL
#define osIsrPrioLevel_SystemTimerISR 128UL
#define osIsrServiceRoutine_SystemTimerISR osTimerInterruptfunc

/********************** Isr 1***********************/
#define osIsrId_CAN0_ISR 1UL
#define osIsrPrioLevel_CAN0_ISR 128UL
#define osIsrServiceRoutine_CAN0_ISR Can_Interrupt_CANFD00_Cat2func



/* Task function prototypes */

void InitTaskfunc(void);
void OsTask_IdleTaskfunc(void);
void OsTask_NvM_EventPeriodic_0func(void);
void OsTask_Wdg_EventPeriodic_0func(void);
void OsTask_Bsw_EventPeriodic_0func(void);
extern const OsAppConfigType OsAppConfig[OsNumberOfApplications];
extern const OsAppConfigRefType OsCore0ApplicationRef[OsNumberOfApplicationsCore0];
extern const OsCoreConfigType OsCoreConfig[OsNumberOfCores];
extern const OsObjConfigType  OsObjConfig[OsMaxNumOfObjectId];
extern const OsObjConfigRefType OsApplication_TrustedSystemObjConfigRef[];
extern const OsObjConfigRefType OsApplication_QMObjConfigRef[];
extern const OsTrustedCallConfigType OsCfgTrustedCallConfig[OsNumberOfTrustedFns];
extern const OsMPUAccessGroupConfigType OsMPUAccessGroupConfig[OsMaxAccessGroupIds];
extern const OsMpuAccessGroupDiffType OsMpuAccessGroupDiff[OsMaxAccessGroupIds][OsMaxAccessGroupIds];
extern const OsIntMpuConfigType OsMpu_TrustedSystem[OsNumberOfMPURegions_0];

extern const OsIntMpuConfigType OsMpu_QMSystem[OsNumberOfMPURegions_0];

extern OsprioQueueType OsPriorityQueueDyn[OsMaxPriorityLevel];
extern const OsResConfigType OsResConfig[OsNumberOfRes];
extern const TaskPriorityType OsMaxPrioQueueCount[OsMaxPriorityLevel];



/************* OsMessage Configurations ******************************/
#define OsNumberOfTotalMessageQueues         0  /* 1,2,3,4,6 */
#define OsNumberOfRxMessages                 0  /* 0 to 6 */
#define OsNumberOfTxMessages                 0  /* 0,1,2,3,4 */
#define OsNumberOfMsgFlagNotifications       0 /* 0 */
#define OsNumberOfMsgCallbackNotifications   0 /* 2,5 */

#define OsComStartComExtension         1 /* 0 - Standard; 1 - Extended */

#if (OsNumberOfTxMessages>0)
#define osStartCOMExtension() E_OK

#if OsNumberOfMsgFlagNotifications
extern osuint8 osMsgFlags[OsNumberOfMsgFlagNotifications];
#endif
/* DataBuffer[Queue][DataLength] */
extern osuint8  OsMsgDataBuffer0[1][2];
extern osuint8  OsMsgDataBuffer1[2][2];
extern osuint8  OsMsgDataBuffer2[5][1];
extern osuint8  OsMsgDataBuffer3[5][1];
extern osuint8  OsMsgDataBuffer4[5][1];
extern osuint8  OsMsgDataBuffer5[1][2];
extern osuint8  OsMsgDataBuffer6[1][2];

extern osuint8 ReadFlag_Flag0(void);
extern void ClearFlag_Flag0(void);
#endif //OsNumberOfTxMessages

#endif    /* */
/* end of file */
/****************************************************************
Created Time: 2/5/2024 6:55:47 PM
****************************************************************/
