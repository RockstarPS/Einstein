/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

# ifndef UPD_Target_H
# define UPD_Target_H

# include "Std_Types.h"
# include "UPDd.h" // for the Manifest structure
//=====================================================================================================================
/* CONSTANTS & TYPES */
//=====================================================================================================================



//=====================================================================================================================
//  User functions
//=====================================================================================================================
// User requests
Std_ReturnType UPDTarget_CopyTo(tUPDiTarget* this, tUPDBank Bank);
Std_ReturnType UPDTarget_Deploy(tUPDiTarget* this);
Std_ReturnType UPDTarget_Verify(tUPDiTarget* this, tUPDHashingTypes HashingTypes,tUPDiHashingContext* pHashingContext);
Std_ReturnType UPDTarget_Erase(tUPDiTarget* this, tUPDBank Bank);
Std_ReturnType UPDTarget_Invalidate(tUPDiTarget* this, tUPDBank Bank);
Std_ReturnType UPDTarget_SwapBanks(tUPDiTarget* this);
Std_ReturnType UPDTarget_RequestEraseStep(tUPDiTarget* this, boolean IsFirst,tUPDBank Bank);

// accesor services
tUPDdManifest*  UPDTarget_GetManifest(tUPDiTarget* this, tUPDBank Bank);
tUPDiPartition*  UPDTarget_GetPartition(tUPDiTarget* this,tUPDBank Bank); 
tUPDiTargetState UPDTarget_GetState(tUPDiTarget* this, tUPDBank Bank);

//=====================================================================================================================
//  Triggers functions
//=====================================================================================================================
// Installation triggers
Std_ReturnType  UPDTarget_InstallStart(tUPDiTarget* this, struct sUPDiInstallSession* Session);
Std_ReturnType  UPDTarget_InstallExit(tUPDiTarget* this, struct sUPDiInstallSession* Session);
Std_ReturnType  UPDTarget_InstallData(tUPDiTarget* this, tUPDiBlockInstaller* pInstaller, uint32 pAddr, uint32 pSize, uint8* pData);

// IO triggers
Std_ReturnType UPDTarget_IoReadConf (tUPDiTarget* this, tUPDBank pBankType);
Std_ReturnType UPDTarget_IoWriteConf(tUPDiTarget* this, uint32 IoReqSize, tUPDBank pBankType);
Std_ReturnType UPDTarget_IoHashConf (tUPDiTarget* this, tUPDiHashingContext* pHashingContext);
Std_ReturnType UPDTarget_IoEraseConf(tUPDiTarget* this, tUPDBank pBankType);
void UPDTarget_IoEraseIdle(tUPDiTarget* this);

//=====================================================================================================================
//  Management functions
//=====================================================================================================================
void UPDTarget_Init(tUPDiTarget* this);
void UPDTarget_SetState(tUPDiTarget* this, tUPDiTargetState State);

#endif /*UPD_Target_H*/
