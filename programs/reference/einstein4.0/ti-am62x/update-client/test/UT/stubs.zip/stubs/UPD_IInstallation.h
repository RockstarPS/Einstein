/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/
# ifndef UPD_IInstallation_H
# define UPD_IInstallation_H

# include "UPD.h"
# include "UPDi_types.h"

//=====================================================================================================================
//  Public installation interface
//=====================================================================================================================
// FOTA or Wired update
Std_ReturnType UPD_IInstallation_TransferStart(uint32 PackageSize, tUPDiSessionID pSessionID);
Std_ReturnType UPD_IInstallation_TransferData(tUPDiSessionID SessionID, uint32 Size, uint8* data);
Std_ReturnType UPD_IInstallation_TransferExit(tUPDiSessionID SessionID);
Std_ReturnType UPD_IInstallation_Erase(uint32 PackageSize, tUPDiSessionID pSessionID);

/*FOTA only*/
/* copy related inactive partitions to active partitions.*/
Std_ReturnType UPD_IInstallation_CopyLast(char* TargetName); 
/* For all Uninstalled targets, copy all inactive partitions to active partitions.*/
Std_ReturnType UPD_IInstallation_CopyLastToAllUninstalled(void);
/* Suspend the installation session */
Std_ReturnType UPD_IInstallation_Suspend(tUPDiSessionID Id);
/* Suspend all installation sessions.*/
Std_ReturnType UPD_IInstallation_SuspendAll(void);
/* Resume an installation session.*/
Std_ReturnType UPD_IInstallation_Resume(char* PackageName);

# endif /*UPD_IInstallation_H*/
