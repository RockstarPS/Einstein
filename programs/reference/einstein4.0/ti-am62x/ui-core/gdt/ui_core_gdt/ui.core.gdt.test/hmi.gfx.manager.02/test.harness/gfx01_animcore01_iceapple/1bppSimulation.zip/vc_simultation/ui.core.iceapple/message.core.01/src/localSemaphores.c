/*============================================================================
**
**                     CONFIDENTIAL VISTEON CORPORATION
**
** This is an unpublished work of authorship, which contains trade secrets,
** created in 2001. Visteon Corporation owns all rights to this work and
** intends to maintain it in confidence to preserve its trade secret status.
** Visteon Corporation reserves the right, under the copyright laws of the
** United States or those of any other country that may have jurisdiction,
** to protect this work as an unpublished work, in the event of an
** inadvertent or deliberate unauthorized publication. Visteon Corporation
** also reserves its rights under all copyright laws to protect this work as
** a published work, when appropriate. Those having access to this work may
** not copy it, use it, modify it or disclose the information contained in
** it without the written authorization of Visteon Corporation.
**
**============================================================================
**
** Name:           localSemaphores.c
**
** Description:
**
** Organization:   Driver Information Software Section,
**                 DI Core Engineering Department
**
**==========================================================================*/
#define localSemaphores_C

/*==========================================================================*/
/*  I N C L U D E   F I L E S                                               */
/*==========================================================================*/
#include "system.h"
#include "localSemaphores.h"


/*==========================================================================*/
/* I N T E R N A L   M A C R O   A N D   T Y P E   D E F I N I T I O N S    */
/*==========================================================================*/


/*==========================================================================*/
/* I N T E R N A L   F U N C T I O N   P R O T O T Y P E S                  */
/*==========================================================================*/


/*==========================================================================*/
/* M E M O R Y   A L L O C A T I O N                                        */
/*==========================================================================*/


/*==========================================================================*/
/* E N T R Y   P O I N T S  /  D A T A   A C C E S S   S E R V I C E S      */
/*==========================================================================*/

BOOLEAN semCheckAllSemaphores(UINT8 *semBuf, UINT32 semSize)
/*============================================================================
**  Visibility:     Public (localSemaphores.h)
**----------------------------------------------------------------------------
**  Description:    Check if all semaphores are clear.
**
**  Parameters:     *semBuf:    Pointer to semaphore buffer
**                  semSize:    Number of semaphores in buffer
**
**  Returns:        FALSE:      One or more semaphores are set.
**                  TRUE:       All semaphores are clear.
**----------------------------------------------------------------------------
** Created: AFERRIS2 19/May/2009
**==========================================================================*/
{
    BOOLEAN retVal = FALSE;
    UINT32 bufIndex;

    bufIndex = BUF_SIZE(semSize);

    while (bufIndex != 0)
    {
        if(semBuf[bufIndex-1] != 0)
        {
            retVal = TRUE;
            break;
        }
        bufIndex--;
    }
    return(retVal);
}


/*==========================================================================*/
/* R E V I S I O N    N O T E S                                             */
/*==========================================================================*/
/*
** For each change to this file, be sure to record:
** 1.  Who made the change and when the change was made.
** 2.  Why the change was made and the intended result.
**
**  Date            By
**  dd Month yyyy   CDSID
**  n.  Comment
**============================================================================
**  22/Mar/2007     SCHANDR1 CQ-BSDI00040150
**  Merge from x250_aferris2_cq40150_02 branch.
**
**  20/Mar/2007             AFERRIS2
**  Initial revision for
**
**==========================================================================*/

/****************************************************************************
**  Date: 01/Jun/2009     by: AFERRIS2        Ref: 
**  Change: 1.  Changed filename (from localsem.c)
**          2.  Improve efficiency of semCheckAllSemaphores() by checking byte
**              values instead of individual semaphores. 
**
**  Checks: COMPILER - NOT CHECKED       QAC - NOT CHECKED
*****************************************************************************/

/* end of file =============================================================*/
