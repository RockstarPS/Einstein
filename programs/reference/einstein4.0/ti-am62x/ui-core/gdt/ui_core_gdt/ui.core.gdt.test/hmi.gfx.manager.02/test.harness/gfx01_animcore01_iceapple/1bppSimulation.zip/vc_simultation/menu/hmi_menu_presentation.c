/*============================================================================
**
**                     CONFIDENTIAL VISTEON CORPORATION
**
** This is an unpublished work of authorship, which contains trade secrets,
** created in 2010. Visteon Corporation owns all rights to this work and
** intends to maintain it in confidence to preserve its trade secret status.
** Visteon Corporation reserves the right, under the copyright laws of the
** United States or those of any other country that may have jurisdiction,
** to protect this work as an unpublished work, in the event of an
** inadvertent or deliberate unauthorized publication. Visteon Corporation
** also reserves its rights under all copyright laws to protect this work as
** a published work, when appropriate. Those having access to this work may
** not copy it, use it, modify it or disclose the information contained in
** it without the written authorization of Visteon Corporation.
**
**============================================================================
**
** Name:           hmi_menu_presentation.c
**
** Description:
**
** Organization:   Driver Information Software Section,
**                 Visteon
**
**============================================================================
**
**==========================================================================*/
#define HMI_MENU_PRESENTATION_C

/*============================================================================
** I N C L U D E   F I L E S
**==========================================================================*/
#include "hmi_language_interface.h"
#include "hmi_menu_core_01_logic.h"
#include "hmi_logic_state_handler.h"
//#include "hmi_gfx_mgr02_cfg.h"
//#include "hmi_gfx_mgr02_if.h"
//#include "hmi_gfx_anim_engine.h"
#include "hmi_menu_presentation.h"
//#include "hmi_menu_config_1.inc"
//#include <time.h>
/*============================================================================
** I N T E R N A L   M A C R O   A N D   T Y P E   D E F I N I T I O N S
**==========================================================================*/


/*============================================================================
** I N T E R N A L   F U N C T I O N   P R O T O T Y P E S
**==========================================================================*/

/*============================================================================
** M E M O R Y   A L L O C A T I O N
**==========================================================================*/
/*============================================================================
** E N T R Y   P O I N T S  /  D A T A   A C C E S S   S E R V I C E S
**==========================================================================*/

/*============================================================================
** Function Name:    hmi_menu_prn_hndlr
** Visibility:       global
** Description:      This is the function to display the menu screen in the
**                   Presentation.
** Invocation:       Invoked by application when ever menu screen
**                    needs to be displayed or updated
** Inputs/Outputs:   p_lsh_status_U8 indicates the activate or deactivate or refresh.
** Critical Section: None.
**==========================================================================*/
void hmi_menu_prn_hndlr(struct menu_t *hmi_menu_presentation, UINT8_T p_lsh_status_U8)
{
  if((p_lsh_status_U8 != LSH_DEACTIVATED_STATUS) && (hmi_menu_presentation !=NULL))
  {
     GfxManagerSendEvent(GFX_SCR_TUNER_BASE_BC_1, 1);
	 (void)GfxManagerSendEvent(GFX_TXT_BASE_HDR1_113W_0, 
     (UINT16)hmi_menu_const_struct_array_table[hmi_menu_presentation->menu_id].menu_header_label);
	 GfxManagerBuildScreen();
  }
  else
  {
    
  }
}



/*============================================================================
 **
 **============================================================================
 ** C M S    R E V I S I O N    N O T E S
 **============================================================================
 **
 ** For each change to this file, be sure to record:
 ** 1.  Who made the change and when the change was made.
 ** 2.  Why the change was made and the intended result.
 **
 ** CMS Rev #        Date         By
 ** CMS Rev X.X      mm/dd/yy     CDSID
 **
 **============================================================================
 **
 ** CMS Rev 1.0      19-Mar-2015    arajase2
 ** Creation.
 **==========================================================================*/

