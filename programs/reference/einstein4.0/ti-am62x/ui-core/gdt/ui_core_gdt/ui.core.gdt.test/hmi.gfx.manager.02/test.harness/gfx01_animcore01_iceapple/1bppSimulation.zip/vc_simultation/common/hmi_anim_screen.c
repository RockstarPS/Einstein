/*============================================================================
 **
 **                     CONFIDENTIAL VISTEON CORPORATION
 **
 ** This is an unpublished work of authorship, which contains trade secrets,
 ** created in 2012. Visteon Corporation owns all rights to this work and
 ** intends to maintain it in confidence to preserve its trade secret status.
 ** Visteon Corporation reserves the right, under the copyright laws of the
 ** United States or those of any other country that may have jurisdiction,
 ** to protect this work as an unpublished work, in the event of an
 ** inadvertent or deliberate unauthorized publication. Visteon Corporation
 ** also reserves its rights under all copyright laws to protect this work as
 ** a published work, when appropriate. Those having access to this work may
 ** not copy it, use it, modify it or disclose the information contained in
 ** it without the written authorization of Visteon Corporation.
 **
 **============================================================================
 **
 ** Name:          hmi_anim_screen.c
 **
 ** Description:   Implements the Animation 
 **
 ** Organization:  GUI Software Section
 **
 **============================================================================
 **
 **==========================================================================*/
#define HMI_POPUP_SCREEN_C

/*============================================================================
 ** I N C L U D E   F I L E S
 **==========================================================================*/
#include "system.h"
#include "hmi_logic_state_handler.h"
#include "hmi_animation01_core_if.h"
#include "hmi_animation01_core.h"
#include "hmi_animation01_core.cfg"


#ifdef  __cplusplus
extern "C" {
#endif
/*============================================================================
 ** I N T E R N A L   M A C R O   A N D   T Y P E   D E F I N I T I O N S
 **==========================================================================*/

/*============================================================================
 ** I N T E R N A L   F U N C T I O N   P R O T O T Y P E S
 **==========================================================================*/

/*============================================================================
 ** M E M O R Y   A L L O C A T I O N
 **==========================================================================*/

/*============================================================================
 ** E N T R Y   P O I N T S  /  D A T A   A C C E S S   S E R V I C E S
 **==========================================================================*/

	UINT8 hmi_dummy_animation_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}

UINT8 hmi_anim_fade_out_footer(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}


UINT8 hmi_anim_fade_out_header(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_anim_time_out_flip_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_anim_welcome_sleep_fade_out_anim(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_navigation_fade_out_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_navigation_fade_in_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_anim_welcome_theme2_fade_in_anim(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}


UINT8 hmi_anim_welcome_zoom_out_fade_in_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_anim_welcome_zoom_in_fade_in_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_welcome_anim_priniple_frame_fade_out_anim(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_menu_up_action_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_menu_down_action_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_list_focus_down_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_list_focus_up_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_welcome_anim_vehicle_sts_car_sliding_anim(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)

{
	return 1;
}

UINT8 hmi_welcome_anim_zoom_out_anim(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_welcome_anim_priniple_frame_shrt_fade_in_anim(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_welcome_anim_priniple_frame_fade_in_anim(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_welcome_anim_flying_window_fade_out_anim(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_welcome_anim_zoom_in_anim(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}

UINT8 hmi_welcome_anim_logo_shrt_fade_out(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_welcome_anim_logo_fade_out(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_welcome_anim_logo_HighLight_in(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_welcome_anim_logo_shrt_fade_in(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_welcome_anim_logo_fade_in(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_welcome_anim_flying_window_rolling(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_welcome_anim_flying_window_fade_in(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_level_move_dbl_wiper_animation_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_level_move_right_animation_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_level_move_left_animation_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_dimming_scale_adjust_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_anim_overlay_appear_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_overlay_disappear_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	return 1;
}
UINT8 hmi_right_overlay_appear_anim_handler(LSH_STATE_ID_T p_state_id, UINT8 p_frame_count)
{
	switch(p_frame_count)
	{
	     case 0:
           GfxManagerSendEvent(GFX_NEW_IMAGES_6_X,0);
           GfxManagerSendEvent(GFX_NEW_IMAGES_6_Y,10);
		 break;
	     case 1:
		   GfxManagerSendEvent(GFX_NEW_IMAGES_6_X,0);
           GfxManagerSendEvent(GFX_NEW_IMAGES_6_Y,20);
		 break;
		 case 2:
		   GfxManagerSendEvent(GFX_NEW_IMAGES_6_X,0);
           GfxManagerSendEvent(GFX_NEW_IMAGES_6_Y,30);	 
		 break;
		 case 3:
		   GfxManagerSendEvent(GFX_NEW_IMAGES_6_X,0);
           GfxManagerSendEvent(GFX_NEW_IMAGES_6_Y,40);	 
		 break;
		 case 4:
		   GfxManagerSendEvent(GFX_NEW_IMAGES_6_X,0);
           GfxManagerSendEvent(GFX_NEW_IMAGES_6_Y,50);
		 break;
	     default: break;
	}
	
	return 1;
}

UINT8 ui_tuner_base_presentation_handler()
{
	return 1;
}

UINT8 ui_tuner_base_focus_handler()
{
	return 1;
}

UINT8 ui_tuner_base_event_handler()
{
	return 1;
}




/*============================================================================
 **
 **============================================================================
 ** C M S    R E V I S I O N    N O T E S
 **============================================================================
 **
 ** For each change to this file, be sure to record:
 ** 1.  Who made the change and when the change was made.
 ** 2.  Why the change was made and the intended result.
 **
 ** CMS Rev #        Date         By
 ** CMS Rev X.X      mm/dd/yy     CDSID
 **
 **============================================================================
 **
 ** CMS Rev 1.0      19-Mar-2015    ADEVI
 ** Creation.
 **==========================================================================*/
#ifdef  __cplusplus
}
#endif