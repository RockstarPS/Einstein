#include <windows.h>
#include "hmi_gfx_manager.h"

UINT8 l_win1_handle;
void main(void)
{
    l_win1_handle = gls_add_layer(255, GFX_MAX_W_LENGTH, GFX_MAX_H_LENGTH, 1);
	GfxManagerInitialize();
	while(1)
	{
		if(kbhit())
		{
			char c = getch();
			switch(c)
			{
			case 27: 
				return;
			case 'a':				
				GfxManagerSendEvent(GFX_SCR_TUNER_BASE_BC_1, 0);
				GfxManagerSendEvent(GFX_SCR_TUNER_BASE_BC_1, 1);
				//GfxManagerSendText(GFX_TXT_BASE_HDR1_113W, "abcdefg");
				GfxManagerSendText(GFX_TXT_BASE_HDR1_113W_0, "Outwidgetabcdefg");
    //    GfxManagerSendEvent(GFX_FILL_SCREENS_BG_0_0_X, 300);
				//GfxManagerSendEvent(GFX_FILL_SCREENS_BG_0_0_Y, 150);
				//GfxManagerSendEvent(GFX_FILL_SCREENS_BG_0_0_W, 50);
				//GfxManagerSendEvent(GFX_FILL_SCREENS_BG_0_0_H, 50);
				//GfxManagerSendEvent(GFX_NEW_IMAGES_3_X,50);
				//GfxManagerSendEvent(GFX_NEW_IMAGES_3_Y,160);
				//GfxManagerSendEvent(GFX_TXT_BASE_HDR1_113W_X,100);
				//GfxManagerSendEvent(GFX_TXT_BASE_HDR1_113W_Y,10);
				//GfxManagerSendEvent(GFX_TXT_BASE_HDR1_113W_0_X,50);
				//GfxManagerSendEvent(GFX_TXT_BASE_HDR1_113W_0_Y,200);
				//GfxManagerSendEvent(GFX_STATIC_IMAGES_1_0_X,100);
				//GfxManagerSendEvent(GFX_STATIC_IMAGES_1_0_Y,90);
				//GfxManagerSendEvent(GFX_NEW_WIDGETS_1_X, 0);
				//GfxManagerSendEvent(GFX_NEW_WIDGETS_1_Y, 0);
				//GfxManagerSendEvent(GFX_NEW_WIDGETS_1_W, 320);
				//GfxManagerSendEvent(GFX_NEW_WIDGETS_1_H, 30);
				//GfxManagerSendEvent(GFX_TXT_BASE_HDR1_113W_0_SCROLL, 0);
				//GfxManagerSetDefaultProperties(GFX_FILL_SCREENS_BG_0_0_X);
				//GfxManagerSetDefaultProperties(GFX_FILL_SCREENS_BG_0_0_Y);
				//GfxManagerSetDefaultProperties(GFX_FILL_SCREENS_BG_0_0_W);
				//GfxManagerSetDefaultProperties(GFX_FILL_SCREENS_BG_0_0_H);
				//GfxManagerSetDefaultProperties(GFX_NEW_IMAGES_3_X);
				//GfxManagerSetDefaultProperties(GFX_NEW_IMAGES_3_Y);
			 // GfxManagerSetDefaultProperties(GFX_TXT_BASE_HDR1_113W_X);
				//GfxManagerSetDefaultProperties(GFX_TXT_BASE_HDR1_113W_Y);
				//GfxManagerSetDefaultProperties(GFX_TXT_BASE_HDR1_113W_0_X);
				//GfxManagerSetDefaultProperties(GFX_TXT_BASE_HDR1_113W_0_Y);
				//GfxManagerSetDefaultProperties(GFX_NEW_WIDGETS_1_X);
				//GfxManagerSetDefaultProperties(GFX_NEW_WIDGETS_1_Y);
				//GfxManagerSetDefaultProperties(GFX_NEW_WIDGETS_1_W);
				//GfxManagerSetDefaultProperties(GFX_NEW_WIDGETS_1_H);
				//GfxManagerSetDefaultProperties(GFX_STATIC_IMAGES_1_0_X);
				//GfxManagerSetDefaultProperties(GFX_STATIC_IMAGES_1_0_Y);
				GfxManagerBuildScreen();
				break;
			}
		}
		else
		{
              MSG  msg;
              if(GetMessage(&msg, NULL, 0, 0))
              {
                  TranslateMessage(&msg);
                  DispatchMessage(&msg);
              }
		}
	}
}
void dSetPixel(int handle, unsigned int x, unsigned int y, unsigned int color)
{
   gls_fb_write_xy(handle, x, y, color);
}

int hmi_disp_drv_data_update(void * pdisp_data)
{
   UINT16 x, y=0, cy, cx = 0;
   GFX_COLOR_T  * fl_cur_frame_buff_P = (void *)pdisp_data;
   UINT8 t_pix = *fl_cur_frame_buff_P;
#if GFX_PIX_FORMAT == GFX_4BPP
   UINT8 lpix_cnt = 2;
 #if (GFX_BIT_ORDER_LSB_FIRST==1)
   UINT8 pix_msk = 0x0F;
 #else
   UINT8 pix_msk = 0xF0;
 #endif
   UINT8 pix_sht = 0x04;
#elif GFX_PIX_FORMAT == GFX_2BPP
   UINT8 lpix_cnt = 4;
 #if (GFX_BIT_ORDER_LSB_FIRST==1)
   UINT8 pix_msk = 0x03;
 #else
   UINT8 pix_msk = 0xC0;
 #endif
   UINT8 pix_sht = 0x02;
#else
   UINT8 lpix_cnt = 8;
 #if (GFX_BIT_ORDER_LSB_FIRST==1)
   UINT8 pix_msk = 0x01;
 #else
   UINT8 pix_msk = 0x80;
 #endif
   UINT8 pix_sht = 0x01;
 #endif
   int pix_cnt;
   unsigned int pdta,pift;

#if GFX_ROTATED_IMAGES == 0   
   for(y = 0;y < (GFX_MAX_H_LENGTH); y+=lpix_cnt)
   {
      for(x = 0; x < (GFX_MAX_W_LENGTH); x++)
      {
         UINT8 pix     = *fl_cur_frame_buff_P++;
         for(pix_cnt=0;pix_cnt < lpix_cnt;pix_cnt++)
         {
            pdta = (pix & pix_msk);
         #if (GFX_BIT_ORDER_LSB_FIRST==0)
            pdta >>= (8-pix_sht);
			pdta *= 0xFF;
			pdta /= (pix_msk>>(8-pix_sht));
			pdta = (0xFF000000|pdta|(pdta<<8)+(pdta<<16));
			dSetPixel(l_win1_handle, x, y+pix_cnt, pdta);
			pix <<= pix_sht;
         #else
			pdta *= 0xFF;
			pdta /= pix_msk;
			pdta = (0xFF000000|pdta|(pdta<<8)+(pdta<<16));
            dSetPixel(l_win1_handle, x, y+pix_cnt, pdta);
			pix >>= pix_sht;
         #endif
		 }
      }
   }
#else
   for(y = 0;y < (GFX_MAX_H_LENGTH); y++)
   {
      for(x = 0; x < (GFX_MAX_W_LENGTH); x+=lpix_cnt)
      {
         UINT8 pix     = *fl_cur_frame_buff_P++;
         for(pix_cnt=0;pix_cnt < lpix_cnt;pix_cnt++)
         {
            pdta = (pix & pix_msk);
         #if (GFX_BIT_ORDER_LSB_FIRST==0)
            pdta >>= (8-pix_sht);
			pdta *= 0xFF;
			pdta /= (pix_msk>>(8-pix_sht));
			pdta = (0xFF000000|pdta|(pdta<<8)+(pdta<<16));
			dSetPixel(l_win1_handle, x+pix_cnt, y, pdta);
			pix <<= pix_sht;
         #else
			pdta *= 0xFF;
			pdta /= pix_msk;
			pdta = (0xFF000000|pdta|(pdta<<8)+(pdta<<16));
            dSetPixel(l_win1_handle, x+pix_cnt, y, pdta);
			pix >>= pix_sht;
         #endif
         }
      }
   }
#endif
   return 0;
}
