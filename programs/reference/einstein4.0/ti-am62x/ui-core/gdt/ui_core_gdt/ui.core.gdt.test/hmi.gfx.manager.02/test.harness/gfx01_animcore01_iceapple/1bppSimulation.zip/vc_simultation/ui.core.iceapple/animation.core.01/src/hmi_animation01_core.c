/*============================================================================
 **
 **                     CONFIDENTIAL VISTEON CORPORATION
 **
 ** This is an unpublished work of authorship, which contains trade secrets,
 ** created in 2010. Visteon Corporation owns all rights to this work and
 ** intends to maintain it in confidence to preserve its trade secret status.
 ** Visteon Corporation reserves the right, under the copyright laws of the
 ** United States or those of any other country that may have jurisdiction,
 ** to protect this work as an unpublished work, in the event of an
 ** inadvertent or deliberate unauthorized publication. Visteon Corporation
 ** also reserves its rights under all copyright laws to protect this work as
 ** a published work, when appropriate. Those having access to this work may
 ** not copy it, use it, modify it or disclose the information contained in
 ** it without the written authorization of Visteon Corporation.
 **
 **============================================================================
 **
 ** Name:           hmi_animation01_core.c
 **
 ** Description:    This module handles the animation sequence for
 **                 each animation.
 **
 ** Organization:   Driver Information Software Section,
 **                 Visteon
 **
 **=========================================================================================
 **
 **=======================================================================================*/
#define HMI_ANIMATION_01_CORE_C

/*=========================================================================================
 ** I N C L U D E   F I L E S
 **=======================================================================================*/
#include "system.h"
#include "hmi_logic_state_handler.h"
#include "hmi_animation01_core_if.h"
#include "hmi_animation01_core.h"
#include "hmi_animation01_core.cfg"
/*=========================================================================================
 ** I N T E R N A L   M A C R O   A N D   T Y P E   D E F I N I T I O N S
 **=======================================================================================*/
#define ANIM_MAX_NO_OF_PRIORITY_LEVEL   (LSH_NB_PRIORITY)
#define ANIM_STACK_MAX                  (5)

#define ANIM_STACK_OVERFLOW             (0x01)

typedef struct
{
    UINT16 counter;
    ANIMATION_ID anim_id;
    LSH_STATE_ID_T state_id;
    ANIM_CALLBACK_T * anim_cb_handler;
    UINT8 nextframe;
    ANIMATION_ID q_anim_id;
    LSH_STATE_ID_T q_state_id;
    ANIM_CALLBACK_T * q_anim_cb_handler;
    UINT8 anim_client_id;
    UINT8 q_anim_client_id;
}ANIM_PRIORITY_LEVEL_TYPE;

typedef struct
{
    UINT8 anim_id;
    UINT8 crnt_frame;
}ANIM_STACK_ELEMENT_T;

typedef struct
{
    UINT8 stack_index_U8;
    UINT8 status_U8;
    ANIM_STACK_ELEMENT_T element[ANIM_STACK_MAX];
}ANIM_STACK_T;
/*=========================================================================================
 ** I N T E R N A L   F U N C T I O N   P R O T O T Y P E S
 **=======================================================================================*/
static void hmi_anim01_init_animation_stack(UINT8 p_prio_U8);
static UINT8 hmi_anim01_push_stack(UINT8 p_prio_U8, UINT8 p_anim_id_U8, UINT8 p_frame_U8);
static UINT8 hmi_anim01_pop_stack(UINT8 p_prio_U8, ANIMATION_ID * p_anim_id, UINT8 * p_frame_U8);
static UINT8 hmi_anim01_is_animation_stack_empty(UINT8 p_prio_U8);
static void hmi_anim01_process_commands(UINT8 p_prio_U8, UINT8 p_anim_id_U8, UINT8 p_framecnt_U8);
static void hmi_anim01_process_simple_framesequence(UINT8 p_prio_U8, UINT8 p_anim_id_U8, UINT8 p_framecnt_U8);
static void hmi_anim01_process_interpolation_framesequence(UINT8 p_prio_U8, UINT8 p_anim_id_U8, UINT8 p_framecnt_U8);
static void hmi_anim01_process_grouped_framesequence(UINT8 p_prio_U8, UINT8 p_anim_id_U8, UINT8 p_framecnt_U8);
static void hmi_anim01_send_command(UINT16 p_cmd_U16, UINT16 p_index_U16);
static void hmi_anim01_remove_anim_from_prioirty_table(UINT8 p_prio_U8, ANIM_PRIORITY_LEVEL_TYPE *p_anim, ANIMATION_ID p_anim_id);
/*=========================================================================================
 ** M E M O R Y   A L L O C A T I O N
 **=======================================================================================*/
/*
 * This variable is used as a free running counter. The resolution of the animation depends
 * on this variable. This variable will be incremented for every scheduling of the
 * Periodic task.
*/

static UINT16 l_anim_counter_U16;

static ANIM_PRIORITY_LEVEL_TYPE l_anim_prio_table[ANIM_MAX_NO_OF_PRIORITY_LEVEL];

static ANIM_STACK_T l_anim_stack[ANIM_MAX_NO_OF_PRIORITY_LEVEL];

/*=========================================================================================
 ** E N T R Y   P O I N T S  /  D A T A   A C C E S S   S E R V I C E S
 **=======================================================================================*/
/*=========================================================================================
 ** Function Name     : hmi_anim01_intialization
 ** Visibility        : Global
 ** Description       : Init routine for the Animation Core Comp
 **                   :
 ** Invocation        : This should be invoked during COLD, WARM, WAKEUP
 **                   : initilaisation
 ** Inputs/Outputs    : None
 ** Critical Section  : None
 **=======================================================================================*/
void hmi_anim01_intialization(void)
{
    UINT8 fl_index_U8;

    l_anim_counter_U16 = 0;

    for(fl_index_U8 = 0; fl_index_U8 < ANIM_MAX_NO_OF_PRIORITY_LEVEL; fl_index_U8++)
    {
        l_anim_prio_table[fl_index_U8].counter = 0;
        l_anim_prio_table[fl_index_U8].nextframe = 0;
        l_anim_prio_table[fl_index_U8].anim_id = ANIM_MAX_ID;
        l_anim_prio_table[fl_index_U8].anim_client_id = LSH_INVALID_CLIENT_ID;
        l_anim_prio_table[fl_index_U8].anim_cb_handler = ANIM_NULL_CALLBACK_T;
        l_anim_prio_table[fl_index_U8].q_anim_id = ANIM_MAX_ID;
        l_anim_prio_table[fl_index_U8].q_anim_client_id = LSH_INVALID_CLIENT_ID;
        l_anim_prio_table[fl_index_U8].q_anim_cb_handler = ANIM_NULL_CALLBACK_T;
        l_anim_prio_table[fl_index_U8].state_id = LSH_NUMBER_OF_LOGIC_STATES;
        l_anim_prio_table[fl_index_U8].q_state_id = LSH_NUMBER_OF_LOGIC_STATES;

        hmi_anim01_init_animation_stack(fl_index_U8);
    }


}

/*=========================================================================================
 ** Function Name     : hmi_anim01_init_animation_stack
 ** Visibility        : Local
 ** Description       : Init routine for the Animation stack
 **                   :
 ** Invocation        : This should be invoked by the Animation Core comp Init routine
 **                   :
 ** Inputs/Outputs    : None
 ** Critical Section  : None
 **=======================================================================================*/
static void hmi_anim01_init_animation_stack(UINT8 p_prio_U8)
{
    UINT8 fl_index_U8;
    ANIM_STACK_T * fl_stack = &l_anim_stack[p_prio_U8];

    fl_stack->stack_index_U8 = 0;
    fl_stack->status_U8 = 0;

    for(fl_index_U8 = 0; fl_index_U8 < ANIM_STACK_MAX; fl_index_U8++)
    {
        fl_stack->element[fl_index_U8].anim_id = ANIM_MAX_ID;
        fl_stack->element[fl_index_U8].crnt_frame = 0;
    }

}


/*=========================================================================================
 ** Function Name     : hmi_anim01_periodic_task
 ** Visibility        : Global
 ** Description       : This function is should be called periodically.
 **                   : Also it issues the graphics command of a frame when the frame rate
 **                   : is met. The resolution of the frame rate is equal to the periodicity
 **                   : of this task.
 **                   :
 ** Invocation        : Periodic Task.
 **                   :
 ** Inputs/Outputs    : None
 ** Critical Section  : None
 **=======================================================================================*/
void hmi_anim01_periodic_task(void)
{
    UINT8 fl_index_U8;
    ANIMATION_ID fl_anim_id;
    ANIM_HANDLER_T  *fl_anim_handler;
    ANIM_PRIORITY_LEVEL_TYPE *fl_anim;
    UINT8 fl_break_loop_U8;
    ANIM_DATA_TYPE_T const * fl_anim_data;
    UINT8 fl_anim_handler_ret_U8 = 0;
    UINT8 fl_state_id;
    UINT8 fl_anim_client_id;
    ANIM_CALLBACK_T * fl_cb_handler;


    /* Increment the free running counter */
    l_anim_counter_U16++;

    for (fl_index_U8 = 0; fl_index_U8 < ANIM_MAX_NO_OF_PRIORITY_LEVEL; fl_index_U8++)
    {
        if ((l_anim_prio_table[fl_index_U8].anim_id != ANIM_MAX_ID) && (l_anim_prio_table[fl_index_U8].counter
                == l_anim_counter_U16))
        {
            /* Its time to execute a Frame for this animation */
            fl_anim = &l_anim_prio_table[fl_index_U8];
            fl_anim_id = fl_anim->anim_id;
            fl_anim_data = l_anim_data[fl_anim_id];

            /*Check whether there is any Animation in Q */
            if (fl_anim->q_anim_id != ANIM_MAX_ID)
            {
                if ((fl_anim_data->properties & ABORT_ON) == ABORT_ON)
                {
                    /* There another animation Queued up. Terminate this animation
                     * by executing the last frame if this animation */
                    fl_anim->nextframe = fl_anim_data->frmcount - 1;
                }
                else
                {
                    /* There is another animation in the Q. Don't worry about it
                     * as the currently playing is a non stop animation.
                     * So continue playing the current animation */
                }
            }


            /* The priority table would have changed if it is grouped animation */
            if (GROUPED_FRAME_SEQUENCER == fl_anim_data->anim_type)
            {
                /* Re-Aling the pointers */
                fl_anim = &l_anim_prio_table[fl_index_U8];
                fl_anim_id = fl_anim->anim_id;
                fl_anim_data = l_anim_data[fl_anim_id];
            }

            fl_anim_handler = fl_anim_data->anim_handler;
            if ((ANIM_HANDLER_T * )fl_anim_handler != ANIM_NULL_HANDLER_T)
            {
                fl_anim_handler_ret_U8 = (*fl_anim_handler)(fl_anim->state_id, fl_anim->nextframe);
            }

            hmi_anim01_process_commands(fl_index_U8, fl_anim_id, fl_anim->nextframe);

            if(ANIM_HNDLR_RET_TERMINATE_ANIM == fl_anim_handler_ret_U8)
            {
                /* Handler has requested for the Termination, So move the current frame to the last frame
                 * so this will get terminated */
                fl_anim->nextframe = fl_anim_data->frmcount;
            }

            fl_anim->nextframe++;
            fl_anim->counter = l_anim_counter_U16 + fl_anim_data->frmrate;

            /* Check whether the maximum Frame Count is reached only if
             * the return type of the handler function is ANIM_HNDLR_RET_INGORE_FRAME_MAX_CNT_ANIM */

            if ((ANIM_HNDLR_RET_INGORE_FRAME_MAX_CNT_ANIM != fl_anim_handler_ret_U8)
                    && (fl_anim_data->frmcount <= fl_anim->nextframe))
            {
                /* The animation has come to an end
                 * Check whether any other animation is in Q */

                if ((fl_anim->q_anim_id < ANIM_MAX_ID))
                {
                    /* Animation is completed, Notification to be sent only at the last step
                     * So Copy it to a local var as the status and callbacks will be modified
                     * after the status change */
                    fl_cb_handler = fl_anim->anim_cb_handler;
                    fl_state_id = fl_anim->state_id;
                    fl_anim_client_id = fl_anim->anim_client_id;

                    if ((fl_anim_data->properties & ABORT_ON) == ABORT_ON)
                    {
                        /* The current animation has been purposefully terminated by the new
                         * animation request. The New animation request should be processed
                         * as the current animation has executed its last frame */
                        fl_anim->anim_id = fl_anim->q_anim_id;
                        fl_anim->q_anim_id = ANIM_MAX_ID;
                        fl_anim->state_id = fl_anim->q_state_id;
                        fl_anim->q_state_id = LSH_NUMBER_OF_LOGIC_STATES;
                        fl_anim->anim_cb_handler = fl_anim->q_anim_cb_handler;
                        fl_anim->q_anim_cb_handler = ANIM_NULL_CALLBACK_T;
                        fl_anim->nextframe = 0;
                        fl_anim->counter = l_anim_counter_U16 + l_anim_data[fl_anim->anim_id]->frmrate;
                        fl_anim->anim_client_id = fl_anim->q_anim_client_id;
                        fl_anim->q_anim_client_id = LSH_INVALID_CLIENT_ID;

                        if (FALSE == hmi_anim01_is_animation_stack_empty(fl_index_U8))
                        {
                            /* Purposefully terminated animation is a grouped animation
                             * It might have some entries in the animation stack, if yes then
                             * empty the animation stack */
                            hmi_anim01_init_animation_stack(fl_index_U8);
                        }

                    }
                    else
                    {
                        /* But check for the Looping options */
                        if ((fl_anim_data->properties & LOOPING_BACK_ON) == LOOPING_BACK_ON)
                        {
                            /* Looping is enabled. Move to the first frame */
                            fl_anim->nextframe = 0;
                            fl_anim->counter = l_anim_counter_U16 + fl_anim_data->frmrate;
                        }
                        else
                        {
                            /* The current animation is completed and there is another animation
                             * waiting in the Queue for this animation to complete.
                             * Execute only the last frame of the waiting animation */
                            fl_anim->anim_id = fl_anim->q_anim_id;
                            fl_anim->q_anim_id = ANIM_MAX_ID;
                            fl_anim->state_id = fl_anim->q_state_id;
                            fl_anim->q_state_id = LSH_NUMBER_OF_LOGIC_STATES;
                            fl_anim->anim_cb_handler = fl_anim->q_anim_cb_handler;
                            fl_anim->q_anim_cb_handler = ANIM_NULL_CALLBACK_T;
                            fl_anim->counter = l_anim_counter_U16 + l_anim_data[fl_anim->anim_id]->frmrate;
                            fl_anim->anim_client_id = fl_anim->q_anim_client_id;
                            fl_anim->q_anim_client_id = LSH_INVALID_CLIENT_ID;

                            /* Check if the animation is a grouped animation Type*/
                            if(TRUE)  /* TBD */
                            {
                                /* It is not a grouped animation, So execute only the last frame
                                 * of the animation */
                                fl_anim->nextframe = l_anim_data[fl_anim->anim_id]->frmcount - 1;
                            }
                            else
                            {
                                /* Animation in the Q is a Grouped Animation.
                                 * Execute the last frame from the last animation in the group */

                            }
                        }
                    }

                    /* Animation status are updated. Notify it to the Animation Client */
                    if (fl_cb_handler != ANIM_NULL_CALLBACK_T)
                    {
                        fl_cb_handler(fl_index_U8, fl_state_id, fl_anim_id,fl_anim_client_id);
                    }

                }
                else
                {

                    /* But check for the Looping options */
                    if ((fl_anim_data->properties & LOOPING_BACK_ON) == LOOPING_BACK_ON)
                    {
                        /* Looping is enabled. Move to the first frame */
                        fl_anim->nextframe = 0;
                        fl_anim->counter = l_anim_counter_U16 + fl_anim_data->frmrate;
                    }
                    else
                    {

                        /* Animation that was just got over was a part of a groped animation
                         * There are still animation waiting in the animation stack for processing
                         * Pop out the Animation from stack and update the same in the
                         * animation priority table, so that it will get executed in the next
                         * Scheduling task */
                        if (FALSE != hmi_anim01_is_animation_stack_empty(fl_index_U8))
                        {
                            /* The stack is empty which is all the grouped/ stright animations
                             * are executed. Inform the application through call back
                             * and clear of the animation in this priority */
                            hmi_anim01_remove_anim_from_prioirty_table(fl_index_U8, fl_anim, fl_anim_id);
                        }
                        else
                        {
                            /* Part of grouped animation is complete, but still more in the stack
                             * Pop out the next animation and start the frame sequence again until
                             * the stack is emptied completely */
                            fl_break_loop_U8 = FALSE;
                            while ((FALSE == fl_break_loop_U8) &&
                                    (FALSE != hmi_anim01_pop_stack(fl_index_U8, &(fl_anim->anim_id), &(fl_anim->nextframe))))
                            {
                                fl_anim_data = l_anim_data[fl_anim->anim_id];
                                fl_anim->nextframe++;
                                if (fl_anim->nextframe < fl_anim_data->frmcount)
                                {
                                    /* There are still frames for the popuped out
                                     *  animation to perform, So break the loop*/
                                    fl_break_loop_U8 = TRUE;
                                }
                            }

                            if(FALSE == fl_break_loop_U8)
                            {
                                /* The end of animation */
                                hmi_anim01_remove_anim_from_prioirty_table(fl_index_U8, fl_anim, fl_anim_id);
                            }
                        }
                    }
                }
            }
        }
    }
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_remove_anim_from_prioirty_table
 ** Visibility        : Local
 ** Description       : This function clear the Animation id in the priority table.
 **                   :
 ** Invocation        : By the Periodic Task to clear the animation from the prio table
 **                   :
 ** Inputs/Outputs    : ANIM_PRIORITY_LEVEL_TYPE * p_anim - Pointer to the prio table
 **                   : ANIMATION_ID -  p_anim_id - Animation ID
 ** Critical Section  : None
 **=======================================================================================*/
static void hmi_anim01_remove_anim_from_prioirty_table(UINT8 p_prio_U8, ANIM_PRIORITY_LEVEL_TYPE *p_anim, ANIMATION_ID p_anim_id)
{
    UINT8 fl_state_id_U8 = p_anim->state_id;
    UINT8 fl_anim_client_id_U8 = p_anim->anim_client_id;
    ANIM_CALLBACK_T  * fl_anim_cb_handler = p_anim->anim_cb_handler;

    if (p_anim->q_anim_id != ANIM_MAX_ID)
    {
        p_anim->anim_id = p_anim->q_anim_id;
        p_anim->counter = l_anim_counter_U16 + l_anim_data[p_anim->anim_id]->frmrate;
        p_anim->anim_cb_handler = p_anim->q_anim_cb_handler;
        p_anim->state_id = p_anim->q_state_id;
        p_anim->q_anim_id = ANIM_MAX_ID;
        p_anim->q_anim_cb_handler = ANIM_NULL_CALLBACK_T;
        p_anim->q_state_id = LSH_NUMBER_OF_LOGIC_STATES;
        p_anim->nextframe = 0;
        p_anim->anim_client_id = p_anim->q_anim_client_id;
        p_anim->q_anim_client_id = LSH_INVALID_CLIENT_ID;

    }
    else
    {
        p_anim->counter = 0;
        p_anim->anim_id = ANIM_MAX_ID;
        p_anim->anim_cb_handler = ANIM_NULL_CALLBACK_T;
        p_anim->state_id = LSH_NUMBER_OF_LOGIC_STATES;
        p_anim->q_anim_id = ANIM_MAX_ID;
        p_anim->q_anim_cb_handler = ANIM_NULL_CALLBACK_T;
        p_anim->q_state_id = LSH_NUMBER_OF_LOGIC_STATES;
        p_anim->nextframe = 0;
        p_anim->anim_client_id = LSH_INVALID_CLIENT_ID;
        p_anim->q_anim_client_id = LSH_INVALID_CLIENT_ID;
    }

    if (fl_anim_cb_handler != ANIM_NULL_CALLBACK_T)
    {
        fl_anim_cb_handler(p_prio_U8, fl_state_id_U8, p_anim_id,fl_anim_client_id_U8);
    }
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_start_frame_sequence
 ** Visibility        : Global
 ** Description       : This function triggers the start of an animation
 **                   :
 ** Invocation        : Invoked by the application
 **                   :
 ** Inputs/Outputs    : p_prio_U8 - Index to the priority table
 **                   : p_state_id - State id to be added after the animation
 **                   : p_anim_id  - Index to the anim table for
 **                   : p_anim_cb_handler - Pointer to function to call when animation is over
 **                   : p_anim_client_id_U8 - client ID for which the animation call is invoked
  ** Critical Section  : None
 **=======================================================================================*/
UINT8 hmi_anim01_start_frame_sequence(UINT8 p_prio_U8, LSH_STATE_ID_T p_state_id, ANIMATION_ID p_anim_id,
        ANIM_CALLBACK_T * p_anim_cb_handler, UINT8 p_anim_client_id_U8)
{
    ANIM_PRIORITY_LEVEL_TYPE *fl_anim;
    UINT8 fl_return_U8 = FALSE;

    if (p_prio_U8 < ANIM_MAX_NO_OF_PRIORITY_LEVEL)
    {
        fl_anim = &l_anim_prio_table[p_prio_U8];

        /* Check for a valid Animation ID */
        if (p_anim_id < ANIM_MAX_ID)
        {
            /* Check for any ongoing animation */
            if (fl_anim->anim_id != ANIM_MAX_ID)
            {
                /* There is an animation already running */
                if (fl_anim->q_anim_id != ANIM_MAX_ID)
                {
                    /* There is also another animation that is queued.
                     * Replace this new animation to the Queue and
                     * call the call back function to inform that the
                     * animation that was waiting for it turn is completed */

                    if (fl_anim->q_anim_cb_handler != ANIM_NULL_CALLBACK_T)
                    {
                        fl_anim->q_anim_cb_handler(p_prio_U8, fl_anim->q_state_id, fl_anim->q_anim_id, fl_anim->q_anim_client_id);
                    }
                }

                fl_anim->q_anim_id = p_anim_id;
                fl_anim->q_state_id = p_state_id;
                fl_anim->q_anim_cb_handler = p_anim_cb_handler;
                fl_anim->q_anim_client_id = p_anim_client_id_U8;
            }
            else
            {
                /* Request for a New Animation */
                fl_anim->nextframe = 0;
                fl_anim->anim_id = p_anim_id;
                fl_anim->state_id = p_state_id;
                fl_anim->anim_cb_handler = p_anim_cb_handler;
                fl_anim->anim_client_id = p_anim_client_id_U8;
                fl_anim->counter = l_anim_counter_U16 + l_anim_data[p_anim_id]->frmrate;
                fl_anim->q_anim_id = ANIM_MAX_ID;
                fl_anim->q_anim_cb_handler =  ANIM_NULL_CALLBACK_T;
                fl_anim->q_state_id = LSH_NUMBER_OF_LOGIC_STATES;
                fl_anim->q_anim_client_id = LSH_INVALID_CLIENT_ID;

            }
            fl_return_U8 = TRUE;
        }
    }
    return(fl_return_U8);
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_stop_frame_sequence
 ** Visibility        : Global
 ** Description       : This function triggers the stops a currently active or Queued animation
 **                   :
 ** Invocation        : Invoked by the application
 **                   :
 ** Inputs/Outputs    : p_prio_U8 - Index to the priority table
 **                   : p_state_id - State id to be added after the animation
 ** Critical Section  : None
 **=======================================================================================*/
void hmi_anim01_stop_frame_sequence(UINT8 p_prio_U8, LSH_STATE_ID_T p_state_id)
{
    ANIM_PRIORITY_LEVEL_TYPE *fl_anim;
    ANIM_DATA_TYPE_T const * fl_anim_data;
    ANIM_CALLBACK_T * fl_cb_handler;
    UINT8 fl_state_id;
    ANIMATION_ID fl_anim_id;
    UINT8 fl_anim_client_id_U8;

    if (p_prio_U8 < ANIM_MAX_NO_OF_PRIORITY_LEVEL)
    {
        fl_anim = &l_anim_prio_table[p_prio_U8];


        if (fl_anim->anim_id < ANIM_MAX_ID)
        {
            fl_anim_data = l_anim_data[fl_anim->anim_id];
            /* Check for a valid Animation ID */
            /* Only ABORT ON animation can be cancelled and make
             * sure that the request if for the same state id */

            if (((fl_anim_data->properties & ABORT_ON) == ABORT_ON) &&
                    (p_state_id == fl_anim->state_id))
            {
                fl_state_id = fl_anim->state_id;
                fl_cb_handler = fl_anim->anim_cb_handler;
                fl_anim_id = fl_anim->anim_id;
                fl_anim_client_id_U8 = fl_anim->anim_client_id;

                /* Make the Queued animation to the acitive animation and clear the Queued Animation */
                fl_anim->anim_id = fl_anim->q_anim_id;
                fl_anim->nextframe = 0;
                fl_anim->anim_cb_handler = fl_anim->q_anim_cb_handler;
                fl_anim->anim_client_id = fl_anim->q_anim_client_id;
                fl_anim->state_id = fl_anim->q_state_id;
                fl_anim->q_anim_id = ANIM_MAX_ID;
                fl_anim->q_anim_cb_handler = ANIM_NULL_CALLBACK_T;
                fl_anim->q_state_id = LSH_NUMBER_OF_LOGIC_STATES;
                fl_anim->q_anim_client_id =LSH_INVALID_CLIENT_ID;

                if (fl_cb_handler != ANIM_NULL_CALLBACK_T)
                {
                    fl_cb_handler(p_prio_U8, fl_state_id, fl_anim_id, fl_anim_client_id_U8);
                }

                /* Also Initialize the Stack.*/
                hmi_anim01_init_animation_stack(p_prio_U8);

            }
        }
        else if(fl_anim->q_anim_id < ANIM_MAX_ID)
        {
            fl_anim_data = l_anim_data[fl_anim->q_anim_id];
            /* Check for a valid Animation ID */
            /* Only ABORT ON animation can be cancelled and make
             * sure that the request if for the same state id */

            if (((fl_anim_data->properties & ABORT_ON) == ABORT_ON) &&
                    (p_state_id == fl_anim->q_state_id))
            {
                fl_state_id = fl_anim->q_state_id;
                fl_cb_handler = fl_anim->q_anim_cb_handler;
                fl_anim_id = fl_anim->q_anim_id;
                fl_anim_client_id_U8 = fl_anim->q_anim_client_id;

                fl_anim->q_anim_id = ANIM_MAX_ID;
                fl_anim->q_anim_cb_handler = ANIM_NULL_CALLBACK_T;
                fl_anim->q_state_id = LSH_NUMBER_OF_LOGIC_STATES;
                fl_anim->q_anim_client_id =LSH_INVALID_CLIENT_ID;

                if (fl_cb_handler != ANIM_NULL_CALLBACK_T)
                {
                   fl_cb_handler(p_prio_U8, fl_state_id, fl_anim_id, fl_anim_client_id_U8);


                }
            }
        }
        else
        {
            /* Do Nothing */
        }
    }
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_is_frame_seqncr_active
 ** Visibility        : Global
 ** Description       : This function returns the status of an animation
 **                   :
 ** Invocation        : Invoked by the application to check on the animation status
 **                   :
 ** Inputs/Outputs    : ANIM_SEQNCR_RET_T = Animation Status
 ** Critical Section  : None
 **=======================================================================================*/
ANIM_SEQNCR_RET_T hmi_anim01_is_frame_seqncr_active(void)
{
    UINT8 fl_index_U8 = 0;
    ANIM_SEQNCR_RET_T fl_ret_U8 = ANIM_SEQNCR_INACTIVE;
    ANIM_PRIORITY_LEVEL_TYPE *fl_anim;
    for(fl_index_U8 = 0; ((fl_index_U8 < ANIM_MAX_NO_OF_PRIORITY_LEVEL) && \
            (fl_ret_U8 == ANIM_SEQNCR_INACTIVE));fl_index_U8++)
    {
        fl_anim = &l_anim_prio_table[fl_index_U8];
        if(fl_anim->anim_id != ANIM_MAX_ID)
        {
            /* An Animation is ongoing
             * exit the search */
            fl_ret_U8 = ANIM_SEQNCR_ACTIVE;

        }
    }
    return(fl_ret_U8);
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_push_stack(UINT8 p_anim_id_U8, UINT8 p_frame_U8)
 ** Visibility        : Local
 ** Description       : This function inserts an item into the animation stack.
 **                   :
 ** Invocation        : Invoked by the hmi_anim01_periodic_task
 **                   :
 ** Inputs/Outputs    : UINT8 p_anim_id_U8 - Animation ID
 **                     UINT8 p_frame_U8   - Current executing frame
 ** Critical Section  : None
 **=======================================================================================*/
static UINT8 hmi_anim01_push_stack(UINT8 p_prio_U8, UINT8 p_anim_id_U8, UINT8 p_frame_U8)
{
    UINT8 fl_return_U8 = FALSE;
    ANIM_STACK_T * fl_stack = &l_anim_stack[p_prio_U8];

    if((fl_stack->stack_index_U8) < ANIM_STACK_MAX)
    {

        /* Check for the Stack Overflow, Do not accept any item if there is a
         * an stack overflow */

        fl_stack->element[fl_stack->stack_index_U8].anim_id = p_anim_id_U8;
        fl_stack->element[fl_stack->stack_index_U8].crnt_frame = p_frame_U8;
        fl_stack->stack_index_U8++;
        fl_return_U8 = TRUE;

    }
    else
    {
        fl_stack->status_U8 |= ANIM_STACK_OVERFLOW;
    }
    return(fl_return_U8);
}

/*=========================================================================================
 ** Function Name     :  hmi_anim01_push_stack(UINT8 p_anim_id_U8, UINT8 p_frame_U8)
 ** Visibility        :  Local
 ** Description       :  This function retries the topmost entry from stack in the list for
 **                      further processing.
 **                   :
 ** Invocation        :  Invoked by the hmi_anim01_periodic_task
 **                   :
 ** Inputs/Outputs    : UINT8 p_anim_id_U8 - Animation ID
 **                     UINT8 p_frame_U8   - Current executing frame
 ** Critical Section  : None
 **=======================================================================================*/
static UINT8 hmi_anim01_pop_stack(UINT8 p_prio_U8, ANIMATION_ID * p_anim_id, UINT8 * p_frame_U8)
{
    UINT8 fl_return_U8 = FALSE;
    ANIM_STACK_T * fl_stack = &l_anim_stack[p_prio_U8];

    if (0 != fl_stack->stack_index_U8)
    {
        fl_stack->stack_index_U8--;
        *p_anim_id = fl_stack->element[fl_stack->stack_index_U8].anim_id;
        *p_frame_U8 = fl_stack->element[fl_stack->stack_index_U8].crnt_frame;
        fl_return_U8 = TRUE;
    }
    else
    {
        /* Stack is empty */
    }
    return(fl_return_U8);
}


/*=========================================================================================
 ** Function Name     : hmi_anim01_is_animation_stack_empty
 ** Visibility        : Local
 ** Description       : Return Ture is stack is empty
 **                   :
 ** Invocation        : Preiodic Task
 **                   :
 ** Inputs/Outputs    : TRUE - Stack Empty / FALSE - Stack not empty
 ** Critical Section  : None
 **=======================================================================================*/
static UINT8 hmi_anim01_is_animation_stack_empty(UINT8 p_prio_U8)
{
    UINT8 fl_return_U8 = FALSE;

    if(0 == l_anim_stack[p_prio_U8].stack_index_U8)
    {
        fl_return_U8 = TRUE;
    }
    else
    {
        fl_return_U8 = FALSE;
    }
    return(fl_return_U8);
}
/*=========================================================================================
 ** Function Name     : hmi_anim01_process_commands
 ** Visibility        : Local
 ** Description       : This function handles different command type for a frame
 **                   :
 ** Invocation        : By the Periodic Task
 **                   :
 ** Inputs/Outputs    : p_anim_id_U8   - Animation ID
 **                   : p_framecnt_U8  - Current Frame
 ** Critical Section  : None
 **=======================================================================================*/
static void hmi_anim01_process_commands(UINT8 p_prio_U8, UINT8 p_anim_id_U8, UINT8 p_framecnt_U8)
{
    ANIM_DATA_TYPE_T const *fl_anim = l_anim_data[p_anim_id_U8];

    switch (fl_anim->anim_type)
    {
        case SIMPLE_FRAME_SEQUENCE:

            hmi_anim01_process_simple_framesequence(p_prio_U8, p_anim_id_U8, p_framecnt_U8);
            break;

        case INTERPOLATION_FRAME_SEQUENCER:

            hmi_anim01_process_interpolation_framesequence(p_prio_U8, p_anim_id_U8, p_framecnt_U8);
            break;

        case GROUPED_FRAME_SEQUENCER:

            hmi_anim01_process_grouped_framesequence(p_prio_U8, p_anim_id_U8, p_framecnt_U8);
            break;

        default:
            break;
    }
}


/*=========================================================================================
 ** Function Name     : hmi_anim01_process_simple_framesequence
 ** Visibility        : Local
 ** Description       : This function handles the Simple Command Types
 **                   :
 ** Invocation        : by the command processor
 **                   :
 ** Inputs/Outputs    : p_anim_id_U8   - Animation ID
 **                   : p_framecnt_U8  - Current Frame
 ** Critical Section  : None
 **=======================================================================================*/
static void hmi_anim01_process_simple_framesequence(UINT8 p_prio_U8, UINT8 p_anim_id_U8, UINT8 p_framecnt_U8)
{
    ANIM_DATA_TYPE_T const *fl_anim = l_anim_data[p_anim_id_U8];
    ANIM_CMD_T const * fl_frame ;

    if(fl_anim->frame != NULL)
    {
        if(p_framecnt_U8 < fl_anim->frmcount)
        {
            fl_frame = (fl_anim->frame[p_framecnt_U8]);
            while (GFX_INVALID_CMD_ANIM_TYPE != fl_frame->cmd_type)
            {
                hmi_anim01_send_command(fl_frame->cmd_type, fl_frame->index);
                fl_frame ++ ;
            }

        }

    }
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_process_interpolation_framesequence
 ** Visibility        : Local
 ** Description       : This function handles the Interpolation Command Types
 **                   :
 ** Invocation        : by the command processor
 **                   :
 ** Inputs/Outputs    : p_anim_id_U8   - Animation ID
 **                   : p_framecnt_U8  - Current Frame
 ** Critical Section  : None
 **=======================================================================================*/
static void hmi_anim01_process_interpolation_framesequence(UINT8 p_prio_U8, UINT8 p_anim_id_U8, UINT8 p_framecnt_U8)
{

#ifdef ANIM_INTERPOLATION_ENABLED

    ANIM_DATA_TYPE_T const *fl_anim = l_anim_data[p_anim_id_U8];

    /* only first frame will be there for the interpolated animation */
    ANIM_CMD_T const * fl_frame = (fl_anim->frame[0]);
    UINT16 fl_start_value_U16 = 0;
    UINT16 fl_end_value_U16 = 0;
    UINT16 fl_send_value_U16 = 0;
    ANIM_INTERPOLATE_CMD_T const* fl_interpolate;
    ANIM_INTERPOLATION_CALL_BACK_T const *fl_intplt_cb;

    while (GFX_INVALID_CMD_ANIM_TYPE != fl_frame->cmd_type)
    {
        if(GFX_SEND_INTERPOLATE_ANIM_CMD == fl_frame->cmd_type)
        {
            /* Do the Interpolation for the value
             * Interpolation is applicable only for the SEND_EVENT type
             */
            if(fl_frame->index < ANIM_MAX_INTERPOLATE_OBJ)
            {

                fl_interpolate = &l_interpolate_tbl[fl_frame->index];

                if((fl_interpolate->ctype_U8 & START_POS_DYNAMIC) == START_POS_DYNAMIC)
                {
                    /* Start parameter is a Dynamic Parameter.
                     * The Start value should be fetched. The value should be fetched
                     * as a function call back from the application
                     * */
                    if(fl_interpolate->start_pos_U16 < ANIM_MAX_FUNCION_LIST)
                    {
                        fl_intplt_cb = l_function_tbl[fl_interpolate->start_pos_U16 ];
                        fl_start_value_U16 = (*fl_intplt_cb)(p_anim_id_U8, p_framecnt_U8);
                    }

                }
                else
                {
                    fl_start_value_U16 = fl_interpolate->start_pos_U16;
                }

                if((fl_interpolate->ctype_U8 & END_POS_DYNAMIC) == END_POS_DYNAMIC)
                {
                    /* End parameter is a Dynamic Parameter.
                     * The end value should be fetched. The value should be fetched
                     * as a function call back from the application
                     * */
                    if(fl_interpolate->end_pos_U16 < ANIM_MAX_FUNCION_LIST)
                    {
                        fl_intplt_cb = l_function_tbl[fl_interpolate->end_pos_U16];
                        fl_end_value_U16 = (*fl_intplt_cb)(p_anim_id_U8, p_framecnt_U8);
                    }
                }
                else
                {
                    fl_end_value_U16 = fl_interpolate->end_pos_U16;
                }

                /* Interpolate the value based on the start & end value and no of Frames */
                if(fl_start_value_U16 < fl_end_value_U16)
                {
                    /* Positive Interpolation */
                    fl_send_value_U16 = fl_start_value_U16 + (fl_end_value_U16 - fl_start_value_U16);
                }
                else
                {
                    /* Negative Interpolation */
                    fl_send_value_U16 = fl_start_value_U16 - (fl_start_value_U16 - fl_end_value_U16);
                }

                fl_send_value_U16 = (UINT16)((UINT32)(fl_send_value_U16 * (UINT16)p_framecnt_U8)) / fl_anim->frmcount;
                ANIM_SEND_EVENT_CMD(fl_interpolate->object, fl_send_value_U16);
            }
        }
        else
        {
            /* The command is not an interpolation cmd type,
             * Just a simple command */
            hmi_anim01_send_command(fl_frame->cmd_type, fl_frame->index);
        }
        fl_frame ++ ;
    }
#endif  /* #ifdef(ANIM_INTERPOLATION_ENABLED) */
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_process_grouped_framesequence
 ** Visibility        : Local
 ** Description       : This function handles the Grouped Command Types
 **                   :
 ** Invocation        : by the command processor
 **                   :
 ** Inputs/Outputs    : p_anim_id_U8   - Animation ID
 **                   : p_framecnt_U8  - Current Frame
 ** Critical Section  : None
 **=======================================================================================*/
static void hmi_anim01_process_grouped_framesequence(UINT8 p_prio_U8, UINT8 p_anim_id_U8, UINT8 p_framecnt_U8)
{
    ANIM_DATA_TYPE_T const *fl_anim;
    ANIM_CMD_T const * fl_frame;
    ANIM_PRIORITY_LEVEL_TYPE * fl_prio_tbl = &l_anim_prio_table[0];
    UINT16 fl_anim_id_U16 = 0;
    UINT8 fl_frame_count_U8 = 0;

    /* Push the Animation id and the frame Count into stack
     * also modify the Animation priority table with the new one */

    if (FALSE != hmi_anim01_push_stack(p_prio_U8, p_anim_id_U8, p_framecnt_U8))
    {
        /* The current animation is successfully pushed into stack */
        fl_anim = l_anim_data[p_anim_id_U8];
        fl_frame = (fl_anim->frame[p_framecnt_U8]);

        if(GFX_SEND_GROUP_ANIM_CMD == fl_frame->cmd_type)
        {
            fl_anim_id_U16 = (UINT8)fl_frame->index;
            fl_frame_count_U8 = 0;

            /* Update the change in the priority table of the animation */
            fl_prio_tbl->anim_id = fl_anim_id_U16;
            fl_prio_tbl->nextframe = fl_frame_count_U8;

            hmi_anim01_process_commands(p_prio_U8, fl_anim_id_U16, fl_frame_count_U8);
        }
        else
        {
            /* This is not possible. Grouped animation will not have any other cmd type*/
        }
    }
}


/*=========================================================================================
 ** Function Name     : hmi_anim01_send_command
 ** Visibility        : Local
 ** Description       : This function handles the Command Types handlers
 **                   :
 ** Invocation        : by the command processor
 **                   :
 ** Inputs/Outputs    : p_cmd_U16   - Command ID
 **                   : p_index_U16  - Index to the object type
 ** Critical Section  : None
 **=======================================================================================*/
static void hmi_anim01_send_command(UINT16 p_cmd_U16, UINT16 p_index_U16)
{

#ifdef ANIM_SIMPLE_COMMAND_ENABLED
    switch (p_cmd_U16)
    {
        case GFX_SEND_EVENT_ANIM_CMD:
            if(p_index_U16 < ANIM_MAX_SMPL_OBJ)
            {
                ANIM_SEND_EVENT_CMD(l_smpl_tbl[p_index_U16].object,
                                    l_smpl_tbl[p_index_U16].value);
            }
            break;

        case GFX_SEND_TEXT_ANIM_CMD:
            if(p_index_U16 < ANIM_MAX_SMPL_TEXT_OBJ)
            {
                ANIM_SEND_TEXT_CMD(l_smpl_txt_tbl[p_index_U16].object,
                        l_smpl_txt_tbl[p_index_U16].sid);
            }
            break;

        case GFX_FLUSH_ANIM_CMD:
            ANIM_SEND_FLUSH_CMD();
            break;

        default:
            break;
    }
#endif
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_get_current_animation_state
 ** Visibility        : Global
 ** Description       : This function returns the current state for which the animation
 **                     is playing
 **                   :
 ** Invocation        : Animation Client
 **                   :
 ** Inputs/Outputs    : p_priority_U8   - Index to the Animation Priority Tabel
 ** Critical Section  : None
 **=======================================================================================*/
LSH_STATE_ID_T hmi_anim01_get_current_animation_state(UINT8 p_priority_U8)
{
    LSH_STATE_ID_T fl_return = LSH_NUMBER_OF_LOGIC_STATES;

    if (p_priority_U8 < ANIM_MAX_NO_OF_PRIORITY_LEVEL)
    {
        fl_return = l_anim_prio_table[p_priority_U8].state_id;
    }
    return(fl_return);
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_get_current_animation_id
 ** Visibility        : Global
 ** Description       : This function returns the animation id for which the animation
 **                     is playing
 **                   :
 ** Invocation        : Animation Client
 **                   :
 ** Inputs/Outputs    : p_priority_U8   - Index to the Animation Priority Tabel
 ** Critical Section  : None
 **=======================================================================================*/
ANIMATION_ID hmi_anim01_get_current_animation_id(UINT8 p_priority_U8)
{
    ANIMATION_ID fl_return = LSH_NUMBER_OF_LOGIC_STATES;

    if (p_priority_U8 < ANIM_MAX_NO_OF_PRIORITY_LEVEL)
    {
        fl_return = l_anim_prio_table[p_priority_U8].anim_id;
    }
    return(fl_return);
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_get_queued_animation_state
 ** Visibility        : Global
 ** Description       : This function returns the queued state for which the animation
 **                     is queued
 **                   :
 ** Invocation        : Animation Client
 **                   :
 ** Inputs/Outputs    : p_priority_U8   - Index to the Animation Priority Tabel
 ** Critical Section  : None
 **=======================================================================================*/
LSH_STATE_ID_T hmi_anim01_get_queued_animation_state(UINT8 p_priority_U8)
{
    LSH_STATE_ID_T fl_return = LSH_NUMBER_OF_LOGIC_STATES;

    if (p_priority_U8 < ANIM_MAX_NO_OF_PRIORITY_LEVEL)
    {
        fl_return = l_anim_prio_table[p_priority_U8].q_state_id;
    }
    return(fl_return);
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_terminate_current_playing_animation
 ** Visibility        : Global
 ** Description       : This function terminates the current playing animation and
 **                     move the queued animation to current if any
 **                   :
 ** Invocation        : Animation Client
 **                   :
 ** Inputs/Outputs    : p_priority_U8   - Index to the Animation Priority Tabel
 ** Critical Section  : None
 **=======================================================================================*/
void hmi_anim01_terminate_current_playing_animation(UINT8 p_priority_U8)
{
    ANIM_PRIORITY_LEVEL_TYPE *fl_anim = &l_anim_prio_table[p_priority_U8];

    if(fl_anim->anim_id < ANIM_MAX_ID)
    {
        fl_anim->nextframe = l_anim_data[fl_anim->anim_id]->frmcount-1;
        fl_anim->anim_cb_handler = ANIM_NULL_CALLBACK_T;
    }
}

/*=========================================================================================
 ** Function Name     : hmi_anim01_terminate_queued_animation
 ** Visibility        : Global
 ** Description       : This function terminates the Queued animation
 **                   :
 ** Invocation        : Animation Client
 **                   :
 ** Inputs/Outputs    : p_priority_U8   - Index to the Animation Priority Tabel
 ** Critical Section  : None
 **=======================================================================================*/
void hmi_anim01_terminate_queued_animation(UINT8 p_priority_U8)
{
    ANIM_PRIORITY_LEVEL_TYPE *fl_anim = &l_anim_prio_table[p_priority_U8];
    fl_anim->q_anim_id = ANIM_MAX_ID;
    fl_anim->q_state_id = LSH_NUMBER_OF_LOGIC_STATES;
    fl_anim->q_anim_cb_handler = ANIM_NULL_CALLBACK_T;
}

/*========================================================================================
 **
 **========================================================================================
 ** C M S    R E V I S I O N    N O T E S
 **========================================================================================
 **
 ** For each change to this file, be sure to record:
 ** 1.  Who made the change and when the change was made.
 ** 2.  Why the change was made and the intended result.
 **
 ** CMS Rev #        Date         By
 ** CMS Rev X.X      mm/dd/yy     CDSID
 **
 ** CMS Rev 1.7      16-Dec-2011    CMUTHUSA
 ** Ref. BSDI00111721,PR Defect Fix : 49842
 ** Focus Status Sync missing between LSH, Popup, Animation cores Fix -
 ** New structure members, anim_client_id & q_anim_client_id are introduced in ANIM_PRIORITY_LEVEL_TYPE structure,
 ** the anim_client_id is passed as additional parameter in hmi_anim01_start_frame_sequence() to 
 ** stack the client_id triggering the animation & also in ANIM_CALLBACK_T() callback function to
 ** indicate the client_id for which the animation callback is executed. the client_id is then 
 ** passed to Focus handler function with respective LSH FOCUS status.
 **
 ** CMS Rev 1.6      31-Aug-2011  GPURUSO1
 ** Fixed PR Defects
 **
 ** CMS Rev 1.5      17-June-2011  jmanojkku
 ** 1. Added new interface for returning the current running animation id to the clint
 ** 
 ** CMS Rev 1.4      25-May-2011  GPURUSO1
 ** Fixed Compiler warnings for L538.
 **
 ** CMS Rev 1.3      27-Dec-2010  GPURUSO1
 ** 1. Added Return Parameter to the Start Frame Sequence.
 ** 2. Modified the CallBack Sequence to be called after the status update
 ** 3. Removed the Usecase of Add state with Animation and remove state without anim
 **    as now there will be only one call back
 ** 4. Added a return parameter "ANIM_HNDLR_RET_INGORE_FRAME_MAX_CNT_ANIM" to ignore the
 **    check the maximum frame count
 **
 ** CMS Rev 1.2      02-Nov-2010  GPURUSO1
 ** 1. Added code to block the commands of the simple frame seq if there are no commmands
 **    configured
 ** 2. modified the passing of the priority to the Call back functions.
 **
 ** CMS Rev 1.1      02-Nov-2010  GPURUSO1
 ** Handled the Use case for State change with animation immediately following
 ** a state change without animation
  **
 ** CMS Rev 1.0      01/Jul/2010  GPURUSO1
 ** Initial Revision
 **========================================================================================
 **
 **======================================================================================*/

/* end of file =========================================================================*/


