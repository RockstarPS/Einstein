/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2003. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

/*****************************************************************************

File Name        :  sv_common_if.h
Module Short Name:  CMN INRTF
VOBName          :  sw_di_int\2012_ford_c520_l1_ic
Author           :  gvasude1
Description      :  This file contains generic interfaces enum  and macros

Organization     :  Visteon Software Operation
                    Visteon Corporation

******************************************************************************/

#ifndef SV_COMMON_IF_H
#define SV_COMMON_IF_H


/*****************************************************************************
*                                 Global Constant Declarations               *
*----------------------------------------------------------------------------*
* Declaration shall be followed by a comment that gives the following info.  *
* about the constant.                                                        *
* purpose, unit, and resolution                                              *
******************************************************************************/

/*****************************************************************************
*                                 Global Macro Definitions                   *
*----------------------------------------------------------------------------*
* Definition of macro shall be followed by a comment that explains the       *
* purpose of the macro.                                                      *
******************************************************************************/

/*--------------------------------------------------------------------------*/
/* MACRO: SIF_SUPPORT_EXTENDED_QUALIFIER                                    */
/*     Uncomment this macro if support for extended qualifiers is required. */
/*--------------------------------------------------------------------------*/
/* #define SIF_SUPPORT_EXTENDED_QUALIFIER */


/*****************************************************************************
*                                 Type Decleration                           *
*----------------------------------------------------------------------------*
* Decleration of type shall be accompanied by a comment that explains the    *
* purpose and usage of the type.                                             *
******************************************************************************/

/*----------------------------------------------------------------------*/
/* This is the return type for all standard interface functions.        */
/* Valid values for this type are defined below.                        */
/*----------------------------------------------------------------------*/
typedef UINT8 SIF_STATUS;

/*----------------------------------------------------------------------*/
/* DataStatus_OK: Data is available.  Value has been verified           */
/*----------------------------------------------------------------------*/
#define sif_OK          (0)

/*----------------------------------------------------------------------*/
/* DataStatus_NOTFITTED: Feature is disabled. Data is NOT available     */
/*      and should not be used.                                         */
/*----------------------------------------------------------------------*/
#define sif_NOTFITTED   (BIT1)

/*----------------------------------------------------------------------*/
/* DataStatus_UNKNOWN: No source data has been received yet.            */
/*      The data value will be the last available value or the          */
/*      intialised default.  (Note: this is not an error condition -    */
/*      data is expected to be available soon)                          */
/*----------------------------------------------------------------------*/
#define sif_UNKNOWN     (BIT2)

/*----------------------------------------------------------------------*/
/* DataStatus_ERROR: Data is availbale but the value is not valid.      */
/*----------------------------------------------------------------------*/
#define sif_ERROR       (BIT3)

/*----------------------------------------------------------------------*/
/* DataStatus_FAULT:  The data source has failed and no new data is     */
/*      available.  The data will be the last available or the          */
/*     initialised default if the source has never been available.      */
/*----------------------------------------------------------------------*/
#define sif_FAULT       (BIT4)

/*----------------------------------------------------------------------*/
/* DataStatus_MASK: Mask of all valid states for this data type.        */
/*      This is for system use only.                                    */
/*----------------------------------------------------------------------*/
#define sif_MASK        (sif_NOTFITTED|sif_UNKNOWN|sif_ERROR|sif_FAULT)



#if defined SIF_SUPPORT_EXTENDED_QUALIFIER
/*----------------------------------------------------------------------*/
/* Standard Interface Function using Pointers (SIF_P) prototypes.       */
/*      All SIF interfaces MUST conform to one of the following:        */
/*      (Replace XYZ with the name of the data being accessed.)         */
/*                                                                      */
/*  Parameters:                                                         */
/*      *Data:      pointer to where the data should be placed.         */
/*      *Qualifier: pointer to optional qualification data.             */
/*                  The data type will be defined by the feature.       */
/*                                                                      */
/*  Return value:                                                       */
/*      This is the STATUS of the data being requested. For processed   */
/*      data, a value of DataStatus_OK can normally be returned since   */
/*      the feature will have taken all input states into consideration */
/*      to work out the data value.  Do not just echo the status of the */
/*      original source.                                                */
/*      NOTE: You don't need to support any return state this is not    */
/*      applicable to the data.                                         */
/*                                                                      */
/*  SIF_P Providers:    Parameters should be ignored if NULL.           */
/*  SIF_P Users:        You can set either parameter to NULL if the     */
/*                      data is not needed.                             */
/*----------------------------------------------------------------------*/
SIF_STATUS get_data_XYZ_u8(UINT8 *Data, void * const Qualifier);
SIF_STATUS get_data_XYZ_u16(UINT16 *Data, void * const Qualifier);
SIF_STATUS get_data_XYZ_u32(UINT32 *Data, void * const Qualifier);

#else /* SIF_SUPPORT_EXTENDED_QUALIFIER */
/*----------------------------------------------------------------------*/
/* Standard Interface Function using Values (SIF_V) prototypes.         */
/*      All interfaces MUST conform to one of the following:            */
/*      (Replace XYZ with the name of the data being accessed.)         */
/*                                                                      */
/*  Parameters:                                                         */
/*      *Data:      pointer to where the data should be placed.         */
/*      Qualifier:  Data selection specifier (if needed). This will     */
/*                  one function to provide multiple services.          */
/*                                                                      */
/*  Return value:                                                       */
/*      This is the STATUS of the data being requested. For processed   */
/*      data, a value of DataStatus_OK can normally be returned since   */
/*      the feature will have taken all input states into consideration */
/*      to work out the data value.  Do not just echo the status of the */
/*      original source.                                                */
/*      NOTE: You don't need to support any return state this is not    */
/*      applicable to the data.                                         */
/*                                                                      */
/*  SIF_P Providers:    The Data parameter should be ignored if NULL.   */
/*  SIF_P Users:        Set the Data parameter to NULL if the data is   */
/*                      not needed.                                     */
/*                      Set Qualifier to 0 if not used.                 */
/*----------------------------------------------------------------------*/
SIF_STATUS get_data_XYZ_u8(UINT8 *Data, const UINT8 Qualifier);
SIF_STATUS get_data_XYZ_u16(UINT16 *Data, const UINT16 Qualifier);
SIF_STATUS get_data_XYZ_u32(UINT32 *Data, const UINT32 Qualifier);

#endif /* SIF_SUPPORT_EXTENDED_QUALIFIER */



/*****************************************************************************
*                                 Global Variable Declarations               *
*----------------------------------------------------------------------------*
* Declaration shall be followed by a comment that gives the following info.  *
* about the variable.                                                        *
* purpose, critical section, unit, and resolution                            *
******************************************************************************/

/*****************************************************************************
*                                 Global Function Prototypes                 *
******************************************************************************/


#endif
/*End of File*/
/****************************************************************************
*   for each change to this file, be sure to record:                        *
*      1.  who made the change and when the change was made                 *
*      2.  why the change was made and the intended result                  *
*   Following block needs to be repeated for each change                    *
*****************************************************************************/
/*---------------------------------------------------------------------------
Date              :  20/Apr/2010
By                :  gvasude1
Traceability      :
Change Description:  initial version
-----------------------------------------------------------------------------*/
