/*============================================================================
**
**                     CONFIDENTIAL VISTEON CORPORATION
**
** This is an unpublished work of authorship, which contains trade secrets,
** created in 2009. Visteon Corporation owns all rights to this work and
** intends to maintain it in confidence to preserve its trade secret status.
** Visteon Corporation reserves the right, under the copyright laws of the
** United States or those of any other country that may have jurisdiction,
** to protect this work as an unpublished work, in the event of an
** inadvertent or deliberate unauthorized publication. Visteon Corporation
** also reserves its rights under all copyright laws to protect this work as
** a published work, when appropriate. Those having access to this work may
** not copy it, use it, modify it or disclose the information contained in
** it without the written authorization of Visteon Corporation.
**
**============================================================================
**
**  Name:               hmi_SIF.h
**
**  Description:
**
**  Organization:       Driver Information Software Section,
**                      DI Core Engineering Department
**
**===========================================================================*/
#ifndef hmi_SIF_H
#define hmi_SIF_H

/*==========================================================================*/
/* I N C L U D E   F I L E S                                                */
/*==========================================================================*/
#include "sv_common_if.h"


/*==========================================================================*/
/* T Y P E   D E F I N I T I O N S                                          */
/*==========================================================================*/

/*----------------------------------------------------------------------*/
/* Common helper macros                                                 */
/*----------------------------------------------------------------------*/
#define SIF_SET_DATA(value)  *Data = (value)
#define SIF_GET_DATA()       (*Data)
#define SIF_GET_DATA_REF()   (Data)
#define SIF_ISVALID_DATA() (NULL != Data)

#if defined SIF_SUPPORT_EXTENDED_QUALIFIER
/*----------------------------------------------------------------------*/
/* Helper macros for extended interface                                 */
/*----------------------------------------------------------------------*/
#define NULSIF_STANDARD_INTERFACE(name) SIF_STATUS name(void *Data, void *Qualifier)
#define U08SIF_STANDARD_INTERFACE(name) SIF_STATUS name(UINT8 *Data, UINT8 *Qualifier)
#define U16SIF_STANDARD_INTERFACE(name) SIF_STATUS name(UINT16 *Data, UINT16 *Qualifier)
#define U32SIF_STANDARD_INTERFACE(name) SIF_STATUS name(UINT32 *Data, UINT32 *Qualifier)

typedef SIF_STATUS (*U08SIF_GET_DATA)(UINT8 *Data, UINT8 *Qualifier);
typedef SIF_STATUS (*U16SIF_GET_DATA)(UINT16 *Data, UINT16 *Qualifier);
typedef SIF_STATUS (*U32SIF_GET_DATA)(UINT32 *Data, UINT32 *Qualifier);

#define SIF_EXEC(name, data, qualifier) name(&data, &qualifier)

#define SIF_ISVALID_QUALIFIER() (NULL != Qualifier)
#define SIF_GET_QUALIFIER() (*Qualifier)

#else
/*----------------------------------------------------------------------*/
/* Helper macros for standard interface                                 */
/*----------------------------------------------------------------------*/
#define NULSIF_STANDARD_INTERFACE(name) SIF_STATUS name(void *Data)
#define U08SIF_STANDARD_INTERFACE(name) SIF_STATUS name(UINT8 *Data, UINT8 Qualifier)
#define U16SIF_STANDARD_INTERFACE(name) SIF_STATUS name(UINT16 *Data, UINT16 Qualifier)
#define U32SIF_STANDARD_INTERFACE(name) SIF_STATUS name(UINT32 *Data, UINT32 Qualifier)

typedef SIF_STATUS (*U08SIF_GET_DATA)(UINT8 *Data, UINT8 Qualifier);
typedef SIF_STATUS (*U16SIF_GET_DATA)(UINT16 *Data, UINT16 Qualifier);
typedef SIF_STATUS (*U32SIF_GET_DATA)(UINT32 *Data, UINT32 Qualifier);

#define SIF_EXEC(name, data, qualifier) name(&data, qualifier)

#define SIF_GET_QUALIFIER() (Qualifier)
#define SIF_ISVALID_QUALIFIER() (FALSE == FALSE)

#endif

/*==========================================================================*/
/* E N T R Y   P O I N T S                                                  */
/*==========================================================================*/

/*==========================================================================*/
/* F U N C T I O N  P R O T O T Y P E S                                     */
/*==========================================================================*/

/*==========================================================================*/
/* R E V I S I O N    N O T E S                                             */
/*==========================================================================*/
/* For each change to this file, be sure to record:
** 1.  Who made the change and when the change was made.
** 2.  Why the change was made and the intended result.
**==========================================================================*/

/****************************************************************************
**  Date  : 05/May/2010
**  by    : AFERRIS2
**  Ref   : None.
**  Change: Initial version.
**
*****************************************************************************/

/****************************************************************************
**  Date: 08/Jul/2010     by: AFERRIS2        Ref:
**  Change: 1.  Add new macro SIF_GET_DATA_REF()
**
**  Checks: COMPILER - NOT CHECKED       QAC - NOT CHECKED
*****************************************************************************/
/****************************************************************************
**  Date: 10/Feb/2015     by: adevi        Ref:
**  Change: Compiler warnings resolved for Honda THAA
*****************************************************************************/

#endif  /* hmi_SIF_H */
/* end of file =============================================================*/
