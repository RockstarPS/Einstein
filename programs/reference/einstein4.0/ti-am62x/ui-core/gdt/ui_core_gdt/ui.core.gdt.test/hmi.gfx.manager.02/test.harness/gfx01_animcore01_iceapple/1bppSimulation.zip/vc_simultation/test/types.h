#if !defined (TYPES_H)
#define TYPES_H
/* =============================================================================
//
//                     CONFIDENTIAL VISTEON CORPORATION
//
//      This is an unpublished work of authorship, which contains trade
//      secrets, created in 2006.  Visteon Corporation owns all rights
//      to this work and intends to maintain it in confidence to preserve
//      its trade secret status.  Visteon Corporation reserves the right,
//      under the copyright laws of the United States or those of any other
//      country that may have jurisdiction, to protect this work as an
//      unpublished work, in the event of an inadvertent or deliberate
//      unauthorized publication.  Visteon Corporation reserves its rights
//      under all copyright laws to protect this work as a published work,
//      when appropriate.  Those having access to this work may not copy
//      it, use it, modify it or disclose the information contained in it
//      without the written authorization of Visteon Corporation.
//
// ========================================================================== */

/* =============================================================================
//
//  Name:           types.h
//
//  Description:    This file defines common type definitions, defined
//                  constants and function mimicking macros.
//
// ========================================================================== */

/* =============================================================================
//
//  Include Section
//
// ========================================================================== */

#include "design_attributes.h"
#include "tmwtypes.h"


/* =============================================================================
//
//  Public Defined Constants Section
//
// ========================================================================== */

#if !defined (NULL)

#define NULL    ((void *)(0))

#endif /* NULL */


#define YES (1)
#define NO  (-1)


/* =============================================================================
//
//  Public Type Definitions Section
//
// ========================================================================== */

typedef unsigned char   unsigned8;
typedef signed char     signed8;

typedef unsigned short  unsigned16;
typedef signed   short  signed16;

typedef unsigned int    unsigned32;
typedef signed int      signed32;


#if defined (__cplusplus) || defined(MATLAB_MEX_FILE) || defined(RT) || defined(WIN32)

    #define FALSE   false
    #define TRUE    true

#else
  #if !defined(_WINDEF_)
    typedef enum
    {
        FALSE,
        TRUE
    };	 
  #else
	typedef unsigned char bool;
  #endif
#endif /* __cplusplus */

#ifndef _WINDEF_
	//typedef bool BOOL;
#endif

typedef void (*function_ptr_type)(void);


/* =============================================================================
//
//  Public Function Mimicking Macro Definitions Section
//
// ========================================================================== */

/* =============================================================================
//
//  Name:           RANGE_CHECK
//
//  Description:    Range check on value (id) such that the value is >=
//                  to the beginning boundary (first) and < the ending
//                  boundary (last).
//
// ========================================================================== */

#define RANGE_CHECK(id, first, last)        (((id) >= (first)) && ((id) < (last)))


/* =============================================================================
//
//  Name:           INCL_RANGE_CHECK
//
//  Description:    Range check on value (id) such that the value is >=
//                  to the beginning boundary (first) and <= the ending
//                  boundary (last).
//
// ========================================================================== */

#define INCL_RANGE_CHECK(id, first, last)   (((id) >= (first)) && ((id) <= (last)))


#endif /* TYPES_H =========================================================== */
