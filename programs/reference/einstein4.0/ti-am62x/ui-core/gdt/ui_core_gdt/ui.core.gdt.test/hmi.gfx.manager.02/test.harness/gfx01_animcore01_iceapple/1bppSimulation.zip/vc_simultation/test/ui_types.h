/******************************************************************************
*                              Copyright Statement
*                        CONFIDENTIAL VISTEON CORPORATION
*
*  This is an unpublished work of authorship, which contains trade secrets,
*  created in 2006. Visteon Corporation owns all rights to this work and
*  intends to maintain it in confidence to preserve its trade secret status.
*  Visteon Corporation reserves the right, under the copyright laws of the
*  United States or those of any other country that may have  jurisdiction,
*  to protect this work as an unpublished work, in the event of an inadvertent
*  or deliberate unauthorized publication. Visteon Corporation also reserves
*  its rights under all copyright laws to protect this work as a published
*  work, when appropriate. Those having access to this work may not copy it,
*  use it, modify it or disclose the information contained in it without the
*  written authorization of Visteon Corporation.
*
*******************************************************************************
*
*  Module:             ui_input_if.h
*  Description:        
*  Author:             
*  Date:               
*
*******************************************************************************/

#ifndef UI_TYPES_H
#define UI_TYPES_H

/******************************************************************************
* Include files
******************************************************************************/

/******************************************************************************
* Data types
******************************************************************************/
/******************************************************************************
* Data types - enums
******************************************************************************/
/******************************************************************************
* function prototypes
******************************************************************************/

/*
//  Base Data Types
*/
typedef unsigned char   UINT8;
typedef   signed char   SINT8;
typedef unsigned short int   UINT16;
typedef   signed short int   SINT16;
typedef unsigned long   UINT32;
typedef   signed long   SINT32;
typedef unsigned char   BOOLEAN;
/*
//  Base Data Type Modifiers
*/
#define NEAR        zpage
#define FAR
/*
//  Base Function Type Modifiers
*/
#define INTERRUPT   interrupt
#define FARFUNC
#define NEARFUNC
#define REENTRANT


#undef EXTERN_pfx

#endif /* UI_TYPES_H */

