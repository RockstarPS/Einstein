/*============================================================================
 **
 **                     CONFIDENTIAL VISTEON CORPORATION
 **
 ** This is an unpublished work of authorship, which contains trade secrets,
 ** created in 2010. Visteon Corporation owns all rights to this work and
 ** intends to maintain it in confidence to preserve its trade secret status.
 ** Visteon Corporation reserves the right, under the copyright laws of the
 ** United States or those of any other country that may have jurisdiction,
 ** to protect this work as an unpublished work, in the event of an
 ** inadvertent or deliberate unauthorized publication. Visteon Corporation
 ** also reserves its rights under all copyright laws to protect this work as
 ** a published work, when appropriate. Those having access to this work may
 ** not copy it, use it, modify it or disclose the information contained in
 ** it without the written authorization of Visteon Corporation.
 **
 **============================================================================
 **
 ** Name:           hmi_animation01_core.c
 **
 ** Description:    This module handles the animation sequence for
 **                 each animation.
 **
 ** Organization:   Driver Information Software Section,
 **                 Visteon
 **
 **=========================================================================================
 **
 **=======================================================================================*/
#ifndef HMI_ANIMATION_01_CORE_H
#define HMI_ANIMATION_01_CORE_H


/*=========================================================================================
 ** I N C L U D E   F I L E S
 **=======================================================================================*/
#include "system.h"
#include "hmi_animation01_core_if.h"
#include "hmi_language_interface.h"

/*=========================================================================================
 ** I N T E R N A L   M A C R O   A N D   T Y P E   D E F I N I T I O N S
 **=======================================================================================*/

/* Command Type Enumeration */
typedef enum
{
    GFX_SEND_EVENT_ANIM_CMD = 0,
    GFX_SEND_TEXT_ANIM_CMD,
    GFX_FLUSH_ANIM_CMD,
    GFX_SEND_INTERPOLATE_ANIM_CMD,
    GFX_SEND_GROUP_ANIM_CMD,
    GFX_INVALID_CMD_ANIM_TYPE
}ANIM_CMD_TYPE;

typedef enum
{
	ANIM_SEQNCR_INACTIVE = 0,
	ANIM_SEQNCR_ACTIVE
}ANIM_SEQNCR_RET_T;


#define ANIMATION_INVALID_ID    (ANIM_MAX_ID)
#define ANIM_GET_ANIM_ID 0xFF

#define ANIM_HNDLR_RET_TERMINATE_ANIM               (0xFF)
#define ANIM_HNDLR_RET_INGORE_FRAME_MAX_CNT_ANIM    (0xFE)
#define ANIM_HNDLR_RET_CONTINUE_ANIM                (0)

typedef UINT8 (ANIM_HANDLER_T)(UINT8 p_state_id_U8, UINT8 p_frame_cnt_U8);
#define ANIM_NULL_HANDLER_T    ((ANIM_HANDLER_T * ) 0)

typedef void (ANIM_CALLBACK_T)(UINT8 p_prio_U8, UINT8 p_state_id_U8, ANIMATION_ID p_anim_ID, UINT8 p_anim_client_id_U8);
#define ANIM_NULL_CALLBACK_T   ((ANIM_CALLBACK_T *) 0)

typedef UINT8 (ANIM_INTERPOLATION_CALL_BACK_T)(UINT8 p_anim_id_U8, UINT8 p_frame_cnt_U8);


typedef struct
{
	UINT16 object;
	UINT16  value;
}ANIM_SIMPLE_CMD_T;

typedef struct
{
	UINT16 object;
	HMI_CHAR * sid;
}ANIM_SIMPLE_TEXT_CMD_T;


typedef struct
{
	ANIM_CMD_TYPE cmd_type;
	UINT16 index;
}ANIM_CMD_T;

#define ANIM_START_POS_MASK    (0x0F)
#define ANIM_END_POS_MASK      (0xF0)

#define ANIM_SET_START_POS_AS_DYNAMIC(x)     (x = (x | ANIM_START_POS_MASK))
#define ANIM_SET_END_POS_AS_DYNAMIC(x)       (x = (x | ANIM_END_POS_MASK))

#define ANIM_CLEAR_START_POS_DYNAMIC(x)   (x = (x & (~ANIM_START_POS_MASK)))
#define ANIM_CLEAR_END_POS_DYNAMIC(x)     (x = (x & (~ANIM_END_POS_MASK)))

#define IS_ANIM_START_POS_DYNAMIC(x)      ((x & ANIM_START_POS_MASK) == (ANIM_START_POS_MASK))
#define IS_ANIM_END_POS_DYNAMIC(x)        ((x & ANIM_END_POS_MASK) == (ANIM_END_POS_MASK))

typedef struct
{
	UINT8 ctype_U8;
	UINT16 object;
	UINT16 start_pos_U16;
	UINT16 end_pos_U16;
}ANIM_INTERPOLATE_CMD_T;

#define LOOPING_BACK_ON    (1)
#define LOOPING_BACK_OFF   (0)

#define ABORT_ON  (2)
#define ABORT_OFF (0)

typedef struct
{
	UINT8 properties;
	UINT8 anim_type;
	ANIM_HANDLER_T * anim_handler;
	UINT8 config_cnt;
	UINT8 frmcount;
	UINT8 frmrate;
	 ANIM_CMD_T ** frame;
}ANIM_DATA_TYPE_T;

typedef enum
{
	SIMPLE_FRAME_SEQUENCE,
	INTERPOLATION_FRAME_SEQUENCER,
	GROUPED_FRAME_SEQUENCER,
	INVALID_SEQUENCR
};

/*=========================================================================================
 ** I N T E R N A L   F U N C T I O N   P R O T O T Y P E S
 **=======================================================================================*/
/*=========================================================================================
 ** M E M O R Y   A L L O C A T I O N
 **=======================================================================================*/

/*=========================================================================================
 ** E N T R Y   P O I N T S  /  D A T A   A C C E S S   S E R V I C E S
 **=======================================================================================*/
/*=========================================================================================
 ** Function Name     : hmi_anim01_intialization
 ** Visibility        : Global
 ** Description       : Init routine for the Animation Core Comp
 **                   :
 ** Invocation        : This should be invoked during COLD, WARM, WAKEUP
 **                   : initilaisation
 ** Inputs/Outputs    : None
 ** Critical Section  : None
 **=======================================================================================*/
extern void hmi_anim01_intialization(void);

/*=========================================================================================
 ** Function Name     : hmi_anim01_periodic_task
 ** Visibility        : Global
 ** Description       : This function is should be called periodically.
 **                   : Also it issues the graphics command of a frame when the frame rate
 **                   : is met. The resolution of the frame rate is equal to the periodicity
 **                   : of this task.
 **                   :
 ** Invocation        : Periodic Task.
 **                   :
 ** Inputs/Outputs    : None
 ** Critical Section  : None
 **=======================================================================================*/
extern void hmi_anim01_periodic_task(void);

/*=========================================================================================
 ** Function Name     : hmi_anim01_start_frame_sequence
 ** Visibility        : Global
 ** Description       : This function triggers the start of an animation
 **                   :
 ** Invocation        : Invoked by the application
 **                   :
 ** Output            : Returns True is the Animation is started or Queued
 **                   :
 ** Inputs            : p_prio_U8 - Index to the priority table
 **                   : p_state_id - State id to be added after the animation
 **                   : p_anim_id  - Index to the anim table for
 **                   : p_anim_cb_handler - Pointer to function to call when animation is over
 ** Critical Section  : None
 **=======================================================================================*/
extern UINT8 hmi_anim01_start_frame_sequence(UINT8 p_prio_U8, LSH_STATE_ID_T p_state_id,
		             ANIMATION_ID p_anim_id, ANIM_CALLBACK_T * p_anim_cb_handler, UINT8 p_anim_client_id_U8);

/*=========================================================================================
 ** Function Name     : hmi_anim01_stop_frame_sequence
 ** Visibility        : Global
 ** Description       : This function triggers the start of an animation
 **                   :
 ** Invocation        : Invoked by the application
 **                   :
 ** Inputs/Outputs    : p_prio_U8 - Index to the priority table
 **                   : p_state_id - State id to be added after the animation
 **                   : p_anim_id  - Index to the anim table for
 ** Critical Section  : None
 **=======================================================================================*/
extern void hmi_anim01_stop_frame_sequence(UINT8 p_prio_U8, LSH_STATE_ID_T p_state_id);

/*=========================================================================================
 ** Function Name     : hmi_anim01_is_frame_seqncr_active
 ** Visibility        : Global
 ** Description       : This function returns the status of an animation
 **                   :
 ** Invocation        : Invoked by the application to check on the animation status
 **                   :
 ** Inputs/Outputs    : ANIM_SEQNCR_RET_T = Animation Status
 **                     ANIM_SEQNCR_INACTIVE - Animation Inactive
 **                     ANIM_SEQNCR_ACTIVE   - Animation Active
 ** Critical Section  : None
 **=======================================================================================*/
extern ANIM_SEQNCR_RET_T hmi_anim01_is_frame_seqncr_active(void);


/*=========================================================================================
 ** Function Name     : hmi_anim01_get_current_animation_state
 ** Visibility        : Global
 ** Description       : This function returns the current state for which the animation
 **                     is playing
 **                   :
 ** Invocation        : Animation Client
 **                   :
 ** Inputs/Outputs    : p_priority_U8   - Index to the Animation Priority Tabel
 ** Critical Section  : None
 **=======================================================================================*/
extern LSH_STATE_ID_T hmi_anim01_get_current_animation_state(UINT8 p_priority_U8);

/*=========================================================================================
 ** Function Name     : hmi_anim01_get_current_animation_id
 ** Visibility        : Global
 ** Description       : This function returns the current ANIMATION id for which the animation
 **                     is playing
 **                   :
 ** Invocation        : Animation Client
 **                   :
 ** Inputs/Outputs    : p_priority_U8   - Index to the Animation Priority Tabel
 ** Critical Section  : None
 **=======================================================================================*/
extern ANIMATION_ID hmi_anim01_get_current_animation_id(UINT8 p_priority_U8);


/*=========================================================================================
 ** Function Name     : hmi_anim01_get_queued_animation_state
 ** Visibility        : Global
 ** Description       : This function returns the queued state for which the animation
 **                     is queued
 **                   :
 ** Invocation        : Animation Client
 **                   :
 ** Inputs/Outputs    : p_priority_U8   - Index to the Animation Priority Tabel
 ** Critical Section  : None
 **=======================================================================================*/
extern LSH_STATE_ID_T hmi_anim01_get_queued_animation_state(UINT8 p_priority_U8);

/*=========================================================================================
 ** Function Name     : hmi_anim01_terminate_current_playing_animation
 ** Visibility        : Global
 ** Description       : This function terminates the current playing animation and
 **                     move the queued animation to current if any
 **                   :
 ** Invocation        : Animation Client
 **                   :
 ** Inputs/Outputs    : p_priority_U8   - Index to the Animation Priority Tabel
 ** Critical Section  : None
 **=======================================================================================*/
extern void hmi_anim01_terminate_current_playing_animation(UINT8 p_priority_U8);

/*=========================================================================================
 ** Function Name     : hmi_anim01_terminate_queued_animation
 ** Visibility        : Global
 ** Description       : This function terminates the Queued animation
 **                   :
 ** Invocation        : Animation Client
 **                   :
 ** Inputs/Outputs    : p_priority_U8   - Index to the Animation Priority Tabel
 ** Critical Section  : None
 **=======================================================================================*/
extern void hmi_anim01_terminate_queued_animation(UINT8 p_priority_U8);



/*========================================================================================
 **
 **========================================================================================
 ** C M S    R E V I S I O N    N O T E S
 **========================================================================================
 **
 ** For each change to this file, be sure to record:
 ** 1.  Who made the change and when the change was made.
 ** 2.  Why the change was made and the intended result.
 **
 ** CMS Rev #        Date         By
 ** CMS Rev X.X      mm/dd/yy     CDSID
 **
 **========================================================================================
 ** CMS Rev 1.2      16-Dec-2011    CMUTHUSA
 ** Ref. BSDI00111721,PR Defect Fix : 49842
 ** Focus Status Sync missing between LSH, Popup, Animation cores Fix -
 ** the anim_client_id is passed as additional parameter in hmi_anim01_start_frame_sequence() to 
 ** stack the client_id triggering the animation & also in ANIM_CALLBACK_T() callback function to
 ** indicate the client_id for which the animation callback is executed. the client_id is then 
 ** passed to Focus handler function with respective LSH FOCUS status.
 **
 **     Rev 1.1      17- june-11     gpuruso1
 **     added the prototype
 **
 **     Rev 1.0      5-Aug-10     gpuruso1
 **     Intial Version
 **======================================================================================*/

/* end of file =========================================================================*/
#endif
