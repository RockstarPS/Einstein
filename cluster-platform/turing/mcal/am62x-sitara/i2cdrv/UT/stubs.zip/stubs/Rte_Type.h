#ifndef RTE_TYPE_H
#define RTE_TYPE_H


#include "Std_Types.h"

typedef uint8 EcuM_StateType; /*NCHELLAP Added to resolve compilation error from EcuM Integration*/

typedef uint8 EcuM_BootTargetType;


# define Rte_TypeDef_EcuM_UserType
typedef uint8 EcuM_UserType;

# define Rte_TypeDef_NvM_RequestResultType
typedef uint8 NvM_RequestResultType;

#endif

