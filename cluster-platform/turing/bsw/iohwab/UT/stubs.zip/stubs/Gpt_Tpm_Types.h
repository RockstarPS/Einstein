/**
*   @file           Gpt_Tpm_Types.h
*   @version        4.0.0
*
*   @brief          AUTOSAR Gpt - Tpm data types header file.
*   @details        Tpm defines, types used by GPT driver.
*
*   @addtogroup     PWM_MODULE
*   @{
*/
/*==================================================================================================
*   Project              : AUTOSAR 4.2 MCAL
*   Platform             : ARM
*   Peripheral           : Ftm
*   Dependencies         : none
*
*   Autosar Version      : 4.2.2
*   Autosar Revision     : ASR_REL_4_2_REV_0002
*   Autosar Conf.Variant :
*   SW Version           : 4.0.0
*   Build Version        : IMX8_MCAL_4_0_0_RTM_ASR_REL_4_2_REV_0002_20201231
*
*   Copyright 2006-2016 Freescale Semiconductor, Inc. 
*   Copyright 2017 - 2020 NXP
*   NXP Confidential. This software is owned or controlled by NXP and may only be 
*   used strictly in accordance with the applicable license terms.  By expressly 
*   accepting such terms or by downloading, installing, activating and/or otherwise 
*   using the software, you are agreeing that you have read, and that you agree to 
*   comply with and are bound by, such license terms.  If you do not agree to be 
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/
/*==================================================================================================
==================================================================================================*/

#ifndef GPT_TPM_TYPES_H
#define GPT_TPM_TYPES_H

#ifdef __cplusplus
extern "C"{
#endif

/**
* @page misra_violations MISRA-C:2004 violations
*
* @section [global]
*       Violates MISRA 2004 Required Rule 5.1, Identifiers (internal and external) shall not rely
*       on the significance of more than 31 characters. The used compilers use more than 31 chars
*       for identifiers
*/

/*===============================================================================================
*                                         INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
===============================================================================================*/
#include "Tpm_Common_Types.h"

//#include "Reg_eSys_Tpm.h"

#include "Gpt_EnvCfg.h"
#include "Gpt_Cfg.h"

/*===============================================================================================
*                               SOURCE FILE VERSION INFORMATION
===============================================================================================*/

#define GPT_TPM_TYPES_VENDOR_ID                       43
#define GPT_TPM_TYPES_MODULE_ID                       100
#define GPT_TPM_TYPES_AR_RELEASE_MAJOR_VERSION        4
#define GPT_TPM_TYPES_AR_RELEASE_MINOR_VERSION        2
#define GPT_TPM_TYPES_AR_RELEASE_REVISION_VERSION     2
#define GPT_TPM_TYPES_SW_MAJOR_VERSION                4
#define GPT_TPM_TYPES_SW_MINOR_VERSION                0
#define GPT_TPM_TYPES_SW_PATCH_VERSION                0

/*===============================================================================================
*                                      FILE VERSION CHECKS
===============================================================================================*/
//     /* Check if Gpt_Tpm_Types.h and Tpm_Common_Types.h file are of the same Autosar version */
// #ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
//     #if ((GPT_TPM_TYPES_AR_RELEASE_MAJOR_VERSION != TPM_COMMON_TYPES_AR_RELEASE_MAJOR_VERSION) || \
//         (GPT_TPM_TYPES_AR_RELEASE_MINOR_VERSION != TPM_COMMON_TYPES_AR_RELEASE_MINOR_VERSION) \
//         )
//     #error "AutoSar Version Numbers of Gpt_Tpm_Types.h and Tpm_Common_Types.h are different"
//     #endif
// #endif

//     /* Check if Gpt_Tpm_Types.h and Reg_eSys_Tpm.h file are of the same Autosar version */
// #ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
//     #if ((GPT_TPM_TYPES_AR_RELEASE_MAJOR_VERSION != REG_ESYS_TPM_AR_RELEASE_MAJOR_VERSION) || \
//         (GPT_TPM_TYPES_AR_RELEASE_MINOR_VERSION != REG_ESYS_TPM_AR_RELEASE_MINOR_VERSION) \
//         )
//     #error "AutoSar Version Numbers of Gpt_Tpm_Types.h and Reg_eSys_Tpm.h are different"
//     #endif
// #endif


// #if ( GPT_TPM_TYPES_VENDOR_ID != GPT_VENDOR_ID_CFG)
//     #error "Gpt_LPit_Types.h and Gpt_Cfg.h have different vendor ids"
// #endif
// /* Check if the header files are of the same Autosar version */
// #if ((GPT_TPM_TYPES_AR_RELEASE_MAJOR_VERSION != GPT_AR_RELEASE_MAJOR_VERSION_CFG) || \
//      (GPT_TPM_TYPES_AR_RELEASE_MINOR_VERSION != GPT_AR_RELEASE_MINOR_VERSION_CFG) || \
//      (GPT_TPM_TYPES_AR_RELEASE_REVISION_VERSION != GPT_AR_RELEASE_REVISION_VERSION_CFG) \
//     )
//     #error "AutoSar Version Numbers of Gpt_LPit_Types.h and Gpt_Cfg.h are different"
// #endif
// /* Check if the header files are of the same Software version */
// #if ((GPT_TPM_TYPES_SW_MAJOR_VERSION != GPT_SW_MAJOR_VERSION_CFG) || \
//      (GPT_TPM_TYPES_SW_MINOR_VERSION != GPT_SW_MINOR_VERSION_CFG) || \
//      (GPT_TPM_TYPES_SW_PATCH_VERSION != GPT_SW_PATCH_VERSION_CFG) )
//     #error "Software Version Numbers of Gpt_LPit_Types.h and Gpt_Cfg.h are different"
// #endif


//     /* Check if Gpt_Tpm_Types.h and Gpt_EnvCfg.h file are of the same vendor */
// #if (GPT_TPM_TYPES_VENDOR_ID != GPT_ENVCFG_VENDOR_ID)
//     #error "Gpt_EnvCfg.h and Gpt_Tpm_Types.h have different vendor ids"
// #endif
//     /* Check if Gpt_Tpm_Types.h and Gpt_EnvCfg.h file are of the same Autosar version */

//     #if ((GPT_TPM_TYPES_AR_RELEASE_MAJOR_VERSION != GPT_ENVCFG_AR_RELEASE_MAJOR_VERSION) || \
//         (GPT_TPM_TYPES_AR_RELEASE_MINOR_VERSION != GPT_ENVCFG_AR_RELEASE_MINOR_VERSION) || \
//         (GPT_TPM_TYPES_AR_RELEASE_REVISION_VERSION != GPT_ENVCFG_AR_RELEASE_REVISION_VERSION))
//     #error "AutoSar Version Numbers of Gpt_Tpm_Types.h and Gpt_EnvCfg.h are different"
//     #endif

//     /* Check if Gpt_EnvCfg.h and Gpt_Tpm_Types header file are of the same software version */
// #if ((GPT_TPM_TYPES_SW_MAJOR_VERSION != GPT_ENVCFG_SW_MAJOR_VERSION) || \
//      (GPT_TPM_TYPES_SW_MINOR_VERSION != GPT_ENVCFG_SW_MINOR_VERSION) || \
//      (GPT_TPM_TYPES_SW_PATCH_VERSION != GPT_ENVCFG_SW_PATCH_VERSION))
//     #error "Software Version Numbers of Gpt_Tpm_Types.h and Gpt_EnvCfg.h are different"
// #endif

/*===============================================================================================
*                                           CONSTANTS
===============================================================================================*/

/*===============================================================================================
*                                       DEFINES AND MACROS
===============================================================================================*/

/*===============================================================================================
*                                             ENUMS
===============================================================================================*/

/*===============================================================================================
*                                 STRUCTURES AND OTHER TYPEDEFS
===============================================================================================*/

/**
* @brief TPM channel data type
*/
typedef uint8 Gpt_Tpm_ChannelType;

/**
* @brief TPM channel specific configuration data structure
*/
typedef struct
{
    uint8 u8TpmChannelId;
    uint32 u32TpmChannelTrigger;
    uint32 u32TpmChannelTriggerMask;
} Gpt_Tpm_ChannelConfigType;

/**
* @brief TPM specific configuration data structure
*/
typedef struct
{
    /* @brief number of modules in TPM configuration structure */
    CONST(Gpt_Tpm_ChannelType, GPT_CONST) nNumModules;
    /* @brief number of channels in TPM configuration structure */
    CONST(Gpt_Tpm_ChannelType, GPT_CONST) nNumChannels;
    /* @brief Index in Gpt_aHw2LogicChannelMap where TPM channels start */
    CONST(Gpt_Tpm_ChannelType, GPT_CONST) nTpmChannelsStartIdx;
    /* @brief pointer to TPM global configuration */
    CONST(Tpm_CommonConfigType, GPT_CONST) (*GptTpmGlobalConfiguration)[];
    /* @brief Array of configured TPM channels */
    CONST(Gpt_Tpm_ChannelConfigType, GPT_CONST) (*TpmChannels)[];
} Gpt_Tpm_IpConfigType;

/*===============================================================================================
*                                       DEFINES AND MACROS
===============================================================================================*/

/*===============================================================================================
*                                 GLOBAL VARIABLE DECLARATIONS
===============================================================================================*/

/*===============================================================================================
*                                     FUNCTION PROTOTYPES
===============================================================================================*/

#ifdef __cplusplus
}
#endif

#endif /* GPT_TPM_TYPES_H */

/** @} */
