;******************************************************************************
;  @file  lld_arm_r5.asm
;
;  @brief
;   Implementation file for the ARM R5 module CSL-FL.
;
;   Contains the different control command and status query functions definitions
;
;   \par
;   ============================================================================
;   @n   (C) Copyright 2024, Texas Instruments, Inc.
;
;   Redistribution and use in source and binary forms, with or without
;   modification, are permitted provided that the following conditions
;   are met:
;
;     Redistributions of source code must retain the above copyright
;     notice, this list of conditions and the following disclaimer.
;
;     Redistributions in binary form must reproduce the above copyright
;     notice, this list of conditions and the following disclaimer in the
;     documentation and/or other materials provided with the
;     distribution.
;
;     Neither the name of Texas Instruments Incorporated nor the names of
;     its contributors may be used to endorse or promote products derived
;     from this software without specific prior written permission.
;
;   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
;   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
;   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
;   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
;   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
;   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
;   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;  LOSS OF USE,
;   DATA, OR PROFITS;  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
;   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
;   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
;   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
;******************************************************************************
    .text

;==============================================================================
;   void LLD_armR5Dsb( void )
;==============================================================================
    .global LLD_armR5Dsb
LLD_armR5Dsb:
    DSB
    BX      lr

;==============================================================================
;   void LLD_armR5FpuEnable( uint32_t enable )
;==============================================================================
    .global LLD_armR5FpuEnable
LLD_armR5FpuEnable:
    MRC     p15, #0, r1, c1, c0, #2         ; Read CPACR into r1
    CMP     r0, #0
    BEQ     armR5FpuEnable_disable
    ORR     r1, r1, #(0xf << 20)            ; Enable full access for p10 & p11
    B       armR5FpuEnable_00
armR5FpuEnable_disable:
    BIC     r1, r1, #(0xf << 20)
armR5FpuEnable_00:
    MCR     p15, #0, r1, c1, c0, #2         ; Write back into CPACR
    ISB
    MOV     r0, #0x40000000
;    VMSR    FPEXC, r0                      ; Currently causing a build error
    BX      lr

;==============================================================================
;   void LLD_armR5CacheEnableICache( uint32_t enable )
;==============================================================================
    .global LLD_armR5CacheEnableICache
LLD_armR5CacheEnableICache:
    MRC     p15, #0, r1, c1, c0, #0         ; Read SCTLR
    CMP     r0, #0
    BEQ     armR5CacheEnableICaches_disable
    ORR     r1, r1, #(1<<12)                ; Set I bit (enable L1 instruction caches)
    MOV     r2, #0
    MCR     p15, #0, r2, c7, c5, #0         ; Invalidate entire instruction cache
    B       armR5CacheEnableICaches_00
armR5CacheEnableICaches_disable:
    BIC     r1, r1, #(1<<12)                ; Clear I bit (disable L1 instruction caches)
armR5CacheEnableICaches_00:
    DSB
    MCR     p15, #0, r1, c1, c0, #0         ; Write modified SCTLR
    ISB
    BX      lr

;==============================================================================
;   void LLD_armR5CacheEnableDCache( uint32_t enable )
;==============================================================================
    .global LLD_armR5CacheEnableDCache
LLD_armR5CacheEnableDCache:
    MRC     p15, #0, r1, c1, c0, #0         ; Read SCTLR
    CMP     r0, #0
    BEQ     armR5CacheEnableDCaches_disable
    ORR     r1, r1, #(1<<2)                 ; Set C bit (enable L1 data caches)
    DSB
    MOV     r2, #0
    MCR     p15, #0, r2, c15, c5, #0        ; Invalidate entire data cache
    B       armR5CacheEnableDCaches_00
armR5CacheEnableDCaches_disable:
    BIC     r1, r1, #(1<<2)                 ; Clear C bit (disable L1 data caches)
armR5CacheEnableDCaches_00:
    DSB
    MCR     p15, #0, r1, c1, c0, #0         ; Write modified SCTLR
    BX      lr

;==============================================================================
;   uint32_t LLD_armR5CacheGetIcacheLineSize(void )
;==============================================================================
    .global LLD_armR5CacheGetIcacheLineSize
LLD_armR5CacheGetIcacheLineSize:
    DMB
    MRC       p15, #0, r0, c0, c0, #1   ; Read Cache Type Register
    UBFX      r0, r0, #0, #4            ; Extract the iMinLine
    ADD       r0, r0, #2                ; Convert words to bytes
    MOV       r1, #1
    LSL       r0, r1, r0                ; Calculate the line size
    BX        lr

;==============================================================================
;   uint32_t LLD_armR5CacheGetDcacheLineSize(void )
;==============================================================================
    .global LLD_armR5CacheGetDcacheLineSize
LLD_armR5CacheGetDcacheLineSize:
    DMB
    MRC       p15, #0, r0, c0, c0, #1   ; Read Cache Type Register
    UBFX      r0, r0, #16, #4           ; Extract the DMinLine
    ADD       r0, r0, #2                ; Convert words to bytes
    MOV       r1, #1
    LSL       r0, r1, r0                ; Calculate the line size
    BX        lr

;==============================================================================
;   void LLD_armR5CacheEnableAllCache( uint32_t enable )
;==============================================================================
    .global LLD_armR5CacheEnableAllCache
LLD_armR5CacheEnableAllCache:
    PUSH    {lr}
    BL      LLD_armR5CacheEnableICache
    BL      LLD_armR5CacheEnableDCache
    POP     {lr}
    BX      lr

;==============================================================================
;   void LLD_armR5CacheInvalidateAllIcache( void )
;==============================================================================
    .global LLD_armR5CacheInvalidateAllIcache
LLD_armR5CacheInvalidateAllIcache:
    DMB     ; Ensure all previous memory accesses are completed
    MOV     r0, #0
    MCR     p15, #0, r0, c7, c5, #0         ; Invalidate I caches
    DSB
    ISB
    BX      lr

;==============================================================================
;   void LLD_armR5CacheInvalidateAllDcache( void )
;==============================================================================
    .global LLD_armR5CacheInvalidateAllDcache
LLD_armR5CacheInvalidateAllDcache:
    DMB     ; Ensure all previous memory accesses are completed
    MOV     r0, #0
    MCR     p15, #0, r0, c15, c5, #0        ; Invalidate D caches
    DSB
    ISB
    BX      lr

;==============================================================================
;   void LLD_armR5CacheInvalidateAllCache( void )
;==============================================================================
    .global LLD_armR5CacheInvalidateAllCache
LLD_armR5CacheInvalidateAllCache:
    PUSH    {lr}
    BL      LLD_armR5CacheInvalidateAllIcache
    BL      LLD_armR5CacheInvalidateAllDcache
    POP     {lr}
    BX      lr

;==============================================================================
;   void LLD_armR5CacheInvalidateIcacheMva( uint32_t address )
;==============================================================================
    .global LLD_armR5CacheInvalidateIcacheMva
LLD_armR5CacheInvalidateIcacheMva:
    DMB     ; Ensure all previous memory accesses are completed
    MCR     p15, #0, r0, c7, c5, #1
    DSB
    BX      lr

;==============================================================================
;   void LLD_armR5CacheInvalidateDcacheMva( uint32_t address )
;==============================================================================
    .global LLD_armR5CacheInvalidateDcacheMva
LLD_armR5CacheInvalidateDcacheMva:
    MCR     p15, #0, r0, c7, c6, #1
    BX      lr

;==============================================================================
;   void LLD_armR5CacheInvalidateDcacheSetWay( uint32_t set, uint32_t way )
;==============================================================================
    .global LLD_armR5CacheInvalidateDcacheSetWay
LLD_armR5CacheInvalidateDcacheSetWay:
    DMB     ; Ensure all previous memory accesses are completed
    AND     r1, r1, #0x3
    LSL     r0, #(32-9)
    LSR     r0, #(32-9)                     ; set &= 0x1FF
    LSL     r1, r1, #30
    ORR     r0, r1, r0, LSL #5
    MCR     p15, #0, r0, c7, c6, #2
    DSB
    BX      lr

;==============================================================================
;   void LLD_armR5CacheCleanDcacheMva( uint32_t address )
;==============================================================================
    .global LLD_armR5CacheCleanDcacheMva
LLD_armR5CacheCleanDcacheMva:
    MCR     p15, #0, r0, c7, c10, #1
    BX      lr

;==============================================================================
;   void LLD_armR5CacheCleanDcacheSetWay( uint32_t set, uint32_t way )
;==============================================================================
    .global LLD_armR5CacheCleanDcacheSetWay
LLD_armR5CacheCleanDcacheSetWay:
    DMB     ; Ensure all previous memory accesses are completed
    AND     r1, r1, #0x3
    LSL     r0, #(32-9)
    LSR     r0, #(32-9)                     ; set &= 0x1FF
    LSL     r1, r1, #30
    ORR     r0, r1, r0, LSL #5
    MCR     p15, #0, r0, c7, c10, #2
    DSB
    BX      lr

;==============================================================================
;   void LLD_armR5CacheCleanInvalidateDcacheMva( uint32_t address )
;==============================================================================
    .global LLD_armR5CacheCleanInvalidateDcacheMva
LLD_armR5CacheCleanInvalidateDcacheMva:
    MCR     p15, #0, r0, c7, c14, #1
    BX      lr

;==============================================================================
;   void LLD_armR5CacheCleanInvalidateDcacheSetWay( uint32_t set, uint32_t way )
;==============================================================================
    .global LLD_armR5CacheCleanInvalidateDcacheSetWay
LLD_armR5CacheCleanInvalidateDcacheSetWay:
    DMB     ; Ensure all previous memory accesses are completed
    AND     r1, r1, #0x3
    LSL     r0, #(32-9)
    LSR     r0, #(32-9)                     ; set &= 0x1FF
    LSL     r1, r1, #30
    ORR     r0, r1, r0, LSL #5
    MCR     p15, #0, r0, c7, c14, #2
    DSB
    BX      lr

;==============================================================================
;   void LLD_armR5CacheEnableForceWrThru( uint32_t enable )
;==============================================================================
    .global LLD_armR5CacheEnableForceWrThru
LLD_armR5CacheEnableForceWrThru:
    MRC     p15, #0, r1, c1, c0, #1         ; Read Auxiliary Control Register
    CMP     r0, #0
    BEQ     armR5CacheEnableForceWrThru_disable
    ORR     r1, r1, #(1<<9)                 ; Set (enable) force Write-thru bit for write-back (WB) regions
    B       armR5CacheEnableForceWrThru_00
armR5CacheEnableForceWrThru_disable:
    BIC     r1, r1, #(1<<9)                 ; Clear (disable) force Write-thru bit for write-back (WB) regions
armR5CacheEnableForceWrThru_00:
    MCR     p15, #0, r1, c1, c0, #1         ; Write modified Auxiliary Control Register
    BX      lr

;==============================================================================
;   void LLD_armR5CacheDisableEcc( void )
;==============================================================================
    .global LLD_armR5CacheDisableEcc
LLD_armR5CacheDisableEcc:
    PUSH    {lr}
    MOV     r0, #0
    BL      LLD_armR5CacheEnableAllCache    ; Disable instruction and data caches

    MRC     p15, #0, r0, c1, c0, #1         ; Read Auxiliary Control register
    BIC     r0, r0, #(0x7<<3)               ; Clear CEC field
    ORR     r0, r0, #(1<<5)                 ; Set CEC field to 3'b100 (disable parity checking)
    ORR     r0, r0, #(1<<9)                 ; Enable Write Through Cache RAMS
    MCR     p15, #0, r0, c1, c0, #1         ; Write Auxiliary Control register

    BL      LLD_armR5CacheInvalidateAllCache
    MOV     r0, #1
    BL      LLD_armR5CacheEnableAllCache    ; Enable instruction and data caches
    POP     {lr}
    BX      lr

;==============================================================================
;   void LLD_armR5CacheEnableAxiAccess( void )
;==============================================================================
    .global LLD_armR5CacheEnableAxiAccess
LLD_armR5CacheEnableAxiAccess:
    MRC     p15, #0, r0, c1, c0, #1         ; Read Auxiliary Control register
    ORR     r0, r0, #(1<<24)                ; Set AXISCEN bit (enable AXI slave cache RAM access)
    MCR     p15, #0, r0, c1, c0, #1         ; Write Auxiliary Control register
    BX      lr

;==============================================================================
;   uint32_t LLD_armR5ReadMpidrReg(void )
;==============================================================================
    .global LLD_armR5ReadMpidrReg
LLD_armR5ReadMpidrReg:
    DMB
    MRC p15, #0, r0, c0, c0, #5 ; Read MPIDR
    BX        lr

;==============================================================================
;   uintptr_t LLD_armR5GetCpsrRegVal( void );
;==============================================================================
    .global LLD_armR5GetCpsrRegVal
LLD_armR5GetCpsrRegVal:
    MRS     r0, CPSR                        ; Read CPSR
    BX      lr

