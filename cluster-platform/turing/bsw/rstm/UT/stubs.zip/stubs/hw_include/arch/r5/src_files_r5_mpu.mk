
ifeq ($(SOC),$(filter $(SOC), am65xx j7200 j721e j784s4 j742s2 j721s2 j722s am77x tpr12 awr294x am263x am64x am62x am62ax am62dx am275x))

  PACKAGE_SRCS_COMMON += hw_include/arch/r5/src/csl_arm_r5_mpu.asm
  PACKAGE_SRCS_COMMON += hw_include/arch/r5/src_files_r5_mpu.mk
  ifeq ($(ARCH),armv7r)
    SRCDIR += ./arch/r5/src
    INCDIR += ./arch/r5
    SRCS_ASM_COMMON += csl_arm_r5_mpu.asm
  endif

endif
