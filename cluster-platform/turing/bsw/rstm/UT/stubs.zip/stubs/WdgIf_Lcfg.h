/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2012. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/
/*****************************************************************************
*  File Name         :  WdgIf_Lcfg.h                                              *
*  Module Short Name :  WdgIf                                               *
*  VOBName           :                                                       *
*  Author            :                                               *
*  Description       :                              *
*                                                                            *
*                                                                            *
* Organization     :  Driver Information Software Section,                   *
*                     Visteon Software Operation                             *
*                     Visteon Corporation                                    *
*                                                                            *
* ---------------------------------------------------------------------------*
* Compiler Name    :  GHS                                                    *
* Target Hardware  :                                                         *
*                                                                            *
******************************************************************************/
#ifndef WDGIF_LCFG_H
#define WDGIF_LCFG_H
/*****************************************************************************
*                            Include files                                   *
******************************************************************************/
#include "WdgIf_Types.h"
#include "Std_Types.h"



/*****************************************************************************
*                                 Macro Definitions                          *
*----------------------------------------------------------------------------*
* Definition of macro shall be followed by a comment that explains the       *
* purpose of the macro.                                                      *
******************************************************************************/

#define WDGIF_NUMBER_OF_DEVICES_SUPPORTED        1u

/*****************************************************************************
*                                 Type Declarations                          *
******************************************************************************/



typedef struct
{
    void (*SetTriggerPointer)(uint8, uint16);
    Std_ReturnType (*SetModePointer)(WdgIf_ModeType);
} WdgIf_FunctionPointerType;

/*****************************************************************************
*                                Globally  accessed Variable Declarations    *
*----------------------------------------------------------------------------*
* Declaration shall be followed by a comment that gives the following info.  *
* about the variable.                                                        *
* purpose, critical section, unit, and resolution                            *
******************************************************************************/
extern const WdgIf_FunctionPointerType WdgIF_FunctionPointer[WDGIF_NUMBER_OF_DEVICES_SUPPORTED];
/*****************************************************************************
*                                 Locally used Variable Declarations         *
*----------------------------------------------------------------------------*
* Declaration shall be followed by a comment that gives the following info.  *
* about the variable.                                                        *
* purpose, critical section, unit, and resolution                            *
******************************************************************************/


/*****************************************************************************
*                              Limited Scope Prototypes                      *
******************************************************************************/

/*****************************************************************************
*                   Functions                                                *
******************************************************************************/

#endif /* WDGIF_CFG_H */
/*****************************************************************************
*     End of File
*
*******************************************************************************/
