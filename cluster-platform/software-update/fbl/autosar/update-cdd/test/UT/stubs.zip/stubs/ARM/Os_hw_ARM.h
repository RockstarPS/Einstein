/* Os_hw_ARM
 *
 * This file defines the architecture specific macros, derived from Makefiles
 *
 * CHECK: TABS 4 (see editor commands at end of file)
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
*/
#ifndef OS_HW_ARM_H
#define OS_HW_ARM_H

/* Currently no architecture specific macros */

#endif /* OS_HW_ARM_H */
/* Editor settings - DO NOT DELETE
 * vi:set ts=4:
*/

