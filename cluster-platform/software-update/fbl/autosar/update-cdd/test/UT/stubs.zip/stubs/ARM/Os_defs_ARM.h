/* Os_defs_ARM.h - ARM definitions for derivative selection etc.
 *
 * CHECK: TABS 4 (see editor commands at end of file)
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
*/

#ifndef OS_DEFS_ARM_H
#define OS_DEFS_ARM_H

/* CPUs. OS_CPU must be one of these.
 *
 * CAVEAT:
 * The existence of a ARM derivative in this list does not imply a
 * commitment or intention to support the derivative.
 *
 * Tip: using a value of 0 is not recommended because "undefined" also means
 * zero in the preprocessor.
 * Some values were assigned in the past for obsolete ARM derivatives.
 * These numbers mentioned below are deprecated and not recommended to be used in future.
 * 0x004, 0x006, 0x007, 0x009, 0x00b, 0x00d, 0x00e, 0x00f, 0x010, 0x012,
 * 0x01a, 0x02B, 0x030
*/
#define OS_TMS570LS20216	0x001
#define OS_TMS570LS30336	0x002
#define OS_STA8088EX		0x003
#define OS_VF6XX			0x008
#define OS_TMS570LS1113		0x00a
#define OS_STA8090			0x00c
#define OS_RCARV3MCR7		0x011
#define OS_RCARM3CR7		0x013
#define OS_S32S247			0x014
#define OS_BCM89531			0x015
#define OS_ZUXEVCR5			0x016
#define OS_RCARV3HCR7		0x017
#define OS_RCARM3NCR7		0x018
#define OS_SR6P7			0x031	/* Same as Platforms */
#define OS_SR6G7			0x032	/* Same as Platforms */
#define OS_TDA4VMCR5		0x02e	/* Same as Platforms */
#define OS_MV88Q515X		0x033	/* Same as Platforms */
#define OS_S32Z27X			0x035
#define OS_G9XCR5			0x037	/* Same as Platforms */
#define OS_RCARS4CR52		0x038
#define OS_EXYNOSAV9		0x039	/* Same as Platforms */
#define OS_SR6P6			0x03a	/* Same as Platforms */
#define OS_AM2634			0x03f   /* Same as platforms */
#define OS_E36XX			0x040   /* Same as platforms */
#define OS_MVQ622X			0x044   /* Same as platforms */

/* Interrupt vector mapping. OS_ARM_INT_VECTOR_MAPPING must be one of these. */
#define OS_ARM_INT_MAP_BY_PRIO		0x1	/* vectors are mapped by priority */
#define OS_ARM_INT_MAP_BY_SOURCE	0x2	/* vectors are mapped by source */

/* Interrupt controllers. OS_ARM_INT_CTRL must be one of these.
 *
 * CAVEAT:
 * The existence of an interrupt controller in this list does not imply a
 * commitment or intention to support the controller.
*/
#define OS_ARM_INT_TI_VIM			0x001 /* TI VIM interrupt controller */
#define OS_ARM_INT_VIC				0x002 /* ARM VIC interrupt controller */
#define OS_ARM_INT_IUNIT			0x003 /* Fujitsu IUNIT interrupt controller */
#define OS_ARM_INT_GIC				0x004 /* ARM GIC interrupt controller */
#define OS_ARM_INT_GICV3			0x005 /* ARM GICv3 interrupt controller */
#define OS_ARM_INT_VICV2			0x006 /* ARM VICv2 interrupt controller */
#define OS_ARM_INT_TI_TDA4VM_VIM	0x007 /* TI TDA4VM VIM interrupt controller */

/* Vectorization. OS_ARM_INT_VECTORIZATION must be one of these.
*/
#define OS_ARM_INT_HARDWARE_VECTOR	0x1	/* hardware dispatched vectors */
#define OS_ARM_INT_SOFTWARE_VECTOR	0x2	/* dispatched via IRQ exception */

/* End of Interrupt signalling scheme. OS_ARM_INT_EOI_SCHEME must be one
 * of these.
 */
#define OS_ARM_INT_EOI_SCHEME_NONE		0x1	/* EOI is not needed at all */
#define OS_ARM_INT_EOI_SCHEME_REGULAR	0x2	/* EOI is performed at ISR exit */
#define OS_ARM_INT_EOI_SCHEME_EARLY		0x3	/* EOI is performed at ISR entry */

/* Instruction sets. OS_ARM_INSTR_SET must be one of these.
 * Instruction sets that extent an earlier variant must specify
 * a higher number.
 */
#define OS_ARM_INSTR_SET_ARMV7		0x007
#define OS_ARM_INSTR_SET_ARMV8		0x008

/* Preferred encodings. OS_ARM_ENCODING must be one of these.
 */
#define OS_ARM_ENCODING_ARM			0x01
#define OS_ARM_ENCODING_THUMB		0x02
#define OS_ARM_ENCODING_THUMB_ONLY	0x03

/* The inKernel flag is set during IRQ entry.
 * This is necessary for the IUNIT, and doesn't hurt for other interrupt
 * controllers. If an interrupt occurs in the timeframe between the vector
 * entry and setting the locking mask, IUNIT will deliver this interrupt so
 * that the vector is taken right after enabling interrupts again.
 * As a consequence, OS_GetKernelData()->inKernel must be set prior to enabling
 * interrupts to avoid a nested interrupt handler to dispatch tasks.
 */
#define OS_USE_IRQ_ATOMIC_INKERNEL 1

/* FPU that can be supported by the core.
 *
 * CAVEAT:
 * The existence of a FPU in this list does not imply a
 * commitment or intention to support the FPU.
 */
#define OS_ARM_FPU_NONE			0x001		/* no FPU */
#define OS_ARM_FPU_VFPV3_D16	0x002		/* VFPv3 with 16 registers */
#define OS_ARM_FPU_VFPV3_D32	0x003		/* VFPv3 with 32 registers */

#endif /* ! OS_DEFS_ARM_H */
/* Editor settings; DO NOT DELETE
 * vi:set ts=4:
*/
