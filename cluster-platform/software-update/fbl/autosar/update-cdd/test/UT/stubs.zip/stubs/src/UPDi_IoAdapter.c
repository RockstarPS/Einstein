/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/
#include "UPDi.h"
#include "Std_Types.h"
#ifdef VCAST_UT
#include "Stub.h"
#endif


//=====================================================================================================================
/* CONSTANTS & TYPES */
#ifdef VCAST_UT
tUPDiIoReq IoReqInfo;
#else
static tUPDiIoReq IoReqInfo;
#endif



//=======================================================================================================================
/*Static Variables*/
//=====================================================================================================================
//  Static Functions
//=====================================================================================================================

//=====================================================================================================================
//  Private functions
//=====================================================================================================================
/*========================================================================================================================
* Std_ReturnType UPDIoAdapter_Idle(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget))
* Function description : 
* Return :    
*=======================================================================================================================*/ 
Std_ReturnType UPDIoAdapter_Idle(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget)
{
    Std_ReturnType status = E_OK;
    return status;
}
/*========================================================================================================================
* Std_ReturnType UPDIoAdapter_Hash(tUPDiIoAdapter* this, const struct sUPDTarget* pTarget, tUPDiPartition* pPartition, uint32 Offset, uint32 Size, tUPDiHashingContext* HashingContext)
* Function description : This function shall perform verification
* Return : 
*============================================================================================================================================*/ 
Std_ReturnType UPDIoAdapter_Hash(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget, tUPDiPartition* pPartition, uint32 Offset, uint32 Size, tUPDiHashingContext* HashingContext)
{
    Std_ReturnType status = E_OK;
    return status;
}
/*========================================================================================================================
* Std_ReturnType UPDIoAdapter_Read(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget, tUPDiPartition* pPartition, uint32 Offset, uint32 Size))
* Function description : Io adapter read function
* Return : 
*============================================================================================================================================*/
Std_ReturnType UPDIoAdapter_Read(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget, tUPDiPartition* pPartition, uint32 Offset, uint32 Size)
{
    Std_ReturnType ReadStatus;

    /*IO request info initializations*/
    IoReqInfo.Address = Offset;
    IoReqInfo.Size = Size; /* tester size*/
    IoReqInfo.pTarget = pTarget;
    IoReqInfo.ReqType = eUPDiIoReq_Read;

    ReadStatus = this->Vtbl->ProcessReq(&IoReqInfo);
    return ReadStatus;
}
/*========================================================================================================================
* Private function : Std_ReturnType UPDIoAdapter_Write(tUPDiIoAdapter* this, const struct sUPDTarget* pTarget, tUPDiPartition* pPartition, uint32 Offset, uint32 Size, uint8* Data)  
* Function description : This function shall pack datas that are needed to program on flash
* Return : E_OK - datas that are required for software update are packed
*          E_PENDING - packaging is in progress
*=======================================================================================================================*/
Std_ReturnType UPDIoAdapter_Write(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget, tUPDiPartition* pPartition, uint32 Offset, uint32 Size, uint8* Data)
{
    Std_ReturnType Status = E_OK;

    /*IO request info initializations*/
    IoReqInfo.Address = Offset;
    IoReqInfo.Size = Size; 
    IoReqInfo.pTarget = pTarget;
    IoReqInfo.ReqType = eUPDiIoReq_Write;
    IoReqInfo.pIoAdapter = this;
    IoReqInfo.pIoAdapter->Ram->AdapterBuffer = Data;
    
    if(0u ==(this->Ram->PendingCalls))
    {
        this->Ram->PendingCalls = 1u;
   
    }
    
    return Status;
}
/*========================================================================================================================
* Std_ReturnType UPDIoAdapter_Erase(tUPDiIoAdapter* this, const struct sUPDTarget* pTarget, tUPDiPartition* pPartition,uint32 targetAddress,uint32 size)  
* Function description : This function shall place erase order on Fls/Hsm/hyperflash module
* Return               : E_OK - erase order accepted by Fls/Hsm/hyperflash module
*                        E_NOT_OK - erase order not accepted by Fls/Hsm/hyperflash module
*=======================================================================================================================*/
Std_ReturnType UPDIoAdapter_Erase(tUPDiIoAdapter* this, const struct sUPDiTarget* pTarget, tUPDiPartition* pPartition,uint32 targetAddress,uint32 size)
{
    Std_ReturnType status = E_OK;
    
    /*fill IO request structure members*/
    IoReqInfo.Address = targetAddress;
    IoReqInfo.Size = size;
    IoReqInfo.pTarget = pTarget;
    IoReqInfo.ReqType = eUPDiIoReq_Erase;
    IoReqInfo.pIoAdapter = this;
    
    /*call to low level IOadapter*/
    status = this->Vtbl->ProcessReq(&IoReqInfo);

    /*return the status*/
    return status;
}
/*========================================================================================================================
* boolean UPDIoAdapter_IsBusy(tUPDiIoAdapter* this)  
* Function description : indicate if some IO operation are pending
* Return               : 
*=======================================================================================================================*/
boolean UPDIoAdapter_IsBusy(tUPDiIoAdapter* this) 
{
    boolean busy = FALSE;
    
    if(0u != this->Ram->PendingCalls)
    {
        busy = TRUE;
    }
    return busy;  
}

//=====================================================================================================================
//  Management functions
//=====================================================================================================================
Std_ReturnType  UPDIoAdapter_Init(void)
{
    Std_ReturnType status = E_OK;
    uint8 index = 0;

    /*IoReq initilization*/
    IoReqInfo.ReqType = eUPDiIoReq_Init;
    IoReqInfo.Address = 0uL;
    IoReqInfo.Size = 0uL;
    IoReqInfo.pTarget = NULL;    

    for (index = 0; index < oUPDCdd.IoAdaptersCount; index++)
    {
        (*((&(*oUPDCdd.IoAdapters)[index])->Vtbl->ProcessReq))(&IoReqInfo);
    }
    
    return status; 
}

Std_ReturnType UPDIoAdapter_SetIdle(void)
{
    Std_ReturnType status = E_OK;

    /*IoReq initilization*/
    IoReqInfo.ReqType = eUPDiIoReq_Idle;

    return status; 
}
/*===========================================================================================================================================
* Private function : Std_ReturnType UPDIoAdapter_Task(tUPDiIoAdapter* this)
*============================================================================================================================================*/
Std_ReturnType UPDIoAdapter_Task(void)
{
	Std_ReturnType status = E_OK;
    tUPDBank fl_BankType;
        switch(IoReqInfo.ReqType)
		{ 
            /*check for erase request*/
			case eUPDiIoReq_Erase:
			{
                fl_BankType = UPDUpdateMan_GetUpdateBankType();
				status = UPDTarget_IoEraseConf(IoReqInfo.pTarget, fl_BankType);
			}
			break;
            /*check for write request*/
			case eUPDiIoReq_Write:
			{
                if(1u == IoReqInfo.pIoAdapter->Ram->PendingCalls)
                {  
                    status =  IoReqInfo.pIoAdapter->Vtbl->ProcessReq(&IoReqInfo);
                    /*check if write is completed or not*/
                    if(status == E_OK)
                    {
                        fl_BankType = UPDUpdateMan_GetUpdateBankType();
                        /*write operation is completed*/
				        status = UPDTarget_IoWriteConf(IoReqInfo.pTarget, IoReqInfo.Size, fl_BankType);
                        IoReqInfo.pIoAdapter->Ram->PendingCalls = 0uL;
                    }
                    else if(status == E_NOT_OK)
                    {
                        /*write operation failed*/
                        UPDTarget_SetState(IoReqInfo.pTarget,eUPDiTarget_UninstFailed);
                    }
                    else
                    {
                        status = E_PENDING;
                        UPDTarget_SetState(IoReqInfo.pTarget,eUPDiTarget_Installing);
                    }
                }
			}
			break;
            /*check for read request*/
			case eUPDiIoReq_Read:
			{
                fl_BankType = UPDUpdateMan_GetUpdateBankType();
				status = UPDTarget_IoReadConf(IoReqInfo.pTarget, fl_BankType);
			}
			break;
            /*check for hash request*/
			case eUPDiIoReq_Hash:
			{
				status = UPDTarget_IoHashConf(IoReqInfo.pTarget,IoReqInfo.pHashingContext);
			}
			break;
            case eUPDiIoReq_Idle:
            case eUPDiIoReq_Decrypt:
            case eUPDiIoReq_SignVerify:
			default:
			{
				/* Do Nothing */
                status = E_OK;
			}
			break;
        }
    /*return*/       
    return status;
}
