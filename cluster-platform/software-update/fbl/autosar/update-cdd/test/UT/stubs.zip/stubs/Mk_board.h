/* Mk_board.h - board specific ASIL header file for the DISCOVERYV9 board
 *
 * (c) by Elektrobit Automotive Software
 *
 * $Id: Mk_board.h 45925 2022-09-29 15:25:01Z waab271441 $
*/

#ifndef MK_BOARD_H
#define MK_BOARD_H

/* Verify that the version of the board files matches the version of the microkernel */
#include <Mk_Version.h>
#include <Mk_board_version_check.h>

#include <public/Mk_timeconversion.h>

#ifndef MK_ASM

/* Conversion macros for the timestamp. The generic virtual timer is used as a
 * timestamp timer which is derived by MCT's global timer.
 *
 * MK_TimestampNsToTicks() converts the parameter (time in nanoseconds) to
 * ticks of the timebase/decrementer.
 * MK_TimestampTicksToNs(0 converts the parameter (no. of ticks) to
 * nanoseconds. If the time would be larger
 * than can be represented by a 32-bit unsigned number, the maximum possible
 * (Oxffffffff) is returned.
 *
 * Both of the above conversions are performed using integer arithmetic, so
 * can be used to initialize constants.
 *
 * MK_TimestampNsToTicksF() and MK_TimestampTicksToNsF() perform the
 * equivalent conversions using a function
 * call and 48-bit integer arithmetic. The advantage is better accuracy, at
 * the cost of slightly more CPU time.
*/
#define MK_TimestampNsToTicks(ns)			MK_NsToTicks_26000000(ns)
#define MK_TimestampNsToTicksF(ns)			MK_NsToTicksF_26000000(ns)
#define MK_TimestampTicksToNs(tx)			MK_TicksToNs_26000000(tx)
#define MK_TimestampTicksToNsF(tx)			MK_TicksToNsF_26000000(tx)

/* Conversion macros for the microkernel's ticker timers. MCT's global timer
 * comparators are used for this purpose.
 *
 * MK_TickerNsToTicks() converts the parameter (time in nanoseconds) to
 * ticks of the timebase/decrementer.
 * MK_TickerTicksToNs() converts the parameter (no. of ticks) to
 * nanoseconds. If the time would be larger
 * than can be represented by a 32-bit unsigned number, the maximum possible
 * (Oxffffffff) is returned.
 *
 * Both of the above conversions are performed using integer arithmetic, so
 * can be used to initialize constants.
 *
 * MK_TickerNsToTicksF() and MK_TickerTicksToNsF() perform the
 * equivalent conversions using a function
 * call and 48-bit integer arithmetic. The advantage is better accuracy, at
 * the cost of slightly more CPU time.
*/
#define MK_TickerNsToTicks(ns)				MK_NsToTicks_26000000(ns)
#define MK_TickerNsToTicksF(ns)				MK_NsToTicksF_26000000(ns)
#define MK_TickerTicksToNs(tx)				MK_TicksToNs_26000000(tx)
#define MK_TickerTicksToNsF(tx)				MK_TicksToNsF_26000000(tx)

/* Execution timer also uses the generic virtual timer derived by MCT's global timer. */
#define MK_ExecutionNsToTicks(ns)			MK_TimestampNsToTicks(ns)

#define MK_TIMESTAMPCLOCKFACTOR100U 		MK_U(2600)
#define MK_TIMESTAMPCLOCKFACTOR10U			MK_U(260)
#define MK_TIMESTAMPCLOCKFACTOR1U			MK_U(26)

#define MK_HAS_TIMESTAMPCLOCKFACTOR100U		MK_U(1)
#define MK_HAS_TIMESTAMPCLOCKFACTOR10U		MK_U(1)
#define MK_HAS_TIMESTAMPCLOCKFACTOR1U		MK_U(1)

/*
 * Prototype for main()
 *
 * The microkernel will actually not use the returned value, but this prototype
 * was chosen, because it is also one of (hosted) C's standard prototypes.
*/
extern int main(void);

extern void MK_BoardEarlyInit(mk_objectid_t);

#endif /* MK_ASM */
#endif /* MK_BOARD_H */
