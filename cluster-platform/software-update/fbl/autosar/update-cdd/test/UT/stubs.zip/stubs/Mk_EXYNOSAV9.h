/* Mk_EXYNOSAV9.h - Description of ARM derivative EXYNOSAV9
 *
 * This file describes the EXYNOSAV9 variant of ARM.
 *
 * (c) Elektrobit Automotive GmbH
*/
#ifndef MK_EXYNOSAV9_H
#define MK_EXYNOSAV9_H

/* Max. number of cores supported by the derivative.
 * A core's index is formed by considering the Aff0 field of MPIDR.
*/
#define MK_HWMAXCORES				MK_U(1)

/* Settings for instruction/data cache */
#define MK_HAS_ICACHE				1
#define MK_HAS_DCACHE				1
/* Only relevant for cross-core communication so assign random values */
#define MK_ARM_CACHE_MODE			MK_ARM_CACHE_MODE_NONE
#define MK_ARM_CACHE_LINE_LEN		MK_U(64)
#define MK_CACHEOP_PRIVILEGE		MK_CACHEOP_SUPERVISOR

/* Endianess */
#define MK_HWENDIAN					MK_LITTLEENDIAN

/* Encoding */
#define MK_ARM_ENCODING				MK_ARM_ENCODING_ARM

/* EXYNOSAV9 has a generic interrupt controller (GIC), version 3.0/4.0. */
#define MK_INTERRUPTCONTROLLER		MK_GIC_V3
#define MK_GIC_LEVEL_BITS			MK_U(5)

/* Base address for interrupt distributor (ICD). */
#define MK_GIC_ICD_BASE_CORE0		MK_U(0xEFA00000)

/* Base addresses for redistributors. */
#define MK_GIC_ICR_CONTROL_CORE0	(MK_GIC_ICD_BASE_CORE0 + MK_U(0x100000))
#define MK_GIC_ICR_SGIPPI_CORE0		(MK_GIC_ICD_BASE_CORE0 + MK_U(0x110000))

/* Mask for valid affinity bits in the MPIDR (needed to program the IROUTER
 * register).
*/
#define MK_GIC_AFFINITY_MASK		MK_U(0x00ffffff)

/* EXYNOSAV9 has 8 vectors in the interrupt vector table. */
#define MK_ARM_NVEC					MK_U(8)

/* EXYNOSAV9 can relocate the exception table freely via VBAR. */
#define MK_ARM_EXCEPTION_TABLE		MK_ARM_EXCEPTION_TABLE_VBAR

/* EXYNOSAV9 has 512 interrupt sources */
#define MK_HWN_INTERRUPTVECTORS		MK_U(512)

/* Highest vector actually present in the hardware. */
#define MK_HW_MAX_VECTOR			MK_U(294)

/* Derivate does not have non-maskable FIQs */
#define MK_ARM_NON_MASKABLE_FIQ		MK_FALSE

/* FPU selection.
 * This target has a double-precision FPU (a VFP3D32) (Media and Floating-point Feature Register 0 MVFR0)
*/
#define MK_FPU_NREGS				MK_U(32)
#define MK_FPU						MK_FPU_VFP3D32
#define MK_C0_FPU					MK_FPU_VFP3D32

/* VFPv3d32 subarch/revision/variant/part number (field in FPSID). */
#define MK_VFP_SUBARCH				MK_U(0x03)
#define MK_VFP_REVVARPAR			MK_U(0x4022)

/* Selection of memory protection. */
#define MK_MEM_PROT					MK_MEM_PROT_MPU
#define MK_ARM_MPU_TYPE				MK_ARM_MPU_V8R

/* EXYNOSAV9 has 24 MPU regions */
#define MK_HWN_REGION_DESCRIPTOR	24

/* Access permissions for IO regions. */
#define MK_MPU_MK_IO0_PERM			MK_MPERM_S_RW
#define MK_MPU_MK_IO1_PERM			MK_MPERM_S_RW

/* Memory attribute definitions. */

/* Device memory, nGnRnE. */
#define MK_MPU_DEVICE				( MK_ARM_MPU_MAIR_ATT_DEV			\
									| MK_ARM_MPU_MAIR_ATT_DEV_NGNRNE	\
									)

/* Outer and inner write-back, non-transient, read- and write-allocate.
 * On R52, write-back is treated as write-through. So MK_MPU_RAM
 * and MK_MPU_RAM_WRITETHROUGH have same behavior.
*/
#define MK_MPU_RAM					( MK_ARM_MPU_MAIR_ATT_OWBNT	\
									| MK_ARM_MPU_MAIR_ATT_ORA	\
									| MK_ARM_MPU_MAIR_ATT_OWA	\
									| MK_ARM_MPU_MAIR_ATT_IWBNT	\
									| MK_ARM_MPU_MAIR_ATT_IRA	\
									| MK_ARM_MPU_MAIR_ATT_IWA	\
									)

/* Outer and inner write-through, non-transient, read- and write-allocate. */
#define MK_MPU_RAM_WRITETHROUGH		( MK_ARM_MPU_MAIR_ATT_OWTNT	\
									| MK_ARM_MPU_MAIR_ATT_ORA	\
									| MK_ARM_MPU_MAIR_ATT_OWA	\
									| MK_ARM_MPU_MAIR_ATT_IWTNT	\
									| MK_ARM_MPU_MAIR_ATT_IRA	\
									| MK_ARM_MPU_MAIR_ATT_IWA	\
									)

/* Outer and inner non-cached. */
#define MK_MPU_RAM_NON_CACHED		( MK_ARM_MPU_MAIR_ATT_ONC	\
									| MK_ARM_MPU_MAIR_ATT_INC	\
									)

/* GVTimer can be used to deliver a 64-bit time stamp
 * This means that MK_GenericReadTime() and MK_ExtendTimer() are not required.
 *
 * !LINKSTO Microkernel.Function.MK_GenericReadTime, 1,
 * !        Microkernel.Function.MK_ExtendTimer, 1,
 * !        Microkernel.ARM.GVTimer.HwTimestamp.MK_HW_HAS_TIMESTAMP, 1
 * !doctype src
*/
#define MK_HW_HAS_TIMESTAMP			1
#define MK_ARM_TIMESTAMP_TIMER		MK_ARM_GVTIMER

/* Use GVTimer for execution budget monitoring */
#define MK_ARM_EXECUTION_TIMER		MK_ARM_GVTIMER

/* EXYNOSAV9 has Multicore Timer Module's (MCT) global timer for SSTs. */
#define MK_ARM_SST_TICKER			MK_ARM_MCT
#define MK_ARM_MCTG_NCOMP			MK_U(4)
#define MK_ARM_MCTL_NCHANNEL		MK_U(8)
/* Address taken from TRM: Section 19.4.1 and mapped from Table 48-1 Memory Map (SFI_SFR)
 * and 48.4.1 Register Map Summary.
*/
#define MK_ARM_MCT_BASE_ADDR		MK_U(0xFD2B0000)

/* EXYNOSAV9 uses reservations for OS locks */
#define MK_ARM_HW_LOCK_METHOD		MK_ARM_RESERVATIONS
/* Exclusive reservation granule in words (4 byte units), see CTR.ERG */
#define MK_ARM_EXCL_RES_GRANULE		MK_U(16)

#endif /* MK_EXYNOSAV9_H */

/* Editor settings: DO NOT DELETE
 * vi: set ts=4:
*/
