/* Os_ARM_timer_mct_config.h - configuration of Samsung Exynos Auto V9's Multi Core Timer (MCT)
 *
 * CHECK: TABS 4 (see editor commands at end of file)
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
*/
#ifndef OS_ARM_TIMER_MCT_CONFIG_H
#define OS_ARM_TIMER_MCT_CONFIG_H

#define OS_NsToTicks_MCTG0_0(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_NsToTicks_MCTG1_0(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_NsToTicks_MCTG2_0(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_NsToTicks_MCTG3_0(ns)		OS_BoardMCTNsToTicks(ns)

#define OS_TicksToNs_MCTG0_0(ticks)		OS_BoardMCTTicksToNs(ticks)
#define OS_TicksToNs_MCTG1_0(ticks)		OS_BoardMCTTicksToNs(ticks)
#define OS_TicksToNs_MCTG2_0(ticks)		OS_BoardMCTTicksToNs(ticks)
#define OS_TicksToNs_MCTG3_0(ticks)		OS_BoardMCTTicksToNs(ticks)

#define OS_NsToTicks_MCTL0_0(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_NsToTicks_MCTL1_0(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_NsToTicks_MCTL2_0(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_NsToTicks_MCTL3_0(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_NsToTicks_MCTL4_0(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_NsToTicks_MCTL5_0(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_NsToTicks_MCTL6_0(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_NsToTicks_MCTL7_0(ns)		OS_BoardMCTNsToTicks(ns)

#define OS_TicksToNs_MCTL0_0(ticks)		OS_BoardMCTTicksToNs(ticks)
#define OS_TicksToNs_MCTL1_0(ticks)		OS_BoardMCTTicksToNs(ticks)
#define OS_TicksToNs_MCTL2_0(ticks)		OS_BoardMCTTicksToNs(ticks)
#define OS_TicksToNs_MCTL3_0(ticks)		OS_BoardMCTTicksToNs(ticks)
#define OS_TicksToNs_MCTL4_0(ticks)		OS_BoardMCTTicksToNs(ticks)
#define OS_TicksToNs_MCTL5_0(ticks)		OS_BoardMCTTicksToNs(ticks)
#define OS_TicksToNs_MCTL6_0(ticks)		OS_BoardMCTTicksToNs(ticks)
#define OS_TicksToNs_MCTL7_0(ticks)		OS_BoardMCTTicksToNs(ticks)

/* Conversion macros for the Timebase Timer */
#define OS_NsToTicks_TbTimer(ns)		OS_BoardMCTNsToTicks(ns)
#define OS_TicksToNs_TbTimer(ticks)		OS_BoardMCTTicksToNs(ticks)

#endif /* OS_ARM_TIMER_MCT_CONFIG_H */
