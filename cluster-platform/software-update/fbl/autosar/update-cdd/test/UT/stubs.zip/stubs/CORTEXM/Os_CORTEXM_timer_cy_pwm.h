/* Os_CORTEXM_timer_cy_pwm.h - Description of Cypress Traveo II PWM timer for CORTEXM
 *
 * Configuration:
 *		OS_CORTEXM_TIMER_GRPx_BASE		Base address of system timer group x.
 *		OS_CORTEXM_CY_TIMER_NGROUPS		Number of groups of the Timer modules.
 *		OS_CORTEXM_TIMER_NMODULES		Number of Timer modules in each group.
 *
 * (c) Elektrobit Automotive GmbH
*/

#ifndef OS_CORTEXM_TIMER_CY_PWM_H
#define OS_CORTEXM_TIMER_CY_PWM_H

#include <Os_kernel.h>
#include <CORTEXM/Os_CORTEXM_cpu.h>

/* Number of available groups */
#ifndef OS_CORTEXM_CY_TIMER_NGROUPS
#error "OS_CORTEXM_CY_TIMER_NGROUPS undefined."
#endif

/* Number of supported groups */
#ifndef OS_CORTEXM_CY_TIMER_NGROUPS_MAX
#error "OS_CORTEXM_CY_TIMER_NGROUPS_MAX undefined."
#endif

/* Number of supported timers in each group */
#ifndef OS_CORTEXM_TIMER_NMODULES_MAX
#error "OS_CORTEXM_TIMER_NMODULES_MAX undefined."
#endif

#if OS_CORTEXM_CY_TIMER_NBLOCKS > 2u
#error "ECUs with more than 2 TCPWM blocks are currently not supported."
#endif

#if OS_CORTEXM_CY_TIMER_NGROUPS > 4u
#error "TCPWMs with more than 4 groups are currently not supported."
#endif

#ifndef OS_ASM

/* Timer/Counter/PWM Counter Module Registers (TCPWM_GRP_CNT) */
typedef struct os_tcpwm_grp_cnt {
	os_reg32_t tcpwm_ctrl;			/* 0x00000000 Counter control register */
	os_reg32_t tcpwm_sts;			/* 0x00000004 Counter status register */
	os_reg32_t tcpwm_cntr;			/* 0x00000008 Counter count register */
	os_uint32_t reserved;
	os_reg32_t tcpwm_cc0;			/* 0x00000010 Counter compare/capture 0 register */
	os_reg32_t tcpwm_cc0buff;		/* 0x00000014 Counter buffered compare/capture 0 register */
	os_reg32_t tcpwm_cc1;			/* 0x00000018 Counter compare/capture 1 register */
	os_reg32_t tcpwm_cc1_buff;		/* 0x0000001C Counter buffered compare/capture 1 register */
	os_reg32_t tcpwm_period;		/* 0x00000020 Counter period register */
	os_reg32_t tcpwm_period_buff;	/* 0x00000024 Counter buffered period register */
	os_reg32_t tcpwm_line_sel;		/* 0x00000028 Counter line selection register */
	os_reg32_t tcpwm_line_sel_buff;	/* 0x0000002C Counter buffered line selection register */
	os_reg32_t tcpwm_dt;			/* 0x00000030 Counter PWM dead time register */
	os_uint32_t reserved1[3];
	os_reg32_t tcpwm_tr_cmd;		/* 0x00000040 Counter trigger command register */
	os_reg32_t tcpwm_tr_in_sel0;	/* 0x00000044 Counter input trigger selection register 0 */
	os_reg32_t tcpwm_tr_in_sel1;	/* 0x00000048 Counter input trigger selection register 1 */
	os_reg32_t tcpwm_tr_in_edge_sel;/* 0x0000004C Counter input trigger edge selection register */
	os_reg32_t tcpwm_tr_pwm_ctrl;	/* 0x00000050 Counter trigger PWM control register */
	os_reg32_t tcpwm_tr_out_sel;	/* 0x00000054 Counter output trigger selection register */
	os_uint32_t reserved2[6];
	os_reg32_t tcpwm_intr;			/* 0x00000070 Interrupt request register */
	os_reg32_t tcpwm_intr_set;		/* 0x00000074 Interrupt set request register */
	os_reg32_t tcpwm_intr_mask;		/* 0x00000078 Interrupt mask register */
	os_reg32_t tcpwm_intr_masked;	/* 0x0000007C Interrupt masked request register */
} os_tcpwm_grp_cnt_t;				/* Size = 128 (0x80) */

/* Group of counters (TCPWM_GRP) */
typedef struct os_tcpwm_grp {
	os_tcpwm_grp_cnt_t	CNT[OS_CORTEXM_TIMER_NMODULES_MAX];		/* 0x00000000 Timer/Counter/PWM Counter Module */
} os_tcpwm_grp_t;								/* Size = 32768 (0x8000) */

/* Timer/Counter/PWM (TCPWM) */
typedef struct os_tcpwm {
	os_tcpwm_grp_t	GRP[OS_CORTEXM_CY_TIMER_NGROUPS_MAX];			/* 0x00000000 Group of counters */
} os_tcpwm_t;									/* Size = 131072 (0x20000) */

/* Timer/Counter/PWM (TCPWM) info */
typedef struct os_tcpwm_info_s {
	os_tcpwm_t * tcpwm_base;	/* TCPWM base address */
	os_uint32_t tcpwm_grp;	/* TCPWM group*/
	os_uint32_t tcpwm_irq;	/* TCPWM interrupt resource (datasheet) */
} os_tcpwm_info_t;

#define OS_TCPWM_UNIT(tcpwm_base, grp, cnt) ((volatile os_tcpwm_grp_cnt_t*) &((tcpwm_base)->GRP[(grp)].CNT[(cnt)]))

/* TCPWM_GRP_CNT_TR_CMD */
#define OS_TCPWM_CMD_START_TRIGGER					OS_U(0x10)

/* TCPWM_GRP_CNT.CTRL */
#define OS_TCPWM_CTRL_CC0_MATCH_UP_EN_POS			OS_U(4)
#define OS_TCPWM_CTRL_CC0_MATCH_UP_EN_MSK			OS_U(0x10)
#define OS_TCPWM_CTRL_ENABLED_POS					OS_U(31)
#define OS_TCPWM_CTRL_ENABLED_MSK					OS_U(0x80000000)
#define OS_TCPWM_CTRL_RESETCFG_MSK					OS_U(0x073737ff)

/* TCPWM_GRP_CNT.STATUS */
#define OS_TCPWM_STATUS_TR_COUNT_POS				OS_U(5)
#define OS_TCPWM_STATUS_TR_COUNT_MSK				OS_U(0x20)


/* OS_TCPWM_GRP_CNT.TR_OUT_SEL */
#define OS_TCPWM_TR_OUT_SEL_TC						OS_U(0x2)
#define OS_TCPWM_TR_OUT0_SEL_CC0_MATCH				OS_U(0x3)
#define OS_TCPWM_TR_OUT1_SEL_DISABLED				OS_U(0x70)
/* OS_TCPWM_GRP_CNT.INTR */
/* OS_TCPWM_GRP_CNT.INTR_SET */
/* OS_TCPWM_GRP_CNT.INTR_MASK */
/* OS_TCPWM_GRP_CNT.INTR_MASKED */
#define OS_TCPWM_INTR_TC_POS						OS_U(0)
#define OS_TCPWM_INTR_TC_MSK						OS_U(0x1)
#define OS_TCPWM_INTR_CC0_MATCH_POS					OS_U(0x1)
#define OS_TCPWM_INTR_CC0_MATCH_MSK					OS_U(0x2)
#define OS_TCPWM_INTR_MASK_TC						OS_U(0x1)
#define OS_TCPWM_INTR_MASK_CC1						OS_U(0x4)

#define OS_TCPWM_CTR_CC0_MATCH_EN					OS_U(1)		/* A cc0_match event. */
/* Initial value for the counter in the Up counting mode */
#define OS_TCPWM_CNT_UP_INIT_VAL					OS_U(0x0)

extern const os_hwtdrv_t OS_timerCYPWMdriver;

#endif

#endif /* OS_CORTEXM_TIMER_CY_PWM_H */
/* Editor settings: DO NOT DELETE
 * vi: set ts=4:
*/
