/* Os_CORTEXM_CYT4BB.h - Description of Cortex-M7 variant CYT4BB .
 *
 * This file describes the CYT4BB variant of Cortex-M7 ARM-core family.
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
*/

#ifndef OS_CORTEXM_CYT4BB_H
#define OS_CORTEXM_CYT4BB_H

/* CYT4BB derivative has the following features:*/

#define OS_CORTEXM_TIMER						OS_CORTEXM_TIMER_CY_PWM

/* Number of Timer blocks*/
#define OS_CORTEXM_CY_TIMER_NBLOCKS				OS_U(1)

/* Actual number of groups of Timer instances per block*/
#define OS_CORTEXM_CY_TIMER_NGROUPS				OS_U(3)

/* Theoretically maximum number of groups of Timer instances per block (MAX:4)*/
#define OS_CORTEXM_CY_TIMER_NGROUPS_MAX			OS_U(4)

/* Theoretically maximum number of Timer instances in each group (MAX:256)*/
#define OS_CORTEXM_TIMER_NMODULES_MAX			OS_U(256)

/* TCPWM0 */
#define OS_CORTEXM_TCPWM0_BASE					OS_U(0x40580000)
/* Base address of the group 0 timer*/
#define OS_CORTEXM_TCPWM0_GR0_BASE				OS_U(0x40580000)
#define OS_CORTEXM_TCPWM0_GR0_IRQ_BASE			OS_U(351)
/* Base address of the group 1 timer*/
#define OS_CORTEXM_TCPWM0_GR1_BASE				OS_U(0x40588000)
#define OS_CORTEXM_TCPWM0_GR1_IRQ_BASE			OS_U(414)
/* Base address of the group 2 timer*/
#define OS_CORTEXM_TCPWM0_GR2_BASE				OS_U(0x40590000)
#define OS_CORTEXM_TCPWM0_GR2_IRQ_BASE			OS_U(426)

#define OS_CORTEXM_NUM_INTERRUPTS				OS_U(443)

/* This is an ARMv7-M core */
#define OS_CORTEXM_VARIANT						OS_CORTEXM_ARMV7

/* Cortex M7 derivatives contains a floating-point unit.*/
#define OS_CORTEXM_FPU							OS_CORTEXM_FPU_ARMV7

/* CYT4BB features related to the generic part of the kernel:
 *
 * - OS_STACKGROWS:		either OS_STACKGROWSDOWN or OS_STACKGROWSUP as necessary
 * - OS_STACKFILL:		0xebe..b, enough to fill an os_stackelement_t with bytes of 0xeb
 * - OS_HWT_POWEROF2:	1 if all supported hardware timers wrap cleanly on the (2**n)th tick, 0 otherwise.
*/
#define OS_STACKGROWS							OS_STACKGROWSDOWN
#define OS_STACKFILL							OS_U(0xebebebeb)
#define OS_HWT_POWEROF2							1
#define OS_USE_MMU								0
#define OS_USE_MPU								1
#define OS_CORTEXM_MPU_TYPE						OS_CORTEXM_MPU_ARM

/* Caches are only relevant for cross-core communication.
 * Use arbitrary values.
*/
#define OS_CACHE_MODE							OS_CACHE_MODE_NONE
#define OS_CACHE_LINE_LEN						OS_U(32)

/* CPUSS module is available */
#define OS_CORTEXM_INT_MUX						OS_CORTEXM_INT_MUX_CPUSS

/* Base address of the CPUSS module */
#define OS_CORTEXM_CPUSS_BASE					(0x40200000u)
/* Split it up into digestible bits for the ghs assembler */
#define OS_CORTEXM_CPUSS_BASE_HI					(0x4020)
#define OS_CORTEXM_CPUSS_BASE_LO					(0x0000)
/* Bus master Id of core CM7_0, further cores follow with a decremented bus master Id */
#define OS_CORTEXM_BUSMASTER_START				(14u)

/* 2nd M7 core not (yet) supported */
#define OS_N_CORES_MAX							OS_U(1)

#if (OS_N_CORES > 1)
#if (OS_KERNEL_TYPE == OS_MICROKERNEL)
#define OS_GetMyCoreId()					((os_coreid_t)MK_GetPhysicalCoreId(GetCoreID()))
#else
/* Get core ID via bus master ID. CPUSS_IDENTITY returns the bus master performing the read access,
 * CM7_0 has bus master 14, CM7_1 has 13 */
#define OS_GetMyCoreId()		(OS_CORTEXM_BUSMASTER_START-(((*(os_reg32_t*)OS_CORTEXM_CPUSS_BASE)&0xF00u)>>8u))
#endif
#endif

/* NVIC number of interrupt sources (8 ext, 8 SGI, 443 muxed sys)*/
#define OS_CORTEXM_NUM_SOURCES					OS_U(459)

/* CPU interrupts are effectively banked. Even as a single core we need this to differentiate between
 * CPU interrupts and multiplexed system interrupts */
#define OS_CORTEXM_BANKED_SOURCES				OS_U(16)

/* The amount of interrupt sources connected to the multiplexer. It's using all 8 external CPU interrupts */
#define OS_CORTEXM_MUXED_IRQS					OS_U(8)

/* NVIC lowest interrupt locking level.
 * One lower than the lowest possible priority an IRQ request can have,
 * so that all interrupts are enabled.
 * If the highest priority possible is 7, then the values here will be 7+1;
*/
#define OS_CORTEXM_ALL_INT_ENABLED_LEVEL		OS_U(8)

/* NVIC number of bits to shift the interrupt priority to the left */
/* Note: An NVIC implementation may use a sub-range of the architectural priority range.
 * Example: If the architectural priority range is 8 bit and an implementation
 *          uses only 6 bit the priorities have to be shifted by 2 bit to the left.
 *
 * CYT4BB seems to support 8 priorities ranging from 0 to 7, hence only upper 3 bits
 * are used and we have to shift according to below table
 */
#define OS_CORTEXM_INT_PRIO_SHIFT				OS_U(5)

/* CYT4BB has a CORTEX-M7F/M0+ core (see ASCOS-5685) */
#define OS_CORTEXM_HAS_ERRATA_838869			0

/*
 * If we need a CPU related initialization this can be done
 * by refining the OS_CORTEXM_CpuInitArch macro.
 * For CYT4BB we initialize the interrupt controller.
*/
#define OS_CORTEXM_CpuInitArch()				\
	do {										\
		OS_CORTEXM_SetupVFPCoprocessor();		\
		OS_CORTEXM_IntSetupMux();				\
	} while(0)

#endif

/* Editor settings: DO NOT DELETE
 * vi: set ts=4:
*/
