/* Os_tool_ARM.h - ARM definitions for different tool chains.
 *
 * CHECK: TABS 4 (see editor commands at end of file)
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
*/

#ifndef OS_TOOL_ARM_H
#define OS_TOOL_ARM_H

#include <Os_defs.h>
#include <ARM/Os_ARM_cpu.h>

#ifndef EB_STATIC_CHECK

#if (OS_TOOL==OS_ticgt)
#include <ARM/Os_tool_ARM_ticgt.h>
#elif (OS_TOOL==OS_gnu)
#include <ARM/Os_tool_ARM_gnu.h>
#elif (OS_TOOL==OS_realview)
#include <ARM/Os_tool_ARM_realview.h>
#elif (OS_TOOL==OS_ghs)
#include <ARM/Os_tool_ARM_ghs.h>
#elif (OS_TOOL==OS_diab)
#include <ARM/Os_tool_ARM_diab.h>
#elif (OS_TOOL==OS_armkeil)
#include <ARM/Os_tool_ARM_armkeil.h>
#else
//#error "Unknown or unsupported toolchain. Check your Makefiles!"
#endif

/* Macro that evaluates to the name of the linker generated symbol referring
 * to the virtual memory address of section <secname>.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
 */
#ifndef OS_TOOL_SECTION_VMA
#define OS_TOOL_SECTION_VMA(secname) __START ## secname
#endif

/* Macro that evaluates to the name of the linker generated symbol referring
 * to the virtual memory address one byte beyond section <secname>.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
 */
#ifndef OS_TOOL_SECTION_VMA_END
#define OS_TOOL_SECTION_VMA_END(secname) __END ## secname
#endif

/* Macro that evaluates to the name of the linker generated symbol referring
 * to the load address of section <secname>.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
 */
#ifndef OS_TOOL_SECTION_LMA
#define OS_TOOL_SECTION_LMA(secname) __INIT ## secname
#endif

/* Macro that evaluates to the symbol at the begin of the (anonymous) initialized
 * data. It is used to initialize anynmous data in the board file.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_STARTDATA
#define OS_TOOL_STARTDATA	OS_TOOL_SECTION_VMA(DATA)
#endif

/* Macro that evaluates to the symbol at the load memory address of the (anonymous)
 * initialized data. It is used to initialize anonymous data in the board file.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_INITDATA
#define OS_TOOL_INITDATA	OS_TOOL_SECTION_LMA(DATA)
#endif

/* Macro that evaluates to the symbol one byte beyond the (anonymous) initialized
 * data. It is used to initialize anonymous data in the board file.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_ENDDATA
#define OS_TOOL_ENDDATA		OS_TOOL_SECTION_VMA_END(DATA)
#endif

/* Macro that evaluates to the symbol at the begin of the (anonymous) uninitialized
 * data. It is used to clear the anonymous bss in the board file.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_STARTBSS
#define OS_TOOL_STARTBSS	OS_TOOL_SECTION_VMA(BSS)
#endif

/* Macro that evaluates to the symbol one byte beyond the (anonymous) uninitialized
 * data. It is used to clear the anonymous bss in the board file.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_ENDBSS
#define OS_TOOL_ENDBSS		OS_TOOL_SECTION_VMA_END(BSS)
#endif

/* Macro that evaluates to the symbol at the start of all data (=RAM start).
 * The region between OS_TOOL_RAM_START and OS_TOOL_RAM_END is granted
 * the rights s+rw, u+r as global data region.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_RAM_START
#define OS_TOOL_RAM_START __GLBL_DATA_START
#endif

/* Macro that evaluates to the symbol one byte beyond the end of all data (=RAM end).
 * The region between OS_TOOL_RAM_START and OS_TOOL_RAM_END is granted
 * the rights s+rw, u+r as global data region.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_RAM_END
#define OS_TOOL_RAM_END __GLBL_DATA_END
#endif

/* Macro that evaluates to the symbol at the start of all text.
 * The region between OS_TOOL_TEXT_START and OS_TOOL_TEXT_END is granted
 * the rights s+rx, u+rx as global text region.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_TEXT_START
#define OS_TOOL_TEXT_START __GLBL_TEXT_START
#endif

/* Macro that evaluates to the symbol one byte beyond the end of all text.
 * The region between OS_TOOL_TEXT_START and OS_TOOL_TEXT_END is granted
 * the rights s+rx, u+rx as global text region.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_TEXT_END
#define OS_TOOL_TEXT_END __GLBL_TEXT_END
#endif

/* Macro that evaluates to the symbol at the start of all read-only data.
 * The region between OS_TOOL_RODATA_START and OS_TOOL_RODATA_END is granted
 * the rights s+r, u+r as global const region.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_RODATA_START
#define OS_TOOL_RODATA_START __GLBL_RODATA_START
#endif

/* Macro that evaluates to the symbol one byte beyond the end of all read-only data.
 * The region between OS_TOOL_RODATA_START and OS_TOOL_RODATA_END is granted
 * the rights s+r, u+r as global const region.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_RODATA_END
#define OS_TOOL_RODATA_END __GLBL_RODATA_END
#endif

#if (OS_RAM_AT_LOWERADDRESS == 1)
/* Macro that evaluates to the symbol at the start of the exception table
 * The region between OS_TOOL_EXCPTBL_START and OS_TOOL_EXCPTBL_END is granted
 * the rights s+rx, u+rx.
 * This is used when RAM is at 0x00 and Flash is at higher address.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_EXCPTBL_START
#define OS_TOOL_EXCPTBL_START __GLBL_EXCPTBL_START
#endif

/* Macro that evaluates to the symbol at the end of the exception table
 * The region between OS_TOOL_EXCPTBL_START and OS_TOOL_EXCPTBL_END is granted
 * the rights s+rx, u+rx.
 * This is used when RAM is at 0x00 and Flash is at higher address.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_EXCPTBL_END
#define OS_TOOL_EXCPTBL_END __GLBL_EXCPTBL_END
#endif

#endif

/* Macro that evaluates to the symbol at the start of the kernel's peripheral
 * region.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_STARTKERNDEV
#define OS_TOOL_STARTKERNDEV OS_TOOL_SECTION_VMA(KERNDEV)
#endif

/* Macro that evaluates to the symbol one byte beyond the end of the kernel's
 * peripheral region.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_ENDKERNDEV
#define OS_TOOL_ENDKERNDEV OS_TOOL_SECTION_VMA_END(KERNDEV)
#endif

#else  /*EB_STATIC_CHECK*/

/* stubs for MISRA-C checks */

#define OS_TOOL_GETKERNELDATA_IMPLEMENTATION OS_TOOL_ASM_INLINE
#define OS_ARM_GetKernelData()			((os_kerneldata_t *)OS_NULL)
#define OS_ArchCacheFlushLine(v)		do {} while (0)
#define OS_ArchCacheInvalidateLine(v)	do {} while (0)
#define OS_ARM_GetMpidr()				0
#define OS_ARM_ReadCNTPCT(a,b)			do { (a) = 0u; (b) = 0u; } while (0)
#define OS_ARM_WriteCNTKCTL(a)			do {} while (0)
#define OS_ARM_WriteCNTP_CTL(a)			do {} while (0)
#define OS_ARM_WriteCNTP_TVAL(a)		do {} while (0)
#define OS_ARM_DSB_SY()					do {} while (0)

#endif /*EB_STATIC_CHECK*/

/* Implementation of OS_ARM_GetSP() */
#ifndef OS_TOOL_GETSP_IMPLEMENTATION
#define OS_TOOL_GETSP_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif

/* Implementation of OS_ARM_SetSP() */
#ifndef OS_TOOL_SETSP_IMPLEMENTATION
#define OS_TOOL_SETSP_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif

/* Implementation of OS_ARM_EnableIRQ() */
#ifndef OS_TOOL_ENABLE_IRQ_IMPLEMENTATION
#define OS_TOOL_ENABLE_IRQ_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif

/* Implementation fo OS_ARM_DisableIRQ() */
#ifndef OS_TOOL_DISABLE_IRQ_IMPLEMENTATION
#define OS_TOOL_DISABLE_IRQ_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif

/* Implementation of OS_ARM_EnableIRQGetState() */
#ifndef OS_TOOL_ENABLE_IRQ_GET_STATE_IMPLEMENTATION
#define OS_TOOL_ENABLE_IRQ_GET_STATE_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif

/* Implementation of OS_ARM_DisableIRQGetState() */
#ifndef OS_TOOL_DISABLE_IRQ_GET_STATE_IMPLEMENTATION
#define OS_TOOL_DISABLE_IRQ_GET_STATE_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif

/* Implementation of OS_ARM_SetState() */
#ifndef OS_TOOL_SET_STATE_IMPLEMENTATION
#define OS_TOOL_SET_STATE_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif

/* Implementation of OS_ARM_GetIRQPrio() */
#ifndef OS_TOOL_GET_IRQ_PRIO_IMPLEMENTATION
#define OS_TOOL_GET_IRQ_PRIO_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif

/* Implementation of OS_ARM_SetIRQPrio() */
#ifndef OS_TOOL_SET_IRQ_PRIO_IMPLEMENTATION
#define OS_TOOL_SET_IRQ_PRIO_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif

/* Implementation of OS_ARM_GetCurIRQSource() */
#ifndef OS_TOOL_GET_CUR_IRQ_SOURCE_IMPLEMENTATION
#define OS_TOOL_GET_CUR_IRQ_SOURCE_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif


/* Implementation of OS_ARM_GetKernelData() */
#ifndef OS_TOOL_GETKERNELDATA_IMPLEMENTATION
#define OS_TOOL_GETKERNELDATA_IMPLEMENTATION OS_TOOL_ASM_FUNC
#endif

/* Implementation of OS_ARM_DSB_SY() */
#ifndef OS_TOOL_DSB_SY_IMPLEMENTATION
#define OS_TOOL_DSB_SY_IMPLEMENTATION OS_TOOL_ASM_INLINE
#endif

/* Align an object to n bytes.
 *
 * Note:  This is the default implementation, it may be changed in the toolchain header!
*/
#ifndef OS_TOOL_ALIGN
#define OS_TOOL_ALIGN(bytes)	/* nothing */
#endif

#endif
/* Editor settings; DO NOT DELETE
 * vi:set ts=4:
*/
