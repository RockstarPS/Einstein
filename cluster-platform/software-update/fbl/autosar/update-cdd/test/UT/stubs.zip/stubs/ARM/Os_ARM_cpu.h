/* Os_ARM_cpu.h - ARM CPU header file
 *
 * CHECK: TABS 4 (see editor commands at end of file)
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
*/

#ifndef OS_ARM_CPU_H
#define OS_ARM_CPU_H

#include <Os_defs.h>
#include <ARM/Os_defs_ARM.h>

/* Include the appropriate header file for the derivative.
 *
 * CAVEAT:
 * The presence here of an include directive for a particular derivative
 * does not imply support for that derivative, nor does it imply a
 * commitment or intention to support that derivative in the future.
*/
#if (OS_CPU == OS_RCARV3MCR7)
#include <ARM/RCARV3MCR7/Os_ARM_RCARV3MCR7.h>
#elif (OS_CPU == OS_RCARV3HCR7)
#include <ARM/RCARV3HCR7/Os_ARM_RCARV3HCR7.h>
#elif (OS_CPU == OS_RCARM3CR7)
#include <ARM/RCARM3CR7/Os_ARM_RCARM3CR7.h>
#elif (OS_CPU == OS_RCARM3NCR7)
#include <ARM/RCARM3NCR7/Os_ARM_RCARM3NCR7.h>
#elif (OS_CPU == OS_S32S247)
#include <ARM/S32S247/Os_ARM_S32S247.h>
#elif (OS_CPU == OS_BCM89531)
#include <ARM/BCM89531/Os_ARM_BCM89531.h>
#elif (OS_CPU == OS_ZUXEVCR5)
#include <ARM/ZUXEVCR5/Os_ARM_ZUXEVCR5.h>
#elif (OS_CPU == OS_SR6P6)
#include <ARM/SR6P6/Os_ARM_SR6P6.h>
#elif (OS_CPU == OS_SR6P7)
#include <ARM/SR6P7/Os_ARM_SR6P7.h>
#elif (OS_CPU == OS_SR6G7)
#include <ARM/SR6G7/Os_ARM_SR6G7.h>
#elif (OS_CPU == OS_TDA4VMCR5)
#include <ARM/TDA4VMCR5/Os_ARM_TDA4VMCR5.h>
#elif (OS_CPU == OS_MV88Q515X)
#include <ARM/MV88Q515X/Os_ARM_MV88Q515X.h>
#elif (OS_CPU == OS_G9XCR5)
#include <ARM/G9XCR5/Os_ARM_G9XCR5.h>
#elif (OS_CPU == OS_S32Z27X)
#include <ARM/S32Z27X/Os_ARM_S32Z27X.h>
#elif (OS_CPU == OS_RCARS4CR52)
#include <ARM/RCARS4CR52/Os_ARM_RCARS4CR52.h>
#elif (OS_CPU == OS_EXYNOSAV9)
#include <ARM/EXYNOSAV9/Os_ARM_EXYNOSAV9.h>
#elif (OS_CPU == OS_AM2634)
#include <ARM/AM2634/Os_ARM_AM2634.h>
#elif (OS_CPU == OS_E36XX)
#include <ARM/E36XX/Os_ARM_E36XX.h>
#elif (OS_CPU == OS_MVQ622X)
#include <ARM/MVQ622X/Os_ARM_MVQ622X.h>
/* continue here with elif to add support for other ARM devices */
#else
#error "OS_CPU is not properly defined. Check your makefiles!"
#endif

#if (OS_KERNEL_TYPE==OS_SYSTEM_CALL) && ( (OS_USE_MMU==1) || (OS_USE_MPU==1) )
/* Memory protection is only supported if system call libraries are used and */
/* if the derivative has either a MMU or a MPU. */
#define OS_HASMEMPROT	1
#else
#define OS_HASMEMPROT	0
#endif

#if ((OS_ARM_FPU != OS_ARM_FPU_NONE) && !defined(OS_EXCLUDE_HW_FP))
#define OS_USE_HW_FP	1
#else
#define OS_USE_HW_FP	0
#endif

/* For ARMv7 and above, the ldrex/strex instruction pair exists,
 * on which our spinlock implementation is based.
 * Note that some derivatives might override this to provide an
 * own, hardware-semaphore-based implementation.
 */
#ifndef OS_HAS_ARCHSPINLOCK
#define OS_HAS_ARCHSPINLOCK		1
#define OS_ArchTakeSpinlock(a)	OS_ARM_TakeSpinlock(a)
#define OS_ArchDropSpinlock(a)	OS_ARM_DropSpinlock(a)
#endif

/* Per default, ARM derivatives do not need to use a SEMA42 unit (even if they
 * provide one).
 */
#ifndef OS_ARM_HAS_SEMA4
#define OS_ARM_HAS_SEMA4	0
#endif

/* Macro signifying that the RAM is at lower address 0x00
 * This is required to create a new MPU region with execution permissions, 
 * for exception table at 0x00. The other part of RAM has write permissions only.
 * NOTE: If required, this needs to be enabled in the respective CPU header files.
 */
#ifndef OS_RAM_AT_LOWERADDRESS
#define OS_RAM_AT_LOWERADDRESS		0
#endif

#if (OS_N_CORES_MAX > 1)

/* Proactively clear the interrupt-disable flag in case shutdown is called from
 * an exception handler.
*/
#define OS_IntEnableXcoreFromShutdown()		\
	do {									\
		(void) OS_IntEnableXcore();			\
		OS_ARM_EnableIRQ();					\
	} while(0)

#endif

#endif /* OS_ARM_CPU_H */
/* Editor settings; DO NOT DELETE
 * vi:set ts=4:
*/
