/* Mk_qmboard.h
 *
 * Board specific configuration
 *
 * Warning: This file has not been developed in accordance with a safety
 * standard (no ASIL)!
 *
 * (c) Elektrobit Automotive GmbH
 *
 * $Id: Mk_qmboard.h 45925 2022-09-29 15:25:01Z waab271441 $
*/
#ifndef MK_QMBOARD_H
#define MK_QMBOARD_H

#include <Mk_board.h>
#include <MicroOs.h>
#include <public/Mk_timeconversion.h>

/* CPU frequency - This is not used by the MK and is only required for PerfM module. */
#define BOARD_CPU_FREQ_MHZ						MK_U(800)

/*
 * OS_BoardMCTNsToTicks() and OS_BoardMCTTicksToNs() for the MCT counters
 *
 * OS_BoardMCTNsToTicks() converts nanoseconds (ns) to ticks.
 *
 * OS_BoardMCTTicksToNs converts ticks to nanoseconds.
 *
*/
#define OS_BoardMCTNsToTicks(ns)				MK_NsToTicks_26000000(ns)
#define OS_BoardMCTTicksToNs(ticks)				MK_TicksToNs_26000000(ticks)

#ifndef MK_TS5_TEST
#include <ARM/Os_ARM_timer_mct_config.h>
#endif

/* Added dummy implementations for LEDS_INIT() and LEDS_SET(x). */
#define LEDS_INIT()								do {} while (0)
#define LEDS_SET(x)								do {} while (0)

#ifndef MK_ASM
/* MK_InitHardwareBeforeData()
 *
 * MK_InitHardwareBeforeData() is called during startup before the .data and .bss sections
 * have been initialized. The initial values of non-automatic variables must not be relied
 * upon here. Values written to such variables will be lost after this function returns.
 *
 * External RAM, ROM, FLASH etc. can be set up here.
 * PLL initialization should go here so that the RAM initialization runs at full speed.
*/
extern void MK_InitHardwareBeforeData(void);

/* MK_InitHardwareAfterData()
 *
 * MK_InitHardwareAfterData() is called during startup after the .data and .bss sections
 * have been initialized (so global variables can
 * now be used). The BoardInit() can be used to start up drivers etc.
*/
extern void MK_InitHardwareAfterData(void);

/* This macro contains an endless loop that attempts to avoid a compiler warning on endless loops. */
#define TMPL_ENDLESSLOOP()														\
	do																			\
	{																			\
		mk_uint32_t confusion;													\
		for(confusion=0u; confusion!=1u; confusion^=2u)							\
		{																		\
			/* Compiler hopefully does not recognize this as an endless loop */	\
		}																		\
	} while(0)

#endif /* ! MK_ASM */

#endif /* ! MK_QMBOARD_H */
