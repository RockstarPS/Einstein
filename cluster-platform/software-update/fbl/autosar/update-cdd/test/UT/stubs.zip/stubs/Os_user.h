/* This file is generated automatically. DO NOT EDIT!!
 *
 * EB tresos AutoCore OS 6.1.167 CORTEXM/CYT4BB
 * (Build 20230703)
 *
 * (c) 1998-2024 Elektrobit Automotive GmbH
 * Am Wolfsmantel 46
 * 91058 Erlangen
 * GERMANY
 *
 * Date         : 2/20/24 4:32 PM           !!!IGNORE-LINE!!!
 */

#ifndef OS_USER_H
#define OS_USER_H
#ifdef __cplusplus
extern "C" {
#endif

#define OS_GENERATION_ID_OS_H    0xcd3ceaadUL

#define OS_AUTOSAROS_VER         6

#define OS_AUTOSAROS_REV         1

#define OS_AUTOSAROS_CORE_BUILD  20230703

#define OS_AUTOSAROS_ARCH_BUILD  20230703

#ifndef OS_INTERRUPT_KEYWORD
#define OS_INTERRUPT_KEYWORD
#endif


/*===================================================================
 * Alarms
 *==================================================================*/
#define AlarmIncrementRteCounter  0

/*===================================================================
 * Application modes
 *==================================================================*/
#define OSDEFAULTAPPMODE  0

/*===================================================================
 * Applications
 *==================================================================*/
/* Application Hooks */
/* Trusted Functions */

/*===================================================================
 * CPU Core configuration
 *==================================================================*/
#define OS_CORE_ID_0  0

/*===================================================================
 * Core Mapping
 *==================================================================*/

/*===================================================================
 * Counters
 *==================================================================*/
/* Macros for the configured counter values and time conversions */
#define OSMAXALLOWEDVALUE_Rte_Counter  OS_U(4294967295)
#define OSTICKSPERBASE_Rte_Counter  OS_U(1)
#define OSMINCYCLE_Rte_Counter  OS_U(1)
#define OS_NsToTicks_Rte_Counter(x)  ((x)/1000000)
#define OS_TicksToNs_Rte_Counter(x)  ((x)*1000000)
#define OS_TICKS2NS_Rte_Counter(x)   (OS_TicksToNs_Rte_Counter((x)))
#define OS_TICKS2US_Rte_Counter(x)   (OS_TicksToNs_Rte_Counter((x)))/1000u
#define OS_TICKS2MS_Rte_Counter(x)   (OS_TicksToNs_Rte_Counter((x)))/1000000u
#define OS_TICKS2SEC_Rte_Counter(x)  (OS_TicksToNs_Rte_Counter((x)))/1000000000u
#define OSMAXALLOWEDVALUE_HwCounter  OS_U(4294967295)
#define OSTICKSPERBASE_HwCounter  OS_U(1000)
#define OSMINCYCLE_HwCounter  OS_U(1)
#ifndef OS_ASM
extern void OS_CounterIsr_HwCounter(void);
#endif  /* OS_ASM */
#define OS_NsToTicks_HwCounter(x)  OS_NsToTicks_TCPWM0_2_00((x))
#define OS_TicksToNs_HwCounter(x)  OS_TicksToNs_TCPWM0_2_00((x))
#define OS_TICKS2NS_HwCounter(x)   (OS_TicksToNs_TCPWM0_2_00((x)))
#define OS_TICKS2US_HwCounter(x)   (OS_TicksToNs_TCPWM0_2_00((x))/1000u)
#define OS_TICKS2MS_HwCounter(x)   (OS_TicksToNs_TCPWM0_2_00((x))/1000000u)
#define OS_TICKS2SEC_HwCounter(x)  (OS_TicksToNs_TCPWM0_2_00((x))/1000000000u)

/* Non-Internal Counter Ids */
#define Rte_Counter  0
#define HwCounter  1


/* System Counter Macros */
#define OSMAXALLOWEDVALUE  OSMAXALLOWEDVALUE_HwCounter
#define OSTICKSPERBASE     OSTICKSPERBASE_HwCounter
#define OSMINCYCLE         OSMINCYCLE_HwCounter
#define OSTICKDURATION     OS_TicksToNs_HwCounter(1u)

/*===================================================================
 * Events
 *==================================================================*/
#define Rte_OSShutdownEvent  0x0001u
#define Rte_OSResolveWaitPointEvent  0x0002u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_IE_DF8A9D62DE8E5259637BF08F740AF9C2  0x0004u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_DRE_F3DD049CFDD4C9B5EAC85C4C696C1197  0x0008u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_OIE_0C6EFCE8A08894D199A2EF6DBDA948D2  0x0010u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_OIE_818DBE623819B8B39524C65B280D3093  0x0020u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_OIE_492C74F22BD9AF9F42B7625A8438ACFF  0x0040u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_OIE_A35B62A7D66AA3BB4D3CDE4674816A8C  0x0080u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_OIE_037729404CF8A2712DD19E4D4C2C5079  0x0100u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_OIE_3C3C40196766946CCBD19C3457296A2D  0x0200u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_DRE_2A988E8223BBD945EF9955148A952BA2  0x0400u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_DRE_8F9A4C410390CC0DDDBCF48CA35F7E50  0x0800u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_DRE_E98BACD0D7C21132E7BAE5E454A412AF  0x01000u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_4_OIE_4E5584A26E181728C683E91C3F6C506C  0x0004u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_2_OIE_32B8D6BEF56D7E26433A6F8087A0AA8A  0x0002u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_2_OIE_76D6484DC8FA91A08D11FE790B0F1AFB  0x0004u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_OIE_59642E12870E284CE6C1068466D71CC8  0x0004u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_OIE_2E1DAB50CF2AECE2486BD998FA0335FF  0x0008u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_OIE_CA6D1E6AE25A6D488C4D55EA2C970B31  0x0010u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_OIE_905C64E1E990F9D57B71B6E75D92E1A2  0x0020u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_OIE_AC37CD04027D34D0BF7D2BE1F2DAB349  0x0040u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_OIE_9B8E875D6F198EAA694D9E68C7CFFE4A  0x0080u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_DRE_43D618A1CE4A01355F6A9B7D840455A6  0x0100u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_DRE_808C6E0088F9F5B436A9C8CA6C4617D7  0x0200u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_DRE_E1E5D55D7C66462CD5A0D35C8E849969  0x0400u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_DRE_59B240314CAAC5C051F2F9FC7CD91F98  0x0800u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_DRE_F01A68C5147C8ACF41ACFDD3EC8DF39F  0x01000u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_DRE_F1055D71CDA3653B69BAAA10EFF0A358  0x02000u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_DRE_68299756EE3143F1236C4DCA8FD21863  0x04000u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_DRE_979337F206402D694DF99F6214F139BA  0x08000u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_DRE_F5F69428F81E43E4872897E4EEFDDD29  0x10000u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_1_OIE_8AF5587DAF4F5D805CA807D1E7D487FE  0x20000u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_3_OIE_44DF459DE61D9F7A7C321BEB93094F33  0x0004u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_6_OIE_BCE325125EAF1990FF951A1B11832FA2  0x0004u
#define Rte_OSTimingEvent_SwcTask_EventPeriodic_6_TE_F2971F4E598C5EE4561D68D27F79C5DC  0x0008u
#define Rte_OSTimingEvent_SwcTask_EventPeriodic_6_TE_3D921F77B59F359C2A4C7E0F7208FC4A  0x0010u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_1_DRE_52F6930B62C8FBF08635917DA83957BF  0x0002u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_1_DRE_303B91A5E2D086FAB71298122955BAF0  0x0004u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_1_DRE_2B7A042B03B655DA3642B820D538A5AF  0x0008u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_1_DRE_930A5F0A54626A0CD94EE1B66B117EDF  0x0010u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_1_DRE_E6B3D629CD5412578DAA425C44318361  0x0020u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_0_DRE_5200046200700F5A6532E9F54AC4C56F  0x0002u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_0_DRE_9B66825C6EDF0B24C6E6CFE691CB005C  0x0004u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_0_DRE_CE244C5FE36A9FF3894DC38E6D54221A  0x0008u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_0_DRE_26C5906FD6ED6D888B8729DCC4B3D088  0x0010u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_0_DRE_C51546C8FB00DEA6A99BA86E6AA376E8  0x0020u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_5_OIE_5D5F78A397859C8D7085100FA2D5DC40  0x0004u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_5_OIE_C7C353D9E51AF568DEE466762C56569D  0x0008u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_5_DRE_51829B10D9DA9C8BC9958370F7F6E7E8  0x0010u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_7_OIE_025189228FC8045640F38A6078438C64  0x0002u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_7_OIE_5C2F48A013ED6C3EBA2427157F98F5DB  0x0004u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_7_OIE_6840E8A161588E1C990A129B3A0F0858  0x0008u
#define Rte_OSTimingEvent_SwcTask_EventPeriodic_7_TE_C2E250708B72FF1FD9BFBAC1324F002F  0x0010u
#define Rte_OSTimingEvent_SwcTask_EventPeriodic_7_TE_CADDD81A1376F58211C8344F1A4CB4FD  0x0020u
#define Rte_OSTriggerExecutableEvent_SwcTask_Event_Stub_DRE_9B0171315E2088D51B31BAA1898C8062  0x02000u
#define Rte_OSTriggerExecutableEvent_UclProxyEvent_1_DRE_0BEB89F1D59741CC6802E408300EF2D2  0x0040u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_2_DRE_8559BE4E1025A7B519CC16E832ABF346  0x0008u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_2_DRE_EBBE34C21139937E16DA3CF87FE5225A  0x0010u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_3_DRE_0C188B752CC4B5485E9FE949DC600FE0  0x0008u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_3_DRE_C472809CCF642A655DD4C0B2A66C3DF5  0x0010u
#define Rte_OSTimingEvent_SwcTask_EventPeriodic_6_TE_F70D5C77456E728AD212CB12E34A82C2  0x0020u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_3_DRE_425AC17ABFA599BDBE816762B054C0F9  0x0020u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_3_DRE_A8D581E80AE229199019C274681F6A46  0x0040u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_3_DRE_D2635BD5025553F19EEFAB224FC9AF4D  0x0080u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_4_DRE_992103AD62D1B5092067B90FAE8889D1  0x0008u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_4_DRE_386BBC13DCCE02029BCAEC5A238BE8A2  0x0010u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_8_OIE_52C63B8FA0B8006B5702ADD6A88B91E4  0x0002u
#define Rte_OSTriggerExecutableEvent_SwcTask_EventPeriodic_8_DRE_DD30309E81D1B7EFDD3010E29A33506A  0x0004u

/*===================================================================
 * Interrupts
 *==================================================================*/
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_DMA1_Isr_Vector_309_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define DMA1_Isr_Vector_309_Cat2_ISR_CATEGORY  2
#define DMA1_Isr_Vector_309_Cat2_ISR_VECTOR    325
#define DMA1_Isr_Vector_309_Cat2_ISR_LEVEL     3
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_SCB1_Isr_Vector_103_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define SCB1_Isr_Vector_103_Cat2_ISR_CATEGORY  2
#define SCB1_Isr_Vector_103_Cat2_ISR_VECTOR    119
#define SCB1_Isr_Vector_103_Cat2_ISR_LEVEL     4
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_SCB2_Isr_Vector_104_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define SCB2_Isr_Vector_104_Cat2_ISR_CATEGORY  2
#define SCB2_Isr_Vector_104_Cat2_ISR_VECTOR    120
#define SCB2_Isr_Vector_104_Cat2_ISR_LEVEL     5
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_SCB3_Isr_Vector_105_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define SCB3_Isr_Vector_105_Cat2_ISR_CATEGORY  2
#define SCB3_Isr_Vector_105_Cat2_ISR_VECTOR    121
#define SCB3_Isr_Vector_105_Cat2_ISR_LEVEL     7
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_SCB4_Isr_Vector_106_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define SCB4_Isr_Vector_106_Cat2_ISR_CATEGORY  2
#define SCB4_Isr_Vector_106_Cat2_ISR_VECTOR    122
#define SCB4_Isr_Vector_106_Cat2_ISR_LEVEL     7
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_SCB5_Isr_Vector_107_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define SCB5_Isr_Vector_107_Cat2_ISR_CATEGORY  2
#define SCB5_Isr_Vector_107_Cat2_ISR_VECTOR    123
#define SCB5_Isr_Vector_107_Cat2_ISR_LEVEL     2
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_Spi_Interrupt_SCB7_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define Spi_Interrupt_SCB7_Cat2_ISR_CATEGORY  2
#define Spi_Interrupt_SCB7_Cat2_ISR_VECTOR    125
#define Spi_Interrupt_SCB7_Cat2_ISR_LEVEL     4
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_SCB8_Isr_Vector_110_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define SCB8_Isr_Vector_110_Cat2_ISR_CATEGORY  2
#define SCB8_Isr_Vector_110_Cat2_ISR_VECTOR    126
#define SCB8_Isr_Vector_110_Cat2_ISR_LEVEL     3
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_DMA1_Isr_Vector_311_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define DMA1_Isr_Vector_311_Cat2_ISR_CATEGORY  2
#define DMA1_Isr_Vector_311_Cat2_ISR_VECTOR    327
#define DMA1_Isr_Vector_311_Cat2_ISR_LEVEL     5
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_DMA1_Isr_Vector_312_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define DMA1_Isr_Vector_312_Cat2_ISR_CATEGORY  2
#define DMA1_Isr_Vector_312_Cat2_ISR_VECTOR    328
#define DMA1_Isr_Vector_312_Cat2_ISR_LEVEL     4
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_DMA1_Isr_Vector_313_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define DMA1_Isr_Vector_313_Cat2_ISR_CATEGORY  2
#define DMA1_Isr_Vector_313_Cat2_ISR_VECTOR    329
#define DMA1_Isr_Vector_313_Cat2_ISR_LEVEL     6
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_DMA1_Isr_Vector_314_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define DMA1_Isr_Vector_314_Cat2_ISR_CATEGORY  2
#define DMA1_Isr_Vector_314_Cat2_ISR_VECTOR    330
#define DMA1_Isr_Vector_314_Cat2_ISR_LEVEL     7
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_Wdg_66_IA_WarnIntWDT_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define Wdg_66_IA_WarnIntWDT_Cat2_ISR_CATEGORY  2
#define Wdg_66_IA_WarnIntWDT_Cat2_ISR_VECTOR    32
#define Wdg_66_IA_WarnIntWDT_Cat2_ISR_LEVEL     6
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_Icu_Isr_Vector_54_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define Icu_Isr_Vector_54_Cat2_ISR_CATEGORY  2
#define Icu_Isr_Vector_54_Cat2_ISR_VECTOR    70
#define Icu_Isr_Vector_54_Cat2_ISR_LEVEL     5
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_Icu_Isr_Vector_46_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define Icu_Isr_Vector_46_Cat2_ISR_CATEGORY  2
#define Icu_Isr_Vector_46_Cat2_ISR_VECTOR    62
#define Icu_Isr_Vector_46_Cat2_ISR_LEVEL     6
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_Icu_Isr_Vector_47_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define Icu_Isr_Vector_47_Cat2_ISR_CATEGORY  2
#define Icu_Isr_Vector_47_Cat2_ISR_VECTOR    63
#define Icu_Isr_Vector_47_Cat2_ISR_LEVEL     2
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_Fault2_Isr_Vector_10_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define Fault2_Isr_Vector_10_Cat2_ISR_CATEGORY  2
#define Fault2_Isr_Vector_10_Cat2_ISR_VECTOR    26
#define Fault2_Isr_Vector_10_Cat2_ISR_LEVEL     3
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_Fault1_Isr_Vector_09_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define Fault1_Isr_Vector_09_Cat2_ISR_CATEGORY  2
#define Fault1_Isr_Vector_09_Cat2_ISR_VECTOR    25
#define Fault1_Isr_Vector_09_Cat2_ISR_LEVEL     3
#ifndef OS_ASM
#if OS_KERNEL_TYPE != OS_MICROKERNEL
extern void OS_ISR_Fault3_Isr_Vector_11_Cat2(void);
#endif  /* OS_KERNEL_TYPE */
#endif  /* OS_ASM */
#define Fault3_Isr_Vector_11_Cat2_ISR_CATEGORY  2
#define Fault3_Isr_Vector_11_Cat2_ISR_VECTOR    27
#define Fault3_Isr_Vector_11_Cat2_ISR_LEVEL     3
#define Os_Counter_TCPWM0_2_00_ISR_CATEGORY  2
#define Os_Counter_TCPWM0_2_00_ISR_VECTOR    442
#define Os_Counter_TCPWM0_2_00_ISR_LEVEL     2
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define DMA1_Isr_Vector_309_Cat2  0
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SCB1_Isr_Vector_103_Cat2  1
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SCB2_Isr_Vector_104_Cat2  2
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SCB3_Isr_Vector_105_Cat2  3
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SCB4_Isr_Vector_106_Cat2  4
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SCB5_Isr_Vector_107_Cat2  5
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Spi_Interrupt_SCB7_Cat2  6
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SCB8_Isr_Vector_110_Cat2  7
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define DMA1_Isr_Vector_311_Cat2  8
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define DMA1_Isr_Vector_312_Cat2  9
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define DMA1_Isr_Vector_313_Cat2  10
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define DMA1_Isr_Vector_314_Cat2  11
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Wdg_66_IA_WarnIntWDT_Cat2  12
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Icu_Isr_Vector_54_Cat2  13
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Icu_Isr_Vector_46_Cat2  14
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Icu_Isr_Vector_47_Cat2  15
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Fault2_Isr_Vector_10_Cat2  16
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Fault1_Isr_Vector_09_Cat2  17
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Fault3_Isr_Vector_11_Cat2  18
#endif

/*===================================================================
 * Resources
 *==================================================================*/
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define RES_SCHEDULER_0  0
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define MK_RESCAT1_0  1
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define MK_RESCAT2_0  2
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_0  3
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_1  4
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_2  5
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_3  6
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_4  7
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_5  8
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_6  9
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_7  10
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_8  11
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_9  12
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_10  13
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_11  14
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_12  15
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_13  16
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_14  17
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_15  18
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_16  19
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_17  20
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_18  21
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_19  22
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_20  23
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_21  24
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_22  25
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Rte_Res_23  26
#endif

/*===================================================================
 * Schedule Tables
 *==================================================================*/
#define SchM_DefaultScheduleTable  0
#define Rte_DefaultScheduleTable  1

/*===================================================================
 * Spinlocks
 *==================================================================*/

/*===================================================================
 * Tasks
 *==================================================================*/
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_EventPeriodic_7  0
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_EventPeriodic_6  1
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_EventPeriodic_1  2
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_EventPeriodic_2  3
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_EventPeriodic_3  4
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_Event_Stub  5
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_EventPeriodic_5  6
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_EventPeriodic_4  7
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define UclProxyEvent_1  8
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define UclProxyEvent_0  9
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_EventPeriodic_8  10
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Init_Task  11
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define BswTask_10ms  12
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define BswTask_5ms  13
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define BswTask_100ms  14
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define CddTask_100ms_Stub  15
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define Idle_Task  16
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define CddTask_EventPeriodic_0  17
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_EventPeriodic_0  18
#endif
#if OS_KERNEL_TYPE != OS_MICROKERNEL
#define SwcTask_EventPeriodic_9  19
#endif

/*===================================================================
 * Time-stamp timer
 *==================================================================*/
#ifdef __cplusplus
}
#endif
#endif  /* OS_USER_H */
