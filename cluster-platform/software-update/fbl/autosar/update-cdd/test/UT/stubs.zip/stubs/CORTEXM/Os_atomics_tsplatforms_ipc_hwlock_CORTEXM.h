/* Os_atomics_tsplatforms_ipc_hwlock_CORTEXM.h
 *
 * This file contains macros that take and drop a hardware lock in the IPC
 * module to support legacy atomic functions.
 *
 * CHECK: TABS 4 (see editor commands at end of file)
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
*/

#ifndef OS_ATOMICS_TSPLATFORMS_IPC_CORTEXM_H
#define OS_ATOMICS_TSPLATFORMS_IPC_CORTEXM_H

#include <Os_defs.h>
#include <Os_cpu.h>

#if (OS_N_CORES > 1)
#ifndef OS_HAS_IPC
#error "The macro OS_HAS_IPC is not defined."
#endif
#if (OS_HAS_IPC == 0)
#error "There must be a IPC module in multi-core environments."
#endif

#define OS_AtomicsDropHardwareLock()			OS_IPC_ReleaseLock()
#define OS_AtomicsTakeHardwareLock(oldIState)	OS_IPC_AcquireLock(oldIState)

#else /* (OS_N_CORES == 1) */
#define OS_AtomicsDropHardwareLock()			do { } while (0)
#define OS_AtomicsTakeHardwareLock(oldIState)	do { } while (0)

#endif /* (OS_N_CORES > 1) */
#endif /* OS_ATOMICS_TSPLATFORMS_IPC_CORTEXM_H */
