/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CBacklightCdd_Type.h
 *           Config:  Toyota_38xd.dpa
 *      ECU-Project:  Toyota_38xd
 *
 *        Generator:  MICROSAR RTE Generator Version 4.29.0
 *                    RTE Core Version 1.29.0
 *          License:  CBD2200498
 *
 *      Description:  Application types header file for SW-C <CBacklightCdd>
 *********************************************************************************************************************/

/* double include prevention */
#ifndef RTE_CUPDATECDD_TYPE_H
# define RTE_CUPDATECDD_TYPE_H

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

# include "Rte_Type.h"

# ifndef RTE_CORE

/**********************************************************************************************************************
 * Range, Invalidation, Enumeration and Bit Field Definitions
 *********************************************************************************************************************/

#  ifndef eCmpCmd_Init
#   define eCmpCmd_Init (0U)
#  endif

#  ifndef eCmpCmd_DeInit
#   define eCmpCmd_DeInit (1U)
#  endif

#  ifndef eCmpCmd_Activate
#   define eCmpCmd_Activate (2U)
#  endif

#  ifndef eCmpCmd_DeActivate
#   define eCmpCmd_DeActivate (3U)
#  endif

#  ifndef eDeviceNotReady
#   define eDeviceNotReady (0U)
#  endif

#  ifndef eDeviceInitialized
#   define eDeviceInitialized (1U)
#  endif

#  ifndef eDeviceReady
#   define eDeviceReady (2U)
#  endif

#  ifndef eDeviceBusy
#   define eDeviceBusy (3U)
#  endif

#  ifndef eDeviceFault
#   define eDeviceFault (4U)
#  endif

#  ifndef eDeviceMaxState
#   define eDeviceMaxState (5U)
#  endif

# endif /* RTE_CORE */

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* RTE_CBACKLIGHTCDD_TYPE_H */
