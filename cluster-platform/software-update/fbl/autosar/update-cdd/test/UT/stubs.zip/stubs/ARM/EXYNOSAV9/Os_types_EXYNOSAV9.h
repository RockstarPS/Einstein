/* Os_types_EXYNOSAV9.h
 *
 * This file defines the derivative-specific basic data types.
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
 */

/* MISRA-C:2012 Deviation List
 *
 * MISRAC2012-1) Deviated Rule: Dir 4.6 (advisory)
 *  typedefs that indicate size and signedness should be used in place of the
 *  basic numerical types.
 *
 * Reason:
 *  This *is* a declaration for such a typedef.
 */

#ifndef OS_TYPES_EXYNOSAV9_H
#define OS_TYPES_EXYNOSAV9_H

#ifdef __cplusplus
extern "C" {
#endif

/* EXYNOSAV9 data type characteristics:
 *
 * - OS_ENDIAN:			either OS_LITTLEENDIAN or OS_BIGENDIAN, as necessary.
 * - OS_ARCH_HAS_64BIT:	0 (64 bit data type not supported) or 1 (64 bit data type supported).
 */
#define OS_ENDIAN				OS_LITTLEENDIAN
#define OS_ARCH_HAS_64BIT		0
#define OS_ARM_INSTR_SET		OS_ARM_INSTR_SET_ARMV8

/* This derivative has an internal timestamp timer. */
#define OS_HAS_TB_INTERNAL		1

/* Exclusive reservation granule in words (4 byte units), see CTR.ERG */
#define OS_ARM_EXCL_RES_GRANULE			OS_U(16)

#ifndef OS_ASM

/* os_syncspot_t - type of internal locks
 * the ldrex/strex instruction pair are used for spinlock implementation.
 * 
 * Exclusive reservation granule is defined by Cache Type Register (CTR.ERG).
 * We use the first word (sl) as spinlock and all other ((2^CTR.ERG)-1) words as padding words.
*/
typedef struct os_syncspot_s os_syncspot_t;
/* Deviation MISRAC2012-1 <+4> */
struct os_syncspot_s
{
	volatile unsigned long sl;
	volatile unsigned long padding[OS_ARM_EXCL_RES_GRANULE - 1];
};

/* For the software sync spot (used by OS_SyncHere()), load/store exclusive
 * instructions or hardware semaphores are not used.
 * Values are only written to elements unique to the respective core and read
 * by all cores. With working cache-coherency, appropriate caching attributes,
 * or disabled caches, this is no problem.
 */
/* Deviation MISRAC2012-1 */
typedef volatile unsigned long os_sw_syncspot_t;
#endif

#define OS_SYNCSPOT_ALIGNMENT_GRANULE	(OS_ARM_EXCL_RES_GRANULE * 4)

#ifdef __cplusplus
}
#endif

#endif
/* Editor settings - DO NOT DELETE
 * vi:set ts=4:
*/
