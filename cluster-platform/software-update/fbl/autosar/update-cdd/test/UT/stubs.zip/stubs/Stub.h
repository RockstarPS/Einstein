#include "UPDi_BlockInstaller.h"
#include "UPDi_TarDecoder.h"
#include "UPDi_Types.h"
#include "UPDi_Target.h"
#include "CFls.h"
#include "Csm.h"
#include "UPDi_AesDecoder.h"
#include "DEFTYPES.h"
#include "LIB_LZBWP.h"


#define NULL 0

#define cFalse 0

#define max(a,b) (((a) (b)) ? (a) : (b))

#define min(a,b) (((a) < (b)) ? (a) : (b))

#define FUNC(rettype, memclass) rettype

#define UPD_HYPERFLASH_IOADAPTER STD_ON
#define UPD_CFLS_IOADAPTER STD_ON

#define UPD_HSM_IOADAPTER STD_ON
//#define UPD_AES_DECODER STD_ON
#define UPD_RSA_IOADAPTER STD_ON

//#define UPDd_INJECTION_TESTING // Only for unit testing
//#define UTEST // Only for unit test, do not use this on target

//#define UPDd_POINTER_TEST_DISABLED           // Disable the checks on pointers
#define UPDd_MAX_PACKAGE_NAME_SIZE 64        // Max size for package name
#define UPDd_LZMA_MEMORY_POOL_SIZE (1024) // Memory pool for LZMA decoding, encoder need to be configured with the same size
#define UPDd_LOAD_BUFFER_SIZE (256)       // Maximum IO chunk
#define UPDd_REQ_FIFO_SIZE 8 				 // Number of IO chunk on the IO decoupling queue
#define UPDd_HASH_BUFFER_SIZE (32)           // Internal buffer for storing the Hash

#define UPDd_COMPOSE_BUFFER_SIZE (1)        // If Delta Composition with A-Only is required, it shall be as big as the partition (can be 1 if not required)

#define UPDd_SPARSE_BLOCK_SIZE (1024)

#define UPDd_MAX_SLOT 2 // Can be 1 or 2, 2 when A & B is supported
#define E_PENDING 2u

// Constants for FLS
#define UPDd_FLS_PAGE_BUFFERING STD_ON     // when activated, UPD only write multiple of the page size
#define UPDd_FLS_SECTOR_WRITEPAGE_SIZE 512 // UPD only write multiple of the page size
#define UPDd_FLS_SECTOR_BASEADDRESS (0x0)  // Address of the first FLS Sector
#define UPDd_FLS_SECTOR_SIZE (32*1024)     // Sector Size, in case of resume, UPD only erase the last sector

#define UPDd_HW_PARTITION_SWICTH STD_OFF  // when activated, HW support the bank addresses switch. BankB is always inactive.

#define UPDd_UPDATE_ONCE_ACTIVE_CHAIN_VERIFIED 


typedef unsigned char       uint8;          /*           0 .. 255             */


typedef unsigned char         UINT8;
typedef   signed char         SINT8;
typedef unsigned short int    UINT16;
typedef unsigned long         UINT32;
typedef int Int32;
typedef Int32 INT32;

#define E_NOT_READY         ((Std_ReturnType) 2u)
#define E_INVALID_ARG       ((Std_ReturnType) 3u)

# define cDataBufferStartIndex              10uL

// #define SuspendOSInterrupts()		OS_UserSuspendInterrupts(OS_LOCKTYPE_OS)
// #define ResumeOSInterrupts()		OS_UserResumeInterrupts(OS_LOCKTYPE_OS)

// #define OS_UserSuspendInterrupts(l)				//OS_VOIDCALL(OS_KernSuspendInterrupts(l))
// #define OS_UserResumeInterrupts(l)	

// int strncmp (const char *A, const char *B, size_t c)
// {
//     return 0;
// }

//uint8 Global_var = 0;

//uint8 Global_var_01 = 0;
const char g_var[10];
uint8 arr1[32u];

typedef long long		int64_t;
typedef unsigned		uint32_t;
uint32 oFlsIoAdapter_RollingBuffer[10u];
uint8 *enumvar;
uint32 l_downloadsize_u32;
uint16 u16Used1;



UPDd_GetInactiveBank(this, pBank);
/*LIBzm*/
LIBLzbwInit(u16Used1);
uint32 LIBLzbwDecode( uint32 var_01, uint32 var_02, uint32 var_03, uint32 var_05,  uint16 *var_04 ,  uint8 );
/*Target*/
UpDdi_GetEraseSize(uint32 addr);
/*UPDi_LzbwDecoder*/

/*AES*/
UPDd_GetInitialIV(uint8 InitialIV_Buffer_U8[0]);


tUPDBank UpdateCdd_BankType; // defined to which bank is the update related (active/inactive)

/*AES*/
typedef enum
{
   CSM_E_OK,
   CSM_E_NOT_OK,
   CSM_E_BUSY,
   CSM_E_SMALL_BUFFER,
   CSM_E_ENTROPY_EXHAUSTION,
   CSM_E_KEY_NOT_AVAILABLE
};

tUPDiAbstractInstaller_Vtbl tUPDiAbstr_Vtbl;
tUPDiAesDecoder_Ram tAesDecoder_Ram;

/*typedef const struct 
{ 
    tUPDiAbstractInstaller_Vtbl* Vtbl; 
    tUPDiAesDecoder_Ram* Ram;
} tUPDiAesDecoder;*/
tUPDiAesDecoder tUPDiAesDcoder=
{
    &tUPDiAbstr_Vtbl,
    &tAesDecoder_Ram
};

/*UPDi*/
struct sUPDiTarget  uUPDiTarget;
struct sUPDiInstallSession  uUPDiInstallSession;

struct sUPDiTargetRam sUPDiTargetRam2;
struct sUPDiPartitionGroup sUPDiPartitionGrou2;
/*typedef const struct sUPDiTarget
{ 
    tUPDiTargetRam* Ram;
    const char* Name;
    uint8 GroupsCount; 
    tUPDiPartitionGroup* Groups; 
} tUPDiTarget;*/

tUPDiTarget tUPDiTarget1=
{
     &sUPDiTargetRam2,
     &g_var,
     10,
     &sUPDiPartitionGrou2
};

tUPDiIoAdapter** IoAdapters;

struct sUPDiTarget sUPDiTarget100;
struct sUPDiTarget sUPDiTarget101;

tUPDiIoAdapter IoAdapteu[2]={&sUPDiTarget100,
                                   &sUPDiTarget101};

/*IOadapter*/
struct sUPDiIoReq sUPDiIoReq_01;
struct sUPDiIoAdapterVtbl sUPDiIoAdapterVt2;

/*typedef struct
{
    uint32 PendingCalls;  
    uint16 NextToProduce; 
    uint16 NextToConsume; 
    uint8* AdapterBuffer;
} tUPDiIoAdapterRam;*/
tUPDiIoAdapterRam tUPDiIoAdapRam2=
{
    10,
    10,
    10,
    10
};
//tUPDiIoReq IoReqInfo;//for UT
/*typedef struct sUPDiIoAdapter
{
    tUPDiIoAdapterVtbl* Vtbl;
    tUPDiIoAdapterRam* Ram;
} tUPDiIoAdapter;*/
tUPDiIoAdapter  tUPDiIoAdapte2=
{
 &sUPDiIoAdapterVt2,
 &tUPDiIoAdapRam2
};


/*updateman*/
uint16 Targets=10;
tUPDiTarget tUPDiTargettar;
tUPDiIoAdapter tUPDiIoAdaadap;
struct sUPDiAbstractInstaller sUPDiAbstrinstal;
tUPDiInstallSession tUPDiInssession;
tUPDiBufferPool tUPDiBupool;
/*typedef const struct
{
    tUPDiMode Mode;
    uint16 TargetsCount;
    tUPDiTarget** Targets;
    uint16 IoAdaptersCount;
    tUPDiIoAdapter** IoAdapters;
    uint16 InstallersCount;
    const struct sUPDiAbstractInstaller** Installers;
    tUPDiInstallSession* Sessions;
    uint16 SessionsCount;
    tUPDiBufferPool* Buffer;
} tUPDiUpdateCdd;*/

tUPDiUpdateCdd ttUPDiUpdateCddd=
{
 0,
 10,
 &tUPDiTargettar,
 10,
 &tUPDiIoAdaadap,
 10,
 &sUPDiAbstrinstal,
 &tUPDiInssession,
 10,
 &tUPDiBupool
};

/*Target*/
struct sUPDiTargetRam sUPDiTarRam;
struct sUPDiPartitionGroup sUPDiPartGroup;
/*typedef const struct sUPDiTarget
{ 
    tUPDiTargetRam* Ram;
    const char* Name;
    uint8 GroupsCount; 
    tUPDiPartitionGroup* Groups; 
} tUPDiTarget;*/

tUPDiTarget tUPDiTatarget=
{
    &sUPDiTarRam,
    &g_var,
    10,
    &sUPDiPartGroup
};

/*Blockinstaller*/
tUPDiBlockInstaller_Ram tUPDiBlInst_Ram;
/*typedef const struct sUPDiBlockInstaller
{ 
    tUPDiAbstractInstaller_Vtbl* Vtbl; 
    tUPDiBlockInstaller_Ram* Ram; 
} tUPDiBlockInstaller;*/

tUPDiBlockInstaller tUPDiBlInstaller=
{
    &tUPDiAbstr_Vtbl,
    &tUPDiBlInst_Ram
};


struct sUPDiAbstractInstaller sUPDiAbInstaller;
struct sUPDiTarget sUPDiTarget100;
struct sUPDiTarget sUPDiTarget101;

tUPDiTarget updatemanTargets[2]={&sUPDiTarget100,
                                   &sUPDiTarget101};


/*typedef struct sUPDiInstallSession
{
    const struct sUPDiAbstractInstaller* RootInstaller;
    const struct sUPDiTarget* Target;
    uint32  PartitionInstalled; // one bit per partition for the curent Target, 
                                // when the bit is set the partition installation is done or pending in the IoAdapter queue
    uint32  InstalledSize;      // remaining size to be processed
    uint32  PackageSize;        // root package size
    boolean IsActive;
    tUPDiDataFormatType DataFormat;
} tUPDiInstallSession;*/

tUPDiInstallSession tUPDiInstallSsesession=
{
 &sUPDiAbInstaller,
 &sUPDiTarget100,
 10,
 10,
 10,
 1,
1
};


/*Installman*/
/*typedef const struct
{
    tUPDiMode Mode;
    uint16 TargetsCount;
    tUPDiTarget** Targets;
    uint16 IoAdaptersCount;
    tUPDiIoAdapter** IoAdapters;
    uint16 InstallersCount;
    const struct sUPDiAbstractInstaller** Installers;
    tUPDiInstallSession* Sessions;
    uint16 SessionsCount;
    tUPDiBufferPool* Buffer;
} tUPDiUpdateCdd;*/

struct suUPDiUpdateCdd *oUPDCdd1;
struct sUPDiBufferPool sUPDiBufpool;
struct sUPDiBufferSet sUPDiBuferSet;


struct sUPDiBuffer sUPDiBuffe_02;
struct sUPDiBuffer sUPDiBuffe_03;
tUPDiAesDecoder_Ram tUPDiAesDecoder_Ram_02;
/*typedef struct 
{ 
    tUPDiBuffer InBuffer;
    tUPDiBuffer OutBuffer;
    tUPDiAbstractInstaller* pNestedInstaller;
} tUPDiAesDecoder_Ram;*/

/*typedef const struct 
{ 
    tUPDiAbstractInstaller_Vtbl* Vtbl; 
    tUPDiAesDecoder_Ram* Ram;
} tUPDiAesDecoder;*/

tUPDiAesDecoder  tUPDiAesDecoder_02=
{
 NULL,
 &tUPDiAesDecoder_Ram_02
};





/*updateman*/
struct suUPDiUpdateCdd oUPDCdd;

/*qsp*/
// ExtMemMgr_Erase(uint8 val1, uint16 val2, uint8 val3, uint8);
// ExtMemMgr_GetJobResult(uint8);
// ExtMemMgr_Init();
// ExtMemMgr_Write(uint8 ,uint16 val4, uint16 val5, uint16 val6);

// typedef enum
// {
//     EExtMemMgrJobResult_OK,
//     EExtMemMgrJobResult_JobPending,
//     EExtMemMgrJobResult_JobFailed
// } ExtMemMgr_JobResultType;


/*For oUPDCdd_Targets*/
//Std_ReturnType *stub_01(tUPDiIoReq* Req);

/*typedef struct sUPDdManifest
{
    uint32 GoldenCrc; // Define the expected value of the CRC32, CRC ploynomial is Polynomial 0x04C11DB7h
    uint8  GoldenSha256[32];
    uint8  VersionMajor;
    uint8  VersionMinor;
} tUPDdManifest;*/

// tUPDdManifest ActiveManifest_01=
// {
//  10,
//  {1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,31,32},
//  10,
//  10
// };

// tUPDdManifest InactiveManifest_01=
// {
//  10,
//  {1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,31,32},
//  10,
//  10
// };

/*typedef struct sUPDiTargetRam
{
    tUPDdManifest ActiveManifest;
    tUPDdManifest InactiveManifest;
    tUPDiTargetState InactiveState;
    uint16 nextPartitionIndex; // for erase, copy, deploy or crc iterations
    uint32 nextByte;// for erase, copy, deploy or crc iterations
    uint8 nextTargetIndex;
} tUPDiTargetRam;*/

tUPDiTargetRam oTestTarget_Ram_01=
{
 {
 10,
 {1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,31,32},
 10,
 10
},
 {
 10,
 {1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,31,32},
 10,
 10
},
 10,
 10,
 10,
 10
};
/*oUPDCdd_Targets*/
// tUPDiTarget Global_arr=
// { 
// .Name = "TestTarget",
//  .Ram = &oTestTarget_Ram_01, 
//   .GroupsCount = 0,
//   .Groups = 0 
//   };
/*typedef const struct sUPDiTarget
{ 
    tUPDiTargetRam* Ram;
    const char* Name;
    uint16 GroupsCount; 
    tUPDiPartitionGroup* Groups; 
} tUPDiTarget;*/

 tUPDiTarget*           oUPDCdd_Targets[3]=
{
    {   &oTestTarget_Ram_01, 
         "TestTarget",
   0,
   NULL
    },
       {   &oTestTarget_Ram_01, 
         "TestTarget",
   0,
   NULL
    },
       {   &oTestTarget_Ram_01, 
         "TestTarget",
   0,
   NULL
    }
};

//void fn(void);









// struct sUPDiTarget Global_var_02 =
// {
//    0,
//    g_var,
//    10,
//    0 
// };

// struct sUPDiPartition Global_var_03 =
// {
//     0x00,
//     1,
//     0
// };


// struct sUPDiInstallSession Global_var_04 =
// {
//     0,
//     0,
//     10,
//     10,
//     10,
//     1
// };




tUPDiBlockInstaller *global_add = {

        0,
        0,
        0,
        0,
        0,
        0,
        0,
    {
        {
            0X1000,
            10,
            {
                {
                    0,
                },
                {
                    10,
                    10,
                    10
                },
                10,
                10
            }
        },
        12                                                                              
    }
};



tUPDiInstallSession *global_add_psession_01 = {
    
            0,
            0,
            0,
            0,
            0,
            0,
            0,
    
    {
        {
            {
                10,
                {1,2,3,4,5,6,7,8,9},
                10,
                10
            },
            {
                10,
                {1,2,3,4,5,6,7,8,9},
                10,
                10
            },
            10,
            10,
            10,
            10
        },
        'a',
        10,
        {
            'a',
            {
                0x00,
                10,
                {
                    {
                        0,
                    }
                },
            },
            {
                0x00,
                10,
                {
                    {
                        0,
                    }
                },
            },
            {
                0x00,
                10,
                {
                    {
                        0,
                    }
                },
            },

        },
    },
    10,
    10,
    10,
    1
};

/*
void fn(void)
{
    global_add->Ram->NextByte = 0;
    global_add->Ram->pPartition->Address = 0x00;
    global_add->Ram->pPartition->Size = 1;
    global_add->Ram->pPartition->IoAdapter->Vtbl->ProcessReq = NULL;
    global_add->Ram->pPartition->IoAdapter->Ram->NextToConsume = NULL;
    global_add->Ram->pPartition->IoAdapter->Ram->NextToProduce = NULL;
    global_add->Ram->pPartition->IoAdapter->Ram->PendingCalls = NULL;
    global_add->Ram->pPartition->IoAdapter->pRollingBuffer = NULL;
    global_add->Ram->pPartition->IoAdapter->RollingBufferSize = NULL;
    global_add->Vtbl->GetExtension = NULL;
    global_add->Vtbl->InstallErase = NULL;
    global_add->Vtbl->InstallStart = NULL;
    global_add->Vtbl->InstallData = NULL;
    global_add->Vtbl->InstallExit = NULL;
    global_add->Vtbl->Serialize = NULL;
    global_add->Vtbl->Deserialize = NULL;
}
*/


/*
const char* Stub1 (const struct sUPDiAbstractInstaller* this)
{
    
}
*/




// Std_ReturnType *stub_01(tUPDiIoReq* Req)
// {
//  /*dummy*/
// };

/*
typedef struct sUPDiInstallSession
{
    const struct sUPDiAbstractInstaller* RootInstaller;
    const struct sUPDiTarget* Target;
    uint32  PartitionInstalled; // one bit per partition for the curent Target, 
                                // when the bit is set the partition installation is done or pending in the IoAdapter queue
    uint32  RemainingSize;        // remaining size to be processed
    uint32  PackageSize;        // root package size
    boolean IsSuspended;
} tUPDiInstallSession;


*/

/*Blockinstaller InstallStart*/


/*
typedef const struct sUPDiTarget
{ 
    tUPDiTargetRam* Ram;
    const char* Name;
    uint16 GroupsCount; 
    tUPDiPartitionGroup* Groups; 
} tUPDiTarget;*/


/*typedef struct sUPDdManifest
{
    uint32 GoldenCrc; // Define the expected value of the CRC32, CRC ploynomial is Polynomial 0x04C11DB7h
    uint8  GoldenSha256[32];
    uint8  VersionMajor;
    uint8  VersionMinor;
} tUPDdManifest;*/

// tUPDdManifest Global_var_13=
// {
//  10,
//  {1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,31,32},
//  10,
//  10
// };

// tUPDdManifest  Global_var_14=
// {
//  11,
//  {1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,31,32},
//  11,
//  11
// };


/*
typedef struct sUPDiTargetRam
{
    tUPDdManifest ActiveManifest;
    tUPDdManifest InactiveManifest;
    tUPDiTargetState InactiveState;
    uint16 nextPartitionIndex; // for erase, copy, deploy or crc iterations
    uint32 nextByte;// for erase, copy, deploy or crc iterations
    uint8 nextTargetIndex;
    uint8  hashingCycles;
} tUPDiTargetRam;*/

 tUPDiTargetRam Global_var_07=
{
    {
 10,
 {1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,31,32},
 10,
 10
},
    {
 11,
 {1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,1,2,3,4,5,6,7,8,9,10,31,32},
 11,
 11
},
    10,
    10,
    10,
    10,
    10
};

struct sUPDiTarget Global_var_06=
{
    &Global_var_07,
    g_var,
    10,
    NULL
};

// const tUPDiInstallSession Global_var_05=
// {
//         NULL,
//         &Global_var_06,
//         10,
//         10,
//         1 
// };


//(this->Ram->pPartition->IoAdapter->pRollingBuffer)

/*typedef  struct
{
    uint32 PendingCalls; 
    uint16 NextToProduce; 
    uint16 NextToConsume; 
} tUPDiIoAdapterRam;*/

// tUPDiIoAdapterRam Global_var_12=
// {
//  10,
//  10,
//  10
// };

/*typedef struct sUPDiIoAdapter
{
    tUPDiIoAdapterVtbl* Vtbl;
    tUPDiIoAdapterRam* Ram;
    uint8* pRollingBuffer;
    uint16 RollingBufferSize;
} tUPDiIoAdapter;*/

// sUPDiIoAdapter Global_var_11=
// {
//  NULL,
//  &Global_var_12,
//  10,
//  10
// };



/*typedef const struct sUPDiPartition
{
    uint32 Address;
    uint32 Size;
    struct sUPDiIoAdapter* IoAdapter;
} tUPDiPartition;*/

// struct sUPDiPartition Global_var_10=
// {
//     0x00,
//     10,
//     &Global_var_11
// };


/*typedef struct 
{ 
    const struct sUPDiPartition* pPartition; 
    uint32 NextByte; 
} tUPDiBlockInstaller_Ram;
*/

// tUPDiBlockInstaller_Ram Global_var_09=
// {
//  &Global_var_10,
//  10
// };

/*typedef const struct 
{ 
    tUPDiAbstractInstaller_Vtbl* Vtbl; 
    tUPDiBlockInstaller_Ram* Ram; 
} tUPDiBlockInstaller;
*/
tUPDiBlockInstaller Global_var_08;
// tUPDiBlockInstaller Global_var_08=
// {
//     NULL,
//     &Global_var_09,
// };

//this->Ram->pPartition->Address + pSession->Target->Ram->nextByte;

//(this->Ram->pPartition->IoAdapter, pSession->Target, this->Ram->pPartition,address,Size,Data);

const char* Stub1 (const struct sUPDiAbstractInstaller* this);
const char* Stub1 (const struct sUPDiAbstractInstaller* this)
{
    /*dummy*/
}

/*Abstractiinstaller*/
*InstallErase(const struct sUPDiAbstractInstaller* this,tUPDiInstallSession* pSession, const char* PackageName, uint32 Size);
*InstallErase(const struct sUPDiAbstractInstaller* this,tUPDiInstallSession* pSession, const char* PackageName, uint32 Size)
{
 /*dummy*/
};
// Std_ReturnType *tpfInstallStart_01(const struct sUPDiAbstractInstaller* this, tUPDiInstallSession* pSession, uint32 Size)
// {
// /*dummy*/
// };

/*typedef const struct
{
    tpfGetExtension GetExtension;
    tpfInstallErase InstallErase;
    tpfInstallStart InstallStart;
    tpfInstallData InstallData;
    tpfInstallExit InstallExit;
    tpfSerialize Serialize;
    tpfDeserialize Deserialize;
} tUPDiAbstractInstaller_Vtbl;*/

// tUPDiAbstractInstaller_Vtbl AbstractInstaller=
// {
//     NULL,
//     &InstallErase,
//     &tpfInstallStart_01,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
// };

// tUPDiIoAdapterVtbl UPDFlsIoAdapterVtbl_stub =
// { 
//      .ProcessReq = (tpfProcessReq)UPDFlsIoAdapter_ProcessReq,
// };
/*CFLS and HSM*/
Std_ReturnType UPDCFlsIoAdapter_ProcessReq(tUPDiIoReq* Req);
Std_ReturnType UPDSblIoAdapter_ProcessReq(tUPDiIoReq* Req);
Std_ReturnType UPDHsmIoAdapter_ProcessReq(tUPDiIoReq* Req);//for UT
// void UPDTarget_IoEraseIdle(tUPDiTarget* this)
// {
//    UPDTarget_SetState(this,eUPDiTarget_UninstIdleEmpty);
// }

//tUPDiIoReq IoReqInfo;//for UT
CFls_OperationStatusType CFls_Init
(
    void
);

/*typedef enum
{
	eTarDone=0,
    eTarLoadingHeader,
    eTarInstallingFile,
    eTarLoadingPadding,
    eTarLoadingEndOfArchive,
} tUPDiTarDecoderState;*/
// tUPDiTarDecoderState statetardecoder=
// {
//   0,
//   1,
//   2,
//   3,
//   4,
// };

// tUPDiGenDecoder_Vtbl *thisvtbl=
// {
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL
// };

/*typedef struct 
{ 
    // From AbstractInstaller
    uint32 NextByte; // next byte to be installed
    // From GenDecoder
    tUPDiAbstractInstaller* pChild;
    tUPDdPackageName PackageName;
    tUPDdPackageName ChildPackageName;
    tUPDiGenDecoderState State;
    uint32 Processed;
    uint32 ToProcess;
    uint32 ChunkSize;
    uint32 ResumeAt;
    uint8 LoadBuffer[UPDd_LOAD_BUFFER_SIZE];
    uint8* pTransformBuffer;
    uint32 OutSizeProcessed;
} tUPDiGenDecoderRam;*/

//  tUPDiGenDecoderRam Parent_1=
//  {
//   10,
//   NULL,
//   {1,2,3,4,5,},
//   {1,2,3,4,5,},
//   0,
//   10,
//   10,
//   10,
//   10,
//   {1,2,3},
//   &enumvar,
//   10
//  };
/*typedef struct 
{ 
    tUPDiGenDecoderRam Parent;
    tUPDiTarDecoderState State;
    uint32         PaddingSize;
} tUPDiTarDecoderRam;*/
// tUPDiTarDecoderRam tardecoder=
// {
//    &Parent_1,
//  eTarLoadingHeader,
//  10
// };

// tUPDiTarDecoderRam tardecoder_1=
// {
//  NULL,
//  1,
//  10
// };

// tUPDiTarDecoderRam tardecoder_2=
// {
//  NULL,
//  2,
//  10
// };

// tUPDiTarDecoderRam tardecoder_3=
// {
//  NULL,
//  3,
//  10
// };

// tUPDiTarDecoderRam tardecoder_4=
// {
//  NULL,
//  4,
//  10
// };





/*typedef const struct 
{ 
    tUPDiGenDecoder_Vtbl* Vtbl;
    tUPDiTarDecoderRam* pRam;
} tUPDiTarDecoder;
*/
// tUPDiTarDecoder thisdecoder=
// {
//     &thisvtbl,
//     &tardecoder
// };

// tUPDiTarDecoder thisdecoder_1=
// {
//     &thisvtbl,
//     &tardecoder_1
// };

// tUPDiTarDecoder thisdecoder_2=
// {
//     &thisvtbl,
//     &tardecoder_2
// };

// tUPDiTarDecoder thisdecoder_3=
// {
//     &thisvtbl,
//     &tardecoder_3
// };

// tUPDiTarDecoder thisdecoder_4=
// {
//     &thisvtbl,
//     &tardecoder_4
// };

/*typedef struct
{
    uint8              HashSize; // Size in Byte, 4 for CRC32, 32 for SHA256
    tUPDHashingType   HashType;
    uint8*             pHash;
} tUPDHashInfo;*/
//tUPDHashInfo tUPDHashInfoo;

/*typedef const struct sUPDiPartitionGroup
{
    const char * Name;
    tUPDiPartition* BankA;
    tUPDiPartition* BankB;
    tUPDiPartition* BankExt;
} tUPDiPartitionGroup;*/


//struct sUPDiPartitionGroup Groupstar;
struct sUPDiPartitionGroup Groupstarr[2];

struct sUPDiPartition sUPDiPartitiontarget;


/*typedef const struct sUPDiTarget
{
    tUPDiTargetRam* pRam;
    const char* Name;
    uint16 GroupsCount;
    tUPDiPartitionGroup* Groups;
} tUPDiTarget;*/

// tUPDiTarget tUPDiTarget_1=
// {
//  &Global_var_07,
//  &g_var,
//  10,
//  &Groupstar
// };

/*Deltadecoder*/
//tUPDiGenDecoderRam tUPDiGenDecoderRam_1;
/*typedef struct 
{ 
    tUPDiGenDecoderRam Parent;// shall be first
    tUPDiDeltaDecoderState State;
    uint32 LastWritePos; // Size of the output image
    uint32 WritePos; // Curent Write pointer
    sint32 ReadPos; // Curent Write pointer
    uint32 ComposedSectionSize; // form the last control block
    uint32 ExtraSectionSize;// form the last control block
    uint32 SkipedSectionSize;// form the last control block
} tUPDiDeltaDecoderRam;*/

// tUPDiDeltaDecoderRam tUPDiDeltaDepram=
// {
//     &tUPDiGenDecoderRam_1,
//     0,
//     10,
//     10,
//     10,
//     10,
//     10,
//     10
// };
/*typedef const struct 
{ 
    tUPDiGenDecoder_Vtbl* Vtbl;
    tUPDiDeltaDecoderRam* pRam;
} tUPDiDeltaDecoder;*/

//  tUPDiDeltaDecoder tUPDiDeltathhis=
// {
//     NULL,
//     &tUPDiDeltaDepram
// };

//      typedef _UIntType result_type;
//  static constexpr result_type
//       min();
//       static constexpr result_type
//       min()
//       { return __c == 0u ? 1u : 0u; }


Std_ReturnType UPDHyperFlashIoAdapter_ProcessReq(tUPDiIoReq* Req);

Std_ReturnType *tpfInstallStart_01(const struct sUPDiAbstractInstaller* this, tUPDiInstallSession* pSession, uint32 Size)
{
/*dummy*/
};

Std_ReturnType *tpfGetExtension_01(const struct sUPDiAbstractInstaller* this, tUPDiDataFormatType* pDataFormat)
{
    /*dummy*/
};
 Std_ReturnType *tpfInstallErase_01(const struct sUPDiAbstractInstaller* this, tUPDiInstallSession* pSession, uint32 Size)
 {

 };

 Std_ReturnType*tpfInstallExit_01(const struct sUPDiAbstractInstaller* this, tUPDiInstallSession* pSession)
 {

 };
 Std_ReturnType *tpfSerialize_01(const struct sUPDiAbstractInstaller* this, uint32 SizeIn, uint8* data)
 {

 };
 Std_ReturnType *tpfDeserialize_01(const struct sUPDiAbstractInstaller* this, uint32 SizeIn, uint8* data)
 {

 };

  Std_ReturnType *tpfInstallData_01(const struct sUPDiAbstractInstaller* this, tUPDiInstallSession* pSession, uint8* Data, uint32 Size)
 {

 };
/*install Man*/
/*typedef const struct 
{ 
    tpfGetExtension GetExtension;
    tpfInstallErase InstallErase;
    tpfInstallStart InstallStart;
    tpfInstallData InstallData;
    tpfInstallExit InstallExit;
    tpfSerialize Serialize;
    tpfDeserialize Deserialize;
} tUPDiAbstractInstaller_Vtbl;*/

tUPDiAbstractInstaller_Vtbl   AbstractInstll=
{
 &tpfGetExtension_01,
 &tpfInstallErase_01,
 &tpfInstallStart_01,
 &tpfInstallData_01,
 &tpfInstallExit_01,
 &tpfSerialize_01,
 &tpfDeserialize_01
};
/*typedef const struct sUPDiAbstractInstaller
{
    tUPDiAbstractInstaller_Vtbl* Vtbl;
} tUPDiAbstractInstaller;*/

tUPDiAbstractInstaller tUPDiAbstractInsaman=
{
    &AbstractInstll
};


/*UPDi*/

struct sUPDiTarget sUPDiTargett;
struct sUPDiAbstractInstaller sUPDiAbstractInstallerrr;

/*typedef const struct
{
    tUPDiMode Mode;
    uint16 TargetsCount;
    const struct sUPDiTarget** Targets;
    uint16 IoAdaptersCount;
    struct sUPDiIoAdapter** IoAdapters;
    uint16 InstallersCount;
    const struct sUPDiAbstractInstaller** Installers;
    struct sUPDiInstallSession* Sessions;
    uint16 SessionsCount;
} tUPDiUpdateCdd*/

/*typedef struct
#endif
{
    tUPDiMode Mode;
    uint8 TargetsCount;
    uint8 InstallersCount;
    const struct sUPDiTarget** Targets;
    const struct sUPDiAbstractInstaller** Installers;
} tUPDiUpdateCdd;*/
 struct sUPDiTarget Targetss[2];
 struct sUPDiAbstractInstaller Installerss[2];
tUPDiPartitionGroup tUPDiPartitionGropps[3];


tUPDiUpdateCdd oUPDCdd_1;
// {
//     0,
//     2,
//     10,
//     &sUPDiTargett,
//     &sUPDiAbstractInstallerrr
// };

/*Abstract*/
/*typedef const struct
{
    tpfGetExtension GetExtension;
    tpfInstallStart InstallStart;
    tpfInstallData InstallData;
    tpfInstallExit InstallExit;
    tpfSerialize Serialize;
    tpfDeserialize Deserialize;
    tpfRewind Rewind;
} tUPDiAbstractInstaller_Vtbl;*/

tUPDiAbstractInstaller_Vtbl tUPDiAbstractInstallvtbl1;

/*typedef const struct sUPDiAbstractInstaller
{
    tUPDiAbstractInstaller_Vtbl* Vtbl;
} tUPDiAbstractInstaller;*/

struct sUPDiAbstractInstaller tUPDiAbstractIn;
// {
//     &tUPDiAbstractInstallvtbl1
// };

/*AESdecoder*/
//tUPDiAbstractInstaller pNestedInstaller_1;
/*typedef struct 
{ 
    uint8 tdb; // TBD : for the internal  context
    tUPDiAbstractInstaller* pNestedInstaller;
} tUPDiAesDecoder_Ram;*/

// typedef struct tUPDiAesDecoder_Ram  tUPDiAesDecoder_aesRam =
// {
//     10,
//     &pNestedInstaller_1
// };

/*typedef const struct 
{ 
    tUPDiAbstractInstaller_Vtbl* Vtbl; 
    tUPDiAesDecoder_Ram* Ram;
} tUPDiAesDecoder;*/

// typedef struct tUPDiAesDecoder  tUPDiAesDecoderder=
// {
//     &AbstractInstll,
//     &tUPDiAesDecoder_aesRam
// };


/*Gendecoder*/

// Std_ReturnType *fnDecoder_Transf(const struct sUPDiGenDecoder* this, uint8* Data, uint32* pSize, uint8** ppTransformBuffer, uint32* pTransformSize);
// Std_ReturnType *fnDecoder_Transf(const struct sUPDiGenDecoder* this, uint8* Data, uint32* pSize, uint8** ppTransformBuffer, uint32* pTransformSize)
// {
// /*dummy*/
// };

// struct sUPDiGenDecoder_Vtbl tUPDiGenDecoder_Vtbl11=
// {
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     NULL,
//     &fnDecoder_Transf
// };


//struct sUPDiGenDecoder sUPDiGenDecodeer;

/*RSA*/
struct sUPDiTarget sUPDiTarrsa;

/*spardecoder*/
//struct sparse_header sparse_headererer;

/*IOadapter*/
Std_ReturnType *tURead (tUPDiPartition* pPartition, uint32 Offset, uint32 Size, uint8* pBuffer)
{
/*dummy*/
};

 Std_ReturnType *twrite (tUPDiPartition* pPartition, uint32 Offset, uint32 Size, uint8* Data)
 {
/*dummy*/
 };

 Std_ReturnType *tUErase (tUPDiPartition* pPartition, uint32 Offset, uint32 Size)
 {
/*dummy*/
 };

Std_ReturnType *tGet (tUPDiPartition* pPartition, uint32* pOffset, uint32* pSize)
{
/*dummy*/
};

/*typedef const struct sUPDiIoAdapterVtbl
{
	tUPDIoAdapter_Read  Read;
	tUPDIoAdapter_Write Write;
	tUPDIoAdapter_Erase Erase;
	tUPDIoAdapter_GetErasableArea GetErasableArea;
    tpfProcessReq ProcessReq;
} tUPDiIoAdapterVtbl;*/
struct sUPDiIoAdapterVtbl  sUPDiIoAda=
{
 &tURead,
 &twrite,
 &tUErase,
 &tGet,
 NULL
};

/*typedef const struct sUPDiPartition
{

    const char* path;
    uint32 Address;
    uint32 Size;
    const struct sUPDiIoAdapterVtbl* IoAdapter;
} tUPDiPartition;*/
 tUPDiPartition tUPDiPart;
// {
//   1,
//   0x123,
//   10,
//   NULL
// };

/*HSMIOadaptor*/
tUPDiIoAdapterRam tUPDiIoAdapttan;
/*typedef struct sUPDiIoAdapter
{
    tUPDiIoAdapterVtbl* Vtbl;
    tUPDiIoAdapterRam* Ram;
    uint8* pRollingBuffer;
    uint16 RollingBufferSize;
} tUPDiIoAdapter;*/
struct sUPDiIoAdapter  sUPDiIoAdapterre=
{
 NULL,
 &tUPDiIoAdapttan,
 &enumvar,
 10
};
typedef struct sUPDiHashingContext tUPDiHashingContext;
struct sUPDiTarget sUPDiTargeeet;
tUPDiHashingContext tUPDiHashingConteeet;
struct sUPDiBlockInstaller sUPDiBlockInstaller1;
/*typedef struct sUPDiIoReq
{
    uint32 Address;
    uint32 Size;
    const struct sUPDiTarget* pTarget;
    tUPDiIoReqType ReqType;
    tUPDiHashingContext* pHashingContext;
    struct sUPDiIoAdapter* pIoAdapter;
} tUPDiIoReq;*/

tUPDiIoReq tUPDiIoReqadaptor=
{
    0x123,
    10,
    &sUPDiTargeeet,
    0,
    &tUPDiHashingConteeet,
    &sUPDiIoAdapterre
};

/*Gendecoder*/
// struct sUPDiGenDecoder;

// typedef struct sUPDiGenDecoder tUPDiInstallSession;

//typedef struct sUPDiGenDecoder tUPDdPackageName;
// typedef char tUPDdPackageName[UPDd_MAX_PACKAGE_NAME_SIZE];
