//---------------------------------------------------------------------------------------------------------------------
//
// VISTEON CORPORATION CONFIDENTIAL
// ________________________________
//
// [2015] Visteon Corporation
// All Rights Reserved.
//
// NOTICE: This is an unpublished work of authorship, which contains trade secrets.
// Visteon Corporation owns all rights to this work and intends to maintain it in confidence to preserve
// its trade secret status. Visteon Corporation reserves the right, under the copyright laws of the United States
// or those of any other country that may have jurisdiction, to protect this work as an unpublished work,
// in the event of an inadvertent or deliberate unauthorized publication. Visteon Corporation also reserves its rights
// under all copyright laws to protect this work as a published work, when appropriate.
// Those having access to this work may not copy it, use it, modify it, or disclose the information contained in it
// without the written authorization of Visteon Corporation.
//
//---------------------------------------------------------------------------------------------------------------------
#ifndef EXTMEMMGR_H
#define EXTMEMMGR_H

#include "ExtMemMgr_Types.h"

//=====================================================================================================================
//  CONSTANTS & TYPES
//=====================================================================================================================


//=====================================================================================================================
//  FORWARD DECLARATIONS
//=====================================================================================================================
void ExtMemMgr_Init( void );
void ExtMemMgr_DeInit( void );
Std_ReturnType ExtMemMgr_Write(const uint8 DeviceNr, const ExtMemMgr_AddressType TgtAddress, uint8* SrcAddressPtr, const ExtMemMgr_LengthType Length);
Std_ReturnType ExtMemMgr_Read (const uint8 DeviceNr, const ExtMemMgr_AddressType SrcAddress, uint8* TgtAddressPtr, const ExtMemMgr_LengthType Length);
Std_ReturnType ExtMemMgr_Erase(const uint8 DeviceNr, const ExtMemMgr_AddressType TgtAddress, const ExtMemMgr_LengthType Length, const boolean isFullChipErase);
ExtMemMgr_JobResultType ExtMemMgr_GetJobResult(const uint8 DeviceNr);
boolean ExtMemMgr_CheckReading(const uint8 DeviceNr);
void ExtMemMgr_MainFunction(void);

#endif //EXTMEMMGR_H
