/* Os_atomics_ARM.h
 *
 * This file contains the common part of the atomic functions for ARM.
 * It mainly selects between the load/store-exclusive and the hardware-semaphore
 * variants.
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
*/
#ifndef OS_ATOMICS_ARM_H
#define OS_ATOMICS_ARM_H

#include <ARM/Os_ARM_cpu.h>

#if (OS_HAS_ARCHSPINLOCK == 1)
#include <ARM/Os_atomics_ex_ARM.h>
#elif (OS_ARM_HAS_SEMA4 == 1)
#include <ARM/Os_atomics_sema4_ARM.h>
#else
#error "No valid atomics implementation found."
#endif

#endif /* OS_ATOMICS_ARM_H */

/* Editor settings - DO NOT DELETE
 * vi:set ts=4:
*/
