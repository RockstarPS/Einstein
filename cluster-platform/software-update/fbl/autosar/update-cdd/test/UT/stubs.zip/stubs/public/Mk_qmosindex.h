/* Mk_qmosindex.h - indexes for the QM-OS services
 *
 * The services from the start of the list up to the commented place are directly
 * callable by threads. Those after the comment are the QM-OS parts of hybrid system
 * calls and are called by the microkernel.
 *
 * (c) Elektrobit Automotive GmbH
*/
#ifndef MK_QMOSINDEX_H
#define MK_QMOSINDEX_H

#include <public/Mk_public_types.h>

#ifndef MK_ASM

/* mk_qmosindex_t - an enumerated type listing all the QM-OS functions.
*/
/* !LINKSTO Microkernel.CompilerLimitation.ShortEnum, 1
 * !doctype src
*/
enum mk_qmosindex_e
{
	MK_qmos_SetRelAlarm = 0,
	MK_qmos_SetAbsAlarm,
	MK_qmos_CancelAlarm,
	MK_qmos_IncrementCounter,
	MK_qmos_StartScheduleTable,
	MK_qmos_StartScheduleTableSynchron,
	MK_qmos_NextScheduleTable,
	MK_qmos_StopScheduleTable,
	MK_qmos_SyncScheduleTable,
	MK_qmos_SetScheduleTableAsync,
	MK_qmos_SimTimerAdvance,
	MK_qmos_GetCounterValue,
	MK_qmos_GetAlarm,
	MK_qmos_UpdateCounter,

/* From here, the services cannot be called directly by the user.
 * The definition of MK_N_QMOSCALLS uses MK_qmos_TerminateApplication as the reference point,
 * so if you insert more "internal" services, either put them after MK_qmos_TerminateApplication or
 * change the definition of MK_N_QMOSCALLS.
*/
	MK_qmos_TerminateApplication,
	MK_qmos_StartOs,
	MK_qmos_nQmosFuncs
};

typedef enum mk_qmosindex_e mk_qmosindex_t;

/* MK_N_QMOSCALLS is the number of directly-callable QMOS functions.
*/
#define MK_N_QMOSCALLS	((mk_parametertype_t)MK_qmos_TerminateApplication)

/* MK_N_QMOS is the total number of QMOS functions, including those that are part of the hybrid services.
*/
#define MK_N_QMOSFUNCS	(MK_qmos_nQmosFuncs)

#endif

#endif

/* Editor settings; DO NOT DELETE
 * vi:set ts=4:
*/
