#ifndef CRYPTO_RSAVERIFY_H
#define CRYPTO_RSAVERIFY_H

#include "Csm.h"

void Crypto_MainFunction(void);
Csm_ReturnType Crypto_RsaVerify(uint8 *DataStartAddrPtr, uint32 DataSize, uint8 *SignStartAddrPtr, uint32 SignSize, uint32* SignVerifyResult);
void Crypto_Hsm_RsaVerifyMainFunction(void);

#endif