/***************************************************************************/
/**
 * \copyright
 *       VISTEON CORPORATION CONFIDENTIAL
 *       ________________________________
 *       [2020] Visteon Corporation
 *       All Rights Reserved.
 *       NOTICE: This is an unpublished work of authorship, which contains trade
 *               secrets. Visteon Corporation owns all rights to this work and
 *               intends to maintain it in confidence to preserve its trade
 *               secret status. Visteon Corporation reserves the right, under
 *               the copyright laws of the United States or those of any other
 *               country that may have jurisdiction, to protect this work as an
 *               unpublished work, in the event of an inadvertent or deliberate
 *               unauthorized publication. Visteon Corporation also reserves
 *               its rights under all copyright laws to protect this work as a
 *               published work, when appropriate. Those having access to this
 *               work may not copy it, use it, modify it, or disclose the
 *               information contained in it without the written authorization
 *               of Visteon Corporation.
 *
 * \file vHsmIpcCryptoMessageM7.h
 *
 * \brief
 * Visteon HSM IPC driver header file for IPC Host Manager between cores
 *
 * \version 1.1.3
 * |Version | Date       | Author   | Task Id | Description                                |
 * |--------|------------|----------|---------|--------------------------------------------|
 * |1.00.00 | 09/Dec/'20 | KGEETHAA | xxxxxxx | Initial version                            |
 * |1.01.00 | 15/Jan/'21 | bjayara2 | 1169707 | Keys storage and fetch from work flash     |
 * |1.01.02 | 03/Feb/'21 | bjayara2 | 1214316 | Implement fail safe recovery in both cores |
 * |1.01.03 | 03/Mar/'21 | bjayara2 | 1251639 | fix -key not stored error must be shown    |
 *
 * \authors
 *          Name                     | CDSID     | Location
 *          ------------------------ | --------- | --------
 *          Akshay Krishna Upendran  | akrish10  | VTSC, Chennai, India
 *          Banumathi Jayaraman      | bjayara2  | VTSC, Chennai, India
 *          Geetha A Krishna         | kgeethaa  | VTSC, Bengaluru, India
 *          Shanmugam Karthik        | kshanmu4  | VTSC, Chennai, India
 *
 * \todo
 *
 ******************************************************************************/

#ifndef V_HSM_CRYPTO_MESSM0P_H
#define V_HSM_CRYPTO_MESSM0P_H
/******************************************************************************
 *  INCLUDES
 *****************************************************************************/
/*!
 * \defgroup   header_files Dependancy_headers
 */
/*!
 * \brief        The module shall use **Std_Types.h** data types.
 * \addtogroup  header_files
 */
#include "Std_Types.h"

/******************************************************************************
 *  MACROS
 *****************************************************************************/


/* X-Macro to create a jump table to map the message ID's to the corresponding Application Functions */
/*******************Message_ID*************************FunctionName**************/
#define CRYPTO_JOB_TABLE \
ENTRY(    CID_0,                              Crypto_Dummy_Function              )\
ENTRY(    CID_1_ASYM_EXTRACT_CB,              Crypto_Dummy_Function              )\
ENTRY(    CID_2_ASYM_EXTRACT_FINISH,          Crypto_Dummy_Function              )\
ENTRY(    CID_3_ASYM_EXTRACT_FN,              Crypto_Dummy_Function              )\
ENTRY(    CID_4_ASYM_EXTRACT_START,           Crypto_Dummy_Function              )\
ENTRY(    CID_5_ASYM_EXTRACT_UPDATE,          Crypto_Dummy_Function              )\
ENTRY(    CID_6_CHECKSUM_CB,                  Crypto_Dummy_Function              )\
ENTRY(    CID_7_CHECKSUM_FINISH,              Crypto_Dummy_Function              )\
ENTRY(    CID_8_CHECKSUM_FN,                  Crypto_Dummy_Function              )\
ENTRY(    CID_9_CHECKSUM_START,               Crypto_Dummy_Function              )\
ENTRY(    CID_10_CHECKSUM_UPDATE,             Crypto_Dummy_Function              )\
ENTRY(    CID_11_VERSION_INFO,                Crypto_Dummy_Function              )\
ENTRY(    CID_12_HASH_ALGO_ID,                Crypto_Dummy_Function              )\
ENTRY(    CID_13_HASH_CB,                     Crypto_HashCalcCallback            )\
ENTRY(    CID_14_HASH_FINISH,                 Crypto_Dummy_Function              )\
ENTRY(    CID_15_HASH_FN,                     Crypto_Dummy_Function              )\
ENTRY(    CID_16_HASH_START,                  Crypto_Dummy_Function              )\
ENTRY(    CID_17_HASH_UPDATE,                 Crypto_Dummy_Function              )\
ENTRY(    CID_18_HSM_INIT,                    Crypto_Dummy_Function              )\
ENTRY(    CID_19_MAC_GEN_CB,                  Crypto_Dummy_Function              )\
ENTRY(    CID_20_MAC_GEN_FINISH,              Crypto_Dummy_Function              )\
ENTRY(    CID_21_MAC_GEN_FN,                  Crypto_Dummy_Function              )\
ENTRY(    CID_22_MAC_GEN_START,               Crypto_Dummy_Function              )\
ENTRY(    CID_23_MAC_GEN_UPDATE,              Crypto_Dummy_Function              )\
ENTRY(    CID_24_MAC_VER_CB,                  Crypto_MacVerCallback             )\
ENTRY(    CID_25_MAC_VER_FINISH,              Crypto_Dummy_Function              )\
ENTRY(    CID_26_MAC_VER_FN,                  Crypto_Dummy_Function              )\
ENTRY(    CID_27_MAC_VER_START,               Crypto_Dummy_Function              )\
ENTRY(    CID_28_MAC_VER_UPDATE,              Crypto_Dummy_Function              )\
ENTRY(    CID_29_HSM_MAIN_FUNC,               Crypto_Dummy_Function              )\
ENTRY(    CID_30_RANDOM_CB,                   Crypto_RandomNumberGenCallback     )\
ENTRY(    CID_31_RANDOM_GEN,                  Crypto_Dummy_Function              )\
ENTRY(    CID_32_RANDOM_SEED_FINISH,          Crypto_RandomSeedCallback          )\
ENTRY(    CID_33_RANDOM_SEED_START,           Crypto_Dummy_Function              )\
ENTRY(    CID_34_RANDOM_SEED_UPDATE,          Crypto_Dummy_Function              )\
ENTRY(    CID_35_RANDOM_FN,                   Crypto_Dummy_Function              )\
ENTRY(    CID_36_SIG_VERIFY_CB,               Crypto_Dummy_Function          )\
ENTRY(    CID_37_SIG_VERIFY_FINISH,           Crypto_Dummy_Function              )\
ENTRY(    CID_38_SIG_VERIFY_FN,               Crypto_Dummy_Function              )\
ENTRY(    CID_39_SIG_VERIFY_START,            Crypto_Dummy_Function              )\
ENTRY(    CID_40_SIG_VERIFY_UPDATE,           Crypto_Dummy_Function              )\
ENTRY(    CID_41_SYM_BLOCK_DECRYPT_CB,        Crypto_ECBDecryptCallback         )\
ENTRY(    CID_42_SYM_BLOCK_DECRYPT_FINISH,    Crypto_Dummy_Function              )\
ENTRY(    CID_43_SYM_BLOCK_DECRYPT_FN,        Crypto_Dummy_Function              )\
ENTRY(    CID_44_SYM_BLOCK_DECRYPT_START,     Crypto_Dummy_Function              )\
ENTRY(    CID_45_SYM_BLOCK_DECRYPT_UPDATE,    Crypto_Dummy_Function              )\
ENTRY(    CID_46_SYM_BLOCK_ENCRYPT_CB,        Crypto_ECBEncryptCallback         )\
ENTRY(    CID_47_SYM_BLOCK_ENCRYPT_FINISH,    Crypto_Dummy_Function              )\
ENTRY(    CID_48_SYM_BLOCK_ENCRYPT_FN,        Crypto_Dummy_Function              )\
ENTRY(    CID_49_SYM_BLOCK_ENCRYPT_START,     Crypto_Dummy_Function              )\
ENTRY(    CID_50_SYM_BLOCK_ENCRYPT_UPDATE,    Crypto_Dummy_Function              )\
ENTRY(    CID_51_SYM_DECRYPT_CB,              Crypto_CBCDecryptCallback         )\
ENTRY(    CID_52_SYM_DECRYPT_FINISH,          Crypto_Dummy_Function              )\
ENTRY(    CID_53_SYM_DECRYPT_FN,              Crypto_Dummy_Function              )\
ENTRY(    CID_54_SYM_DECRYPT_START,           Crypto_Dummy_Function              )\
ENTRY(    CID_55_SYM_DECRYPT_UPDATE,          Crypto_Dummy_Function              )\
ENTRY(    CID_56_SYM_ENCRYPT_CB,              Crypto_CBCEncryptCallback         )\
ENTRY(    CID_57_SYM_ENCRYPT_FINISH,          Crypto_Dummy_Function              )\
ENTRY(    CID_58_SYM_ENCRYPT_FN,              Crypto_Dummy_Function              )\
ENTRY(    CID_59_SYM_ENCRYPT_START,           Crypto_Dummy_Function              )\
ENTRY(    CID_60_SYM_ENCRYPT_UPDATE,          Crypto_Dummy_Function              )\
ENTRY(    CID_61_SYM_EXTRACT_CB,              Crypto_KeyExtractCallback         )\
ENTRY(    CID_62_SYM_EXTRACT_FINISH,          Crypto_Dummy_Function              )\
ENTRY(    CID_63_SYM_EXTRACT_FN,              Crypto_Dummy_Function              )\
ENTRY(    CID_64_SYM_EXTRACT_START,           Crypto_Dummy_Function              )\
ENTRY(    CID_65_SYM_EXTRACT_UPDATE,          Crypto_Dummy_Function              )\
ENTRY(    CID_66_CRYPTO_JOB_CANCEL_CB,        Crypto_Dummy_Function              )\
ENTRY(    CID_67_CRYPTO_JOB_CANCEL_UPDATE,    Crypto_Dummy_Function              )\
ENTRY(    CID_68_ECDSA_VERIFY_CB,             Crypto_Dummy_Function               )\
ENTRY(    CID_69_ECDSA_VERIFY_FINISH,         Crypto_Dummy_Function              )\
ENTRY(    CID_70_ECDSA_VERIFY_FN,             Crypto_Dummy_Function              )\
ENTRY(    CID_71_ECDSA_VERIFY_START,          Crypto_Dummy_Function              )\
ENTRY(    CID_72_ECDSA_VERIFY_UPDATE,         Crypto_Dummy_Function              )\
ENTRY(    CID_73_SYM_BLOCK2_DECRYPT_CB,       vHsm_SymBlock2DecryptCallbackNotification  )\
ENTRY(    CID_74_SYM_BLOCK2_DECRYPT_FINISH,   Crypto_Dummy_Function              )\
ENTRY(    CID_75_SYM_BLOCK2_DECRYPT_FN,       Crypto_Dummy_Function              )\
ENTRY(    CID_76_SYM_BLOCK2_DECRYPT_START,    Crypto_Dummy_Function              )\
ENTRY(    CID_77_SYM_BLOCK2_DECRYPT_UPDATE,   Crypto_Dummy_Function              )\
ENTRY(    CID_78_SYM_BLOCK2_ENCRYPT_CB,       vHsm_SymBlock2EncryptCallbackNotification  )\
ENTRY(    CID_79_SYM_BLOCK2_ENCRYPT_FINISH,   Crypto_Dummy_Function              )\
ENTRY(    CID_80_SYM_BLOCK2_ENCRYPT_FN,       Crypto_Dummy_Function              )\
ENTRY(    CID_81_SYM_BLOCK2_ENCRYPT_START,    Crypto_Dummy_Function              )\
ENTRY(    CID_82_SYM_BLOCK2_ENCRYPT_UPDATE,   Crypto_Dummy_Function              )\
ENTRY(    CID_83_SYM_BLOCK2_VERIFY_CB,        vHsm_SymBlock2VerifyCallbackNotification  )\
ENTRY(    CID_84_SYM_BLOCK2_VERIFY_FINISH,    Crypto_Dummy_Function              )\
ENTRY(    CID_85_SYM_BLOCK2_VERIFY_FN,        Crypto_Dummy_Function              )\
ENTRY(    CID_86_SYM_BLOCK2_VERIFY_START,     Crypto_Dummy_Function              )\
ENTRY(    CID_87_SYM_BLOCK2_VERIFY_UPDATE,    Crypto_Dummy_Function              )\
ENTRY(    CID_88_HMAC_SHA256_CB,              vHsm_Hmac_Sha256CallbackNotification      )\
ENTRY(    CID_89_HMAC_SHA256_GEN,             Crypto_Dummy_Function              )\
ENTRY(    CID_90_HMAC_SHA256_FN,              Crypto_Dummy_Function              )\
ENTRY(    CID_91_SET_ECDSA_KEY_FN,            Crypto_Dummy_Function              )\
ENTRY(    CID_92_SET_ECDSA_KEY_CB,            Crypto_Dummy_Function              )\
ENTRY(    CID_93_SIPHASH_MACGEN_CB,           Crypto_Dummy_Function              )\
ENTRY(    CID_94_SIPHASH_MACGEN_FINISH,       Crypto_Dummy_Function              )\
ENTRY(    CID_95_SIPHASH_MACGEN_FN,           Crypto_Dummy_Function              )\
ENTRY(    CID_96_SIPHASH_MACGEN_START,        Crypto_Dummy_Function              )\
ENTRY(    CID_97_SIPHASH_MACGEN_UPDATE,       Crypto_Dummy_Function              )\
ENTRY(    CID_98_SIPHASH_MACVER_CB,           Crypto_Dummy_Function              )\
ENTRY(    CID_99_SIPHASH_MACVER_FINISH,       Crypto_Dummy_Function              )\
ENTRY(    CID_100_SIPHASH_MACVER_FN,          Crypto_Dummy_Function              )\
ENTRY(    CID_101_SIPHASH_MACVER_START,       Crypto_Dummy_Function              )\
ENTRY(    CID_102_SIPHASH_MACVER_UPDATE,      Crypto_Dummy_Function              )\
ENTRY(    CID_103_VKMS_START_CB,              Crypto_Dummy_Function              )\
ENTRY(    CID_104_VKMS_HANDLEDLC_START,       Crypto_Dummy_Function              )\
ENTRY(    CID_105_VKMS_HANDLEDLC_FINISH,      Crypto_Dummy_Function              )\
ENTRY(    CID_106_VKMS_GETVERIFICATIONHASH,   Crypto_Dummy_Function              )\
ENTRY(    CID_107_VKMS_GETIDENTITYHASH,       Crypto_Dummy_Function              )\
ENTRY(    CID_108_VKMS_GETPSSHASH,            Crypto_Dummy_Function              )\
ENTRY(    CID_109_VKMS_GETKEY_FN,             Crypto_Dummy_Function              )\
ENTRY(    CID_110_VKMS_GETMETADATA_FN,        Crypto_Dummy_Function              )\
ENTRY(    CID_111_VKMS_GETSTATUS_FN,          Crypto_Dummy_Function              )\
ENTRY(    CID_112_VKMS_GETTRAININGCOUNTER_FN, Crypto_Dummy_Function              )\
ENTRY(    CID_113_VKMS_GETVIN_FN,             Crypto_Dummy_Function              )\
ENTRY(    CID_114_VKMS_INIT_SETKEY_CB,        Crypto_Dummy_Function              )\
ENTRY(    CID_115_VKMS_INIT_SETKEY_FN,        Crypto_Dummy_Function              )\
ENTRY(    CID_116_SIPHASH_MACGEN_CB,          Crypto_Dummy_Function              )\
ENTRY(    CID_117_SIPHASH_MACGEN_FINISH,      Crypto_Dummy_Function              )\
ENTRY(    CID_118_SIPHASH_MACGEN_FN,          Crypto_Dummy_Function              )\
ENTRY(    CID_119_SIPHASH_MACGEN_START,       Crypto_Dummy_Function              )\
ENTRY(    CID_120_SIPHASH_MACGEN_UPDATE,      Crypto_Dummy_Function              )\
ENTRY(    CID_121_JTAG_SETPASSWORD_CB,        Crypto_Hsm_SecureDebugCallback     )\
ENTRY(    CID_122_JTAG_SETPASSWORD_GEN,       Crypto_Dummy_Function              )\
ENTRY(    CID_123_JTAG_CHECKPASSWORD_GEN,     Crypto_Dummy_Function              )\
ENTRY(    CID_124_JTAG_LC_SECUREDEBUG_FN,     Crypto_Dummy_Function              )\
ENTRY(    CID_125_KEYMAN_KEYERASE_CB,         Crypto_Dummy_Function              )\
ENTRY(    CID_126_KEYMAN_KEYERASE_FN,         Crypto_Dummy_Function              )\
ENTRY(    CID_127_ED25519VER_CB,              Crypto_Dummy_Function              )\
ENTRY(    CID_128_ED25519VER_FN,              Crypto_Dummy_Function              )\
ENTRY(    CID_129_ED25519SID_GN,              Crypto_Dummy_Function              )

/* X-Macro to create a jump table to map the message ID's to the corresponding Application Functions */
/*******************Message_ID*************************FunctionName**************/
#define COMMAND_JOB_TABLE \
ENTRY(    SID_0,                              Command_Dummy_Function        )\
ENTRY(    SID_1_HARD_RESET_CMD,               Command_Dummy_Function        )\
ENTRY(    SID_2_REFLASH_CMD_START,            Command_Dummy_Function        )\
ENTRY(    SID_3_REFLASH_CMD_UPDATE,           Command_Dummy_Function        )\
ENTRY(    SID_4_REFLASH_CMD_FINISH,           Command_Dummy_Function        )\
ENTRY(    SID_5_REFLASH_CMD_ERASE,            Command_Dummy_Function        )\
ENTRY(    SID_6_REFLASH_CALLBACK,             vHsmReflashCallback           )\
ENTRY(    SID_7_REFLASH_CRC_CALC_FN,          Command_Dummy_Function        )\
ENTRY(    SID_8_REFLASH_CRC_CALLBACK,         vHsmReflashCrcCallback        )\
ENTRY(    SID_9_REFLASH_FAILED_INFO,          Command_Dummy_Function        )\
ENTRY(    SID_10_REFLASH_GET_KEY,             Command_Dummy_Function        )\
ENTRY(    SID_11_REFLASH_GET_KEY_CBK,         vHsmReflashKeyCallback        )\
ENTRY(    SID_12_HSM_VERSION_INFO_FN,         Command_Dummy_Function        )\
ENTRY(    SID_13_HSM_VERSION_INFO_CALLBACK,   vHsmVersionInfoCallback       )\
ENTRY(    SID_14_HSM_NVM_SET,                 Command_Dummy_Function        )\
ENTRY(    SID_15_HSM_NVM_CLEAR,               Command_Dummy_Function        )\
ENTRY(    SID_16_HSM_NVM_READ,                Command_Dummy_Function        )\
ENTRY(    SID_17_HSM_NVM_STORE_CBK,           vHsm_Nvm_Store_Callback       )\
ENTRY(    SID_18_HSM_WORKFLASH_WRITE_FN,      Command_Dummy_Function        )\
ENTRY(    SID_19_HSM_WORKFLASH_WRITE_CBK,     vHsm_WriteData_Callback       )
/******************************************************************************
 * Exported type declarations
 *****************************************************************************/
#define ENTRY(a,b)             a,
typedef enum
{
    CRYPTO_JOB_TABLE
    CRYPTO_UNUSED_JOBID
}te_cryptojobid;
#undef ENTRY

#define ENTRY(a,b)             a,
typedef enum
{
    COMMAND_JOB_TABLE
    COMMAND_UNUSED_JOBID
}te_commandid;
#undef ENTRY

typedef enum
{
    CRYPTO_JOB_DONE = 0,
    CRYPTO_JOB_NOT_DONE,
    CRYPTO_JOB_KEY_NOT_THERE
}te_cryptojobresult;

/* Priority id for the crypto job */
typedef enum
{
    e_priority0 = 0,
    e_priorityunused = 0xFF,
} te_jobpriority;

/* Crypto Job for cancellation */
typedef enum
{
    e_aescbcencrypt = 0,
    e_aescbcdecrypt,
    e_aesecbencrypt,
    e_aesecbdecrypt,
    e_aescmaccommon,
    e_hashsha256,
    e_allcancel,
    e_canceljobunused = 0xFF,
} te_canceljobid;

typedef struct
{
    uint16         payLoadSize;
    uint8 *        payLoadPtr_U8P;
    te_cryptojobid jobId_E;
    te_jobpriority priority_U8;
    uint8          KeyId_U8;
} ts_vHsm_Cryptodata;

typedef struct
{
    uint16         payLoadSize;
    uint8          priority_U8;
    uint8 *        payLoadPtr_U8P;
    te_commandid   jobId_E;
} ts_vHsm_Commanddata;

typedef enum
{
    BANK_MANAGEMENT,
    SFI_UPDATE,
    QNX_UPDATE,
}te_Management_Appl;

typedef enum
{
    TARGET_ID,
    TARGET_STATE,   
    UPDATE_CDD_STATE,
    REMAINING_SIZE,
    LAST_ADDR,
}te_Entries_Appl;
/******************************************************************************
 *  PUBLIC FUNCTION DECLARATIONS
 *****************************************************************************/

#endif /* V_HSM_CRYPTO_MESSM0P_H */
/* EOF */
