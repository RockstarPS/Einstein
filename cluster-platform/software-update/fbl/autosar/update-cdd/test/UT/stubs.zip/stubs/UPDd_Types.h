/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

# ifndef UPDd_Types_H
# define UPDd_Types_H

//=====================================================================================================================
//  CONSTANTS & TYPES
//=====================================================================================================================

//#define UPDd_POINTER_TEST_DISABLED
#define cUPDdPostIntallationVerificationType eUPDiHash_Crc32 // Define the verfication method used after the installation

// typedef struct sUPDdManifest
// {
//     uint32 GoldenCrc; // Define the expected value of the CRC32, CRC ploynomial is Polynomial 0x04C11DB7h
//     uint8  GoldenSha256[32];
//     uint8  VersionMajor;
//     uint8  VersionMinor;
// } tUPDdManifest;

#endif /*UPDd_Types_H*/
