#ifndef PLATFORMS_TSPLATFORMS_H
#define PLATFORMS_TSPLATFORMS_H
/**
 * \file
 *
 * \brief AUTOSAR Platforms
 *
 * This file contains the implementation of the AUTOSAR
 * module Platforms.
 *
 * \version 4.0.1
 *
 * \author Elektrobit Automotive GmbH, 91058 Erlangen, Germany
 *
 * Copyright 2005 - 2023 Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
 */

/*==================[inclusions]=============================================*/

/*==================[type definitions]=======================================*/

/*==================[macros]=================================================*/

/** \brief definition of derivate names for this architecture */

  
#define TS_TMS570LS20216   1U
#define TS_TMS570LS30336   2U
#define TS_STA8088EX       3U
#define TS_FCR4MB9E        4U
#define TS_TX03            5U
#define TS_IMX6Q           6U
#define TS_TMS570LC4357    7U
#define TS_FCR4MB9D        9U
#define TS_AM35x           10U
#define TS_IMX6SLX         11U
#define TS_MAC57DXXX       12U
#define TS_MAC58RXXX       13U
#define TS_TMS570LS1113    14U
#define TS_TMS570LC4355    16U
#define TS_S32V234AA32     17U
#define TS_STA8090         18U
#define TS_S6J3200         19U
#define TS_ZYNQ7010        20U
#define TS_RCARH3CR7       21U
#define TS_TMS570LS1227    22U
#define TS_RCARV3MCR7      26U
#define TS_AR1642          27U
#define TS_RCARM3CR7       28U
#define TS_S32SDP2XX       29U
#define TS_TMS570LS1114    30U
#define TS_S32S247         31U
#define TS_BCM89531        32U
#define TS_BCM89230        38U
#define TS_ZUXEVCR5        39U
#define TS_G2020           40U
#define TS_RCARV3HCR7      41U
#define TS_S6J3400         42U
#define TS_S6J3300         43U
#define TS_RCARM3NCR7      44U
#define TS_QEMUA9          45U
#define TS_TDA4VMCR5       46U
#define TS_SR6P7C8         47U
#define TS_AWR6843         48U
#define TS_SR6P7           49U
#define TS_SR6G7           50U
#define TS_MV88Q515X       51U
#define TS_S32E27X         52U
#define TS_S32Z27X         53U
#define TS_S32S27X         54U
#define TS_G9XCR5          55U
#define TS_RCARS4CR52      56U
#define TS_EXYNOSAV9       57U
#define TS_SR6P6           58U
#define TS_SR6P3           59U
#define TS_SR6G5           60U
#define TS_SR6G3           61U
#define TS_S32N2RTCR52     62U
#define TS_AM2634          63U

                     

#endif /* ifndef PLATFORMS_TSPLATFORMS_H */

