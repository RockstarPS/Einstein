/* Os_CORTEXM_timer_cy_pwm_config.h - configuration of Cypress Traveo II PWM timer
*
* Copyright Elektrobit Automotive GmbH
* All rights exclusively reserved for Elektrobit Automotive GmbH,
* unless expressly agreed to otherwise.
*/
#ifndef OS_CORTEXM_TIMER_CY_PWM_CONFIG_H
#define OS_CORTEXM_TIMER_CY_PWM_CONFIG_H

#define OS_TicksToNs_TCPWM0_2_00(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM0_2_00(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM0_2_01(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM0_2_01(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM0_2_02(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM0_2_02(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM0_2_03(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM0_2_03(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM0_2_04(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM0_2_04(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM0_2_05(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM0_2_05(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM0_2_06(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM0_2_06(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM0_2_07(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM0_2_07(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_12(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_12(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_11(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_11(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_10(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_10(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_09(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_09(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_08(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_08(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_07(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_07(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_06(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_06(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_05(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_05(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_04(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_04(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_03(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_03(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_02(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_02(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_01(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_01(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#define OS_TicksToNs_TCPWM1_2_00(tk)	 OS_BoardCYPWM_TicksToNs(tk)
#define OS_NsToTicks_TCPWM1_2_00(ns)	 OS_BoardCYPWM_NsToTicks(ns)

#endif
/* Editor settings - DO NOT DELETE
* vi:set ts=4:
*/
