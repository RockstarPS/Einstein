#ifndef FBL_MEMDRV_IF_H
#define FBL_MEMDRV_IF_H

/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

/*****************************************************************************

File Name        :  fbl_memdrv_if.h
Author           :  sananth2
Description      :  Flash driver codes used by UpdateCdd Ioadapters
Organization     :  Driver Information Software Section,
                    Visteon Corporation
----------------------------------------------------------------------------
Compiler Name    :  All
Target Processor :  All
******************************************************************************/

typedef enum
{
    FBL_TARGET_ID,
    FBL_TARGET_STATE,   
    FBL_UPDATE_CDD_STATE,
    FBL_REMAINING_SIZE,
    FBL_LAST_ADDR,
}WorkFlashWrite_Entries;


extern uint8 FblFlashDrv_Write(uint32 addr, uint32 *pLen,  const uint8 *pBuffer);
extern uint8 FblFlashDrv_Erase(uint32 addr, uint32 len);
extern uint8 FblHsmFlashGetResp_erase(void);
extern uint8 FblHsmFlashDrv_Write(uint32 addr, uint32 *pLen,  const uint8 *pBuffer);
extern uint8 FblHsmFlashGetResp_write(void);
//extern uint8  FblHsmFlashDrv_Init(uint8 param);
extern uint8  FblHsmFlashDrv_Erase(void);
extern void FblHsmFlashPeriodic(void);
extern Std_ReturnType Fbl_CheckBankMode(void);
extern Std_ReturnType Fbl_SetBankMode(void);
extern Std_ReturnType Fbl_FotaBankSwitching(boolean isRollBackRequest);
extern void vHsmBankSwitchCallback(boolean sts,uint8 value);

extern void FblHsmFlashDrv_Init(void); //for UT

#endif
