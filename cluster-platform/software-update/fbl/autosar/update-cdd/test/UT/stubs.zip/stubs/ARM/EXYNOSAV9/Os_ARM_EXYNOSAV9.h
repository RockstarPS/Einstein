/* Os_ARM_EXYNOSAV9.h - Description of Samsung Exynos Auto V9 ARM Cortex-R52
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
 */

#ifndef OS_ARM_EXYNOSAV9_H
#define OS_ARM_EXYNOSAV9_H

/*
 * EXYNOSAV9 has the following ARM related features:
 */
#define OS_ARM_INT_CTRL					OS_ARM_INT_GICV3
#define OS_ARM_INT_VECTORIZATION		OS_ARM_INT_SOFTWARE_VECTOR
#define OS_ARM_FPU						OS_ARM_FPU_VFPV3_D32

/* EXYNOSAV9 features related the generic part of the kernel:
 *
 * OS_STACKGROWS:	either OS_STACKGROWSDOWN or OS_STACKGROWSUP as necessary
 * OS_STACKFILL:	0xebe..b, enough to fill an os_stackelement_t with bytes of 0xeb
 * OS_HWT_POWEROF2:	1 if all supported hardware timers wrap cleanly on the (2**n)th tick, 0 otherwise.
 */
#define OS_STACKGROWS					OS_STACKGROWSDOWN
#define OS_STACKFILL					OS_U(0xebebebeb)
#define OS_HWT_POWEROF2					1
#define OS_USE_MMU						0
#define OS_USE_MPU						1

/* EXYNOSAV9 supports any ARM instructions. */
#define OS_ARM_ENCODING					OS_ARM_ENCODING_ARM

/* Use level for locking instead of interrupt flag
 * (otherwise the current implementation of cross-core interrupts won't work).
 */
#define OS_USE_LEVEL_FOR_LOCKING		1

#define OS_HAS_ICACHE					1
#define OS_HAS_DCACHE					1
/* Following cache settings are only relevant for cross-core communication.
 * Use arbitrary values.
 */
#define OS_CACHE_MODE					OS_CACHE_MODE_NONE
#define OS_CACHE_LINE_LEN				OS_U(64)

/* TCMs are not cached, so they could be excluded here, but it's not absolutely
 * necessary. Moreover, this is a single core derivative and these settings
 * are not relevant.
 */
#define OS_ArchAddressIsCacheable(base)	OS_U(1)

/* Settings for the MPU. */
#define OS_MPU_NUM_REGIONS				OS_U(24)

/* Number of interrupt sources. */
#define OS_ARM_INT_NUM_SOURCES			OS_U(512)

/* For compatibility with older versions (< 3.0) of the GIC
 * (support for cascaded GICs).
 * GICv3 currently supports a different kind of multiple GICs:
 * several parallel instances of GICs, one for each cluster of cores.
 */
#define OS_ARM_INT_N_GIC				OS_U(1)

/* Base address for interrupt distributor (ICD). */
#define OS_ARM_INT_ICD_BASE_CORE0		OS_U(0xEFA00000)

/* Base addresses for redistributors. */
#define OS_ARM_GIC_ISR_CONTROL_CORE0	(OS_ARM_INT_ICD_BASE_CORE0 + OS_U(0x100000))
#define OS_ARM_GIC_ISR_SGIPPI_CORE0		(OS_ARM_INT_ICD_BASE_CORE0 + OS_U(0x110000))

/* Multicore Timer Module (MCT). */
#define OS_ARM_MCTG_NCOMP				OS_U(4)
#define OS_ARM_MCTL_NCHANNEL			OS_U(8)
/* Address taken from TRM: Section 19.4.1 and mapped from Table 48-1 Memory Map (SFI_SFR) */
#define OS_ARM_MCT_BASE_ADDR			OS_U(0xFD2B0000)

/* If we need a CPU related initialization this can be done by refining the
 * OS_ARM_CpuInitArch macro. For EXYNOSAV9 we initialize the interrupt controller
 * and the floating point unit.
 */
#define OS_ARM_CpuInitArch()			\
	do {								\
		OS_ARM_IntInit();				\
		OS_ARM_SetupVFPCoprocessor();	\
	} while(0)

/* Maximum number of available cores. */
#define OS_N_CORES_MAX					OS_U(1)

/* How to generate a "physical" core ID from MPIDR.
 * This is a single-core derivative, so always return 0.
 */
#define OS_ARM_MPIDR2COREID(x)			OS_U(0)

#endif /* OS_ARM_EXYNOSAV9_H */

/* Editor settings: DO NOT DELETE
 * vi: set ts=4:
 */
