/* Os_atomics_tsplatforms_ARM.h
 *
 * This file contains redirections to other header files based on the
 * characteristics of the current derivative to implement legacy atomic
 * functions.
 *
 * CHECK: TABS 4 (see editor commands at end of file)
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
*/
#ifndef OS_ATOMICS_TSPLATFORMS_ARM_H
#define OS_ATOMICS_TSPLATFORMS_ARM_H

#include <Os_cpu.h>

#if (OS_HAS_ARCHSPINLOCK == 1)
#include <Os_atomics_tsplatforms_generic_bits_reservations.h>
#elif (OS_ARM_HAS_SEMA4 == 1)
#include <Os_atomics_tsplatforms_generic_bits_hwlock.h>
#else
#error "Underlying mechanism to implement legacy atomic functions unspecified."
#endif

#include <Os_atomics_tsplatforms_generic_intlocks.h>

#endif /* OS_ATOMICS_TSPLATFORMS_ARM_H */
