/* Mk_ARM_exceptioninfo.h - header file for publicized ARM exception information
 *
 * This file contains declarations referring to exception handling on ARM based
 * CPUs.
 *
 * (c) Elektrobit Automotive GmbH
*/
#ifndef MK_ARM_EXCEPTIONINFO_H
#define MK_ARM_EXCEPTIONINFO_H

#include <public/Mk_basic_types.h>
#include <public/Mk_public_types.h>

#ifndef MK_ASM
/* mk_exceptiontype_t enumerates all the different exceptions on the ARM
 * Architecture processor family.
 * Reset is not listed, since it cannot be handled.
 * SVC is solely handled by the microkernel.
 * IRQ / FIQ are treated as interrupts, but they get an id anyway for panic reporting.
*/
enum mk_exceptiontype_e
{
	MK_ex_UndefinedInstruction	= 1,
	MK_ex_PrefetchAbort			= 2,
	MK_ex_DataAbort				= 3,
	MK_ex_Svc					= 4,
	MK_ex_Irq					= 5,
	MK_ex_Fiq					= 6,
	MK_ex_UnknownException		= 7
};

typedef enum mk_exceptiontype_e mk_exceptiontype_t;

/* Exception info structure
 *
 * Apart from 'type', the fields in the structure are named after the
 * registers whose values are stored there.
*/
typedef struct mk_exceptioninfo_s mk_hwexceptioninfo_t;
#define MK_EXCEPTIONINFO_N_GPRS	13
struct mk_exceptioninfo_s
{
	mk_uint32_t pc;				/* program counter at which the exception occurred */
	mk_uint32_t cpsr;			/* CPSR */

	mk_uint32_t dfar;			/* data fault address register */
	mk_uint32_t dfsr;			/* data fault status register */
	mk_uint32_t ifar;			/* instruction fault address register */
	mk_uint32_t ifsr;			/* instruction fault status register */
	mk_exceptiontype_t type;	/* Exception type */

	mk_uint32_t fpscr;			/* floating point status and control register */
	mk_uint32_t fpexc;			/* floating point exception register */

	mk_uint32_t gpr[MK_EXCEPTIONINFO_N_GPRS];	/* general purpose registers */
};

#endif

#endif
/* Editor settings; DO NOT DELETE
 * vi:set ts=4:
*/
