/**********************************************************************************************************************
 *  COPYRIGHT
 *  -------------------------------------------------------------------------------------------------------------------
 *  \verbatim
 *
 *                This software is copyright protected and proprietary to Vector Informatik GmbH.
 *                Vector Informatik GmbH grants to you only those rights as set out in the license conditions.
 *                All other rights remain with Vector Informatik GmbH.
 *  \endverbatim
 *  -------------------------------------------------------------------------------------------------------------------
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  Rte_CBacklightCdd.h
 *           Config:  Toyota_38xd.dpa
 *      ECU-Project:  Toyota_38xd
 *
 *        Generator:  MICROSAR RTE Generator Version 4.29.0
 *                    RTE Core Version 1.29.0
 *          License:  CBD2200498
 *
 *      Description:  Application header file for SW-C <CBacklightCdd>
 *********************************************************************************************************************/

/* double include prevention */
#ifndef RTE_CUPDATECDD_H
# define RTE_CUPDATECDD_H

# ifndef RTE_CORE
#  ifdef RTE_APPLICATION_HEADER_FILE
#   error Multiple application header files included.
#  endif
#  define RTE_APPLICATION_HEADER_FILE
#  ifndef RTE_PTR2ARRAYBASETYPE_PASSING
#   define RTE_PTR2ARRAYBASETYPE_PASSING
#  endif
# endif

# ifdef __cplusplus
extern "C"
{
# endif /* __cplusplus */

/* include files */

# include "Rte_CUpdateCdd_Type.h"
# include "Rte_DataHandleType.h"
# include "fbl_memdrv_if.h"
//# include "Stubs.h"
//#include "cy_mw_flash.h"

#include "Os_api.h"

/**********************************************************************************************************************
 * Runnable entities
 *********************************************************************************************************************/
# ifndef RTE_CORE

    #  define RTE_RUNNABLE_CUPD_UpdateCdd_Impl_MainFunction CUPD_UpdateCdd_Impl_MainFunction
    #  define RTE_RUNNABLE_CUPD_UpdateCdd_Impl_OnCommand CUPD_UpdateCdd_Impl_OnCommand
    #  define RTE_RUNNABLE_UpdateCdd_GenericRequestTransferExit UpdateCdd_GenericRequestTransferExit
    #  define RTE_RUNNABLE_UpdateCdd_GenericTransferDataHandler UpdateCdd_GenericTransferDataHandler
    #  define RTE_RUNNABLE_UpdateCdd_GenericRequestDownloadHandler UpdateCdd_GenericRequestDownloadHandler
    #  define RTE_RUNNABLE_UpdateCdd_GenericRequestEraseHandler UpdateCdd_GenericRequestEraseHandler
    #  define RTE_RUNNABLE_UPD_Task UPD_Task
    




# endif /* !defined(RTE_CORE) */

Std_ReturnType UPD_Task(void);
void CUPD_UpdateCdd_Impl_MainFunction(void); /* PRQA S 0850, 3451 */ /* MD_MSR_19.8, MD_Rte_3451 */
Std_ReturnType CUPD_UpdateCdd_Impl_OnCommand(ECmpCmd cmdP); /* PRQA S 0850 */ /* MD_MSR_19.8 */

Std_ReturnType UpdateCdd_GenericRequestTransferExit(void);
Std_ReturnType UpdateCdd_GenericTransferDataHandler(void);
Std_ReturnType UpdateCdd_GenericRequestDownloadHandler(void);


extern uint8 FblFlashDrv_Write(uint32 addr, uint32 *pLen,  const uint8 *pBuffer);
extern uint8 FblFlashDrv_Erase(uint32 addr, uint32 len);
extern uint8 FblHsmFlashDrv_Write(uint32 addr, uint32 *pLen,  const uint8 *pBuffer);
extern uint8 FblHsmFlashDrv_Erase(void);
extern uint8 FblHsmFlashGetResp_write(void);
extern uint8 FblHsmFlashGetResp_erase(void);
//extern void FblHsmFlashPeriodic(void);
//extern uint8 FblHsmFlashDrv_Init(uint8 param);
extern uint8 FblHsmFlashDrv_DeInit(uint8 param);
extern uint8 FblHsmFlashDrv_Read(uint32 addr,  uint32 *pLen, uint8 *pBuffer);

extern void FblHsmFlashDrv_Init(void); //for UT




# ifndef RTE_CORE
/**********************************************************************************************************************
 * Application errors
 *********************************************************************************************************************/

#  define RTE_E_TI_Backlight_NotifyDispaly_E_NOT_OK (1U)

#  define RTE_E_TI_Backlight_Service_E_NOT_OK (1U)

#  define RTE_E_TI_Backlight_Status_E_NOT_OK (1U)

#  define RTE_E_TI_IOHWAB_GetDIn_E_NOT_OK (1U)

#  define RTE_E_TI_IOHWAB_PWM_E_NOT_OK (1U)

#  define RTE_E_TI_IOHWAB_SetDout_E_NOT_OK (1U)

#  define RTE_E_if_CS_ModeOnCommand_E_NOT_OK (1U)
# endif /* !defined(RTE_CORE) */

# ifdef __cplusplus
} /* extern "C" */
# endif /* __cplusplus */

#endif /* RTE_CBACKLIGHTCDD_H */

/**********************************************************************************************************************
 MISRA 2012 violations and justifications
 *********************************************************************************************************************/

/* module specific MISRA deviations:
   MD_Rte_0624:  MISRA rule: Rule8.3
     Reason:     This MISRA violation is a consequence from the RTE requirements [SWS_Rte_01007] [SWS_Rte_01150].
                 The typedefs are never used in the same context.
     Risk:       No functional risk. Only a cast to uint8* is performed.
     Prevention: Not required.

   MD_Rte_0786:  MISRA rule: Rule5.5
     Reason:     Same macro and idintifier names in first 63 characters are required to meet AUTOSAR spec.
     Risk:       No functional risk.
     Prevention: Not required.

   MD_Rte_3449:  MISRA rule: Rule8.5
     Reason:     Schedulable entities are declared by the RTE and also by the BSW modules.
     Risk:       No functional risk.
     Prevention: Not required.

   MD_Rte_3451:  MISRA rule: Rule8.5
     Reason:     Schedulable entities are declared by the RTE and also by the BSW modules.
     Risk:       No functional risk.
     Prevention: Not required.

*/
