/*****************************************************************************
*                                                                            *
*              CONFIDENTIAL VISTEON CORPORATION                              *
*                                                                            *
* This is an unpublished work of authorship, which contains trade            *
* secrets, created in 2023. Visteon Corporation owns all rights to           *
* this work and intends to maintain it in confidence to preserve             *
* its trade secret status. Visteon Corporation reserves the right,           *
* under the copyright laws of the United States or those of any              *
* other country that may have jurisdiction, to protect this work             *
* as an unpublished work, in the event of an inadvertent or                  *
* deliberate unauthorized publication. Visteon Corporation also              *
* reserves its rights under all copyright laws to protect this               *
* work as a published work, when appropriate. Those having access            *
* to this work may not copy it, use it, modify it or disclose the            *
* information contained in it without the written authorization              *
* of Visteon Corporation.                                                    *
*                                                                            *
******************************************************************************/

# ifndef UPD_SYNCCDD_H
# define UPD_SYNCCDD_H

# include "UPDi.h"

#if 0
# if (STD_ON == UPD_CFLS_IOADAPTER)
# include "CFls.h"
# include "CFls_TypesLib.h"

// typedef enum
// {
//     eUPDiIoCFls_Write,
//     eUPDiIoCFls_Erase,
//     eUPDiIoCFls_Init,
//     eUPDiIoCFls_NoOrder
// } tUPDiIoCFlsType;

//=====================================================================================================================
/*Functions*/
Std_ReturnType UPDCFlsIoAdapter_ProcessRequest(uint32 Destn_addrs, uint32 Source_addrs, uint32 BinSize, uint32 Chunk, tUPDiIoReqType ReqType);
//=====================================================================================================================

//=====================================================================================================================
/*external variable Vtbl and extern functions*/
// extern tUPDiIoAdapterVtbl UPDCFlsIoAdapterVtbl;
extern CFls_OperationStatusType CFls_Init(void);
//=====================================================================================================================

# endif /* UPD_CFLS_IOADAPTER */
# endif /* UPD_CFlsIoAdapter_H  */
#endif
