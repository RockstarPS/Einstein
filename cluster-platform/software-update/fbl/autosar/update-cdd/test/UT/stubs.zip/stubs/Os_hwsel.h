/* Os_hwsel.h
 *
 * This file provides characteristics of the current derivative's cpu.
 * It includes the target specific Os_*_cpu.h file.
*/
#ifndef OS_HWSEL_H
#define OS_HWSEL_H

/* Architecture specific defines */
#define OS_HWSEL_ATOMICS    <ARM/Os_atomics_ARM.h>
#define OS_HWSEL_API        <ARM/Os_api_ARM.h>
#define OS_HWSEL_CPU        <ARM/Os_ARM_cpu.h>
#define OS_HWSEL_DEFS       <ARM/Os_defs_ARM.h>
#define OS_HWSEL_KERNEL     <ARM/Os_kernel_ARM.h>
#define OS_HWSEL_MMU        <ARM/Os_mmu_ARM.h>
#define OS_HWSEL_PROTO      <ARM/Os_proto_ARM.h>
#define OS_HWSEL_TOOL       <ARM/Os_tool_ARM.h>
#define OS_HWSEL_TYPES      <ARM/Os_types_ARM.h>
#define OS_HWSEL_ERRORCODES <ARM/Os_errorcodes_ARM.h>

#endif
/* Editor settings - DO NOT DELETE
 * vi:set ts=4:
*/
