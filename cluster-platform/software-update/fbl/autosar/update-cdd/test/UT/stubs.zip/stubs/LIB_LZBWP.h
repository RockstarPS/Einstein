//==============================================================================
//  Project ......................... <PROJECT>
//  Component ....................... LIB_LZBW
//  File revision.................... 
//  Last modification date .......... 
//  -------------------------------------------------------------------------
//  Copyright ... This software is JCI property. Duplication or
//                disclosure is prohibited without JCI written permission
//  ------------------------------------------------------------------------- 
//
//  - Macros, constants and types which are not exported are defined in 
//    this file
//  - Variables and functions which are not exported are defined in this 
//    file with the static key word
//  
//  -------------------------------------------------------------------------
//  Comments about the component (role, algorithm, structure, limitations,
//           defined tasks and events...)
//  - Role :
//  
//  -------------------------------------------------------------------------
//  LIB_LZBWp.h file review : 
//
//
//==============================================================================

#ifndef I_LIB_LZBWP_H
#define I_LIB_LZBWP_H (1)

//-------------------------------------------------------------------------
//  Included files to resolve specific definitions in this file
//
//  #include <system_file_name.h>
//  #include "project_file_name.h"
//-------------------------------------------------------------------------

// #define LIBEcl_Used
// #define LIB_LZBW_JCI_Used
#define LIB_LZBW_JCI2_Used

#ifdef LIB_LZBW_JCI2_Used
// Enable define if you need compression methods
// #define LIB_LZBW_JCI2_Compression_Used

// Enable define if you need backward compatibility of interfaces between two JCI decompression implementations
#define LIB_LZBW_JCI2_Backward_Compatibility

#ifdef LIB_LZBW_JCI2_Backward_Compatibility
#define LIB_LZBW_JCI_Used
#endif
#endif

//-------------------------------------------------------------------------
//  Constant data
//
//  #define cCMPConstantName   ((tType) ConstantValue)
//-------------------------------------------------------------------------
#if defined(LIB_LZBW_JCI_Used) || defined(LIB_LZBW_JCI2_Used)
#define LIB_LZBW_MAX_UNCODED        2

#define LIB_LZBW_CODE_BITS          16

// Variable compression
#define LIB_LZBW_MAXLENGTH_SIZE     7 // 8 for Dictionary size 256
#define LIB_LZBW_MINLENGTH_SIZE     7 // 3 for Dictionary size 8192
#define LIB_LZBW_MAXOFFSET_SIZE     (LIB_LZBW_CODE_BITS - LIB_LZBW_MINLENGTH_SIZE)
#define LIB_LZBW_MAXDICTIONARY_SIZE (1 << LIB_LZBW_MAXOFFSET_SIZE)

#if (LIB_LZBW_MAXLENGTH_SIZE == LIB_LZBW_MINLENGTH_SIZE)
#define LIB_LZBW_LENGTH_SIZE        LIB_LZBW_MAXLENGTH_SIZE
#define LIB_LZBW_OFFSET_SIZE        LIB_LZBW_MAXOFFSET_SIZE
#define LIB_LZBW_DICTIONARY_SIZE    LIB_LZBW_MAXDICTIONARY_SIZE
#else
#define LIB_LZBW_LENGTH_SIZE        7
#define LIB_LZBW_OFFSET_SIZE        (16 - LIB_LZBW_LENGTH_SIZE)
#define LIB_LZBW_DICTIONARY_SIZE    (1 << LIB_LZBW_OFFSET_SIZE)
#endif

#define LIB_LZBW_TOS_SCHEDULE_LOOP_COUNT    4
#endif

//-------------------------------------------------------------------------
//  Exported Macro
//
//  #define mCMPMacroName   (MacroDefinition)
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//  Exported type
//
//  struct  sCMPStructureName { ... };
//  union   uCMPUnionName { ... };
//  enum    eCMPEnumerationName { ... };
//  typedef Expression tCMPTypeName;
//
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
//  Exported data
//
//  extern  tType   CMPVariableName;
//  extern  tType*  pCMPVariableName; 
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
//  Constant exported data
//
//  extern const tType  CMPVariableName;
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
//  Exported functions
//
//  extern tReturnType CMPFunctionName(tTypeArgument1 ArgumentName1, ... );
//------------------------------------------------------------------------- 

//-------------------------------------------------------------------------
//  End of includes non re entry
//-------------------------------------------------------------------------
#endif /* I_LIB_LZBWP_H */
