#ifndef CSM_H
#define CSM_H

typedef uint8 Csm_ReturnType;

typedef uint32 Csm_AlignType;

typedef struct Csm_SymKeyT
{
    uint32 length;
    Csm_AlignType data;
}Csm_SymKeyType;

Csm_ReturnType Crypto_She_SymDecrypt(uint8* priority, Csm_SymKeyType* key, uint8* buffer, uint32 bufferSize, uint8* cypher, uint32 cypherSize, uint8* plain, uint32* plainSize);

Csm_ReturnType Crypto_She_SymDecryptMainFunction(void);

Csm_ReturnType vHsmIpc_HostManager_PeriodicCheck(void);

Csm_ReturnType CySldIpc_Isr_IpcDrv_Cat2(void);

#endif