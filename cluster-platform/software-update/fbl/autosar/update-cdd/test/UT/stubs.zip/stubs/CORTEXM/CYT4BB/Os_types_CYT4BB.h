/* Os_types_CYT4BB.h
 *
 * This file defines the basic data types for CYT4BB CPU.
 *
 * Copyright Elektrobit Automotive GmbH
 * All rights exclusively reserved for Elektrobit Automotive GmbH,
 * unless expressly agreed to otherwise.
*/
#ifndef OS_TYPES_CYT4BB_H
#define OS_TYPES_CYT4BB_H

#ifdef __cplusplus
extern "C" {
#endif

/* CYT3DL data type characteristics:
 *
 * - OS_ENDIAN:			either OS_LITTLEENDIAN or OS_BIGENDIAN, as necessary.
 * - OS_ARCH_HAS_64BIT:	0 (64 bit data type not supported) or 1 (64 bit data type supported).
*/
#define OS_ENDIAN				OS_LITTLEENDIAN
#define OS_ARCH_HAS_64BIT		0

/* This derivative has no internal timestamp timer. */
#define OS_HAS_TB_INTERNAL		0

#ifdef __cplusplus
}
#endif

#endif

/* Editor settings - DO NOT DELETE
 * vi:set ts=4:
*/
