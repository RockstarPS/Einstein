/* Mk_syscallindex.h
 *
 * This file defines the system call indexes used by the kernel.
 *
 * (c) Elektrobit Automotive GmbH
*/
#ifndef MK_SYSCALLINDEX_H
#define MK_SYSCALLINDEX_H

/* Microkernel system call indexes. These indexes MUST match the positions of the corresponding
 * functions in the system call table.
 * We need these indexes in assembly-language so they must be #defines
 *
 * The first batch contains the indexes for microkernel services.
*/
/*		1234567890123456789012345678901	*/	/* Kernel-side function */
#define MK_SC_TerminateSelf				0	/* MK_SysTerminateSelf */
#define MK_SC_ActivateTask				1	/* MK_SysActivateTask */
#define MK_SC_ChainTask					2	/* MK_SysChainTask */
#define MK_SC_Schedule					3	/* MK_SysSchedule */
#define MK_SC_AcquireLock				4	/* MK_SysAcquireLock */
#define MK_SC_ReleaseLock				5	/* MK_SysReleaseLock */
#define MK_SC_Shutdown					6	/* MK_SysShutdown */
#define MK_SC_StartOs					7	/* MK_SysStartOs */
#define MK_SC_SetEvent					8	/* MK_SysSetEvent */
#define MK_SC_ClearEvent				9	/* MK_SysClearEvent */
#define MK_SC_WaitEvent					10	/* MK_SysWaitEvent */
#define MK_SC_WaitGetClearEvent			11	/* MK_SysWaitEvent (alias) */
#define MK_SC_GetTaskId					12	/* MK_SysGetTaskId */
#define MK_SC_GetTaskState				13	/* MK_SysGetTaskState */
#define MK_SC_GetIsrId					14	/* MK_SysGetIsrId */
#define MK_SC_ReportError				15	/* MK_SysReportError */
#define MK_SC_CallQmOs					16	/* MK_SysCallQmOs */
#define MK_SC_CallTrustedFunction		17	/* MK_SysCallTrustedFunction */
#define MK_SC_AllowAccess				18	/* MK_SysAllowAccess */
#define MK_SC_TerminateApplication		19	/* MK_SysTerminateApplication */
#define MK_SC_EnableInterruptSource		20	/* MK_SysEnableInterruptSource */
#define MK_SC_DisableInterruptSource	21	/* MK_SysDisableInterruptSource */
#define MK_SC_AddOnControl				22	/* MK_SysAddOnControl */
#define MK_SC_AsyncActivateTask			23	/* MK_SysAsyncActivateTask */
#define MK_SC_AsyncSetEvent				24	/* MK_SysAsyncSetEvent */
#define MK_SC_AsyncCallQmOs				25	/* MK_SysAsyncCallQmOs */
#define MK_SC_StartCore					26	/* MK_SysStartCore */
#define MK_SC_ShutdownAllCores			27	/* MK_SysShutdownAllCores */
#define MK_SC_SstStartCounter			28	/* MK_SysSstStartCounter */
#define MK_SC_SstAdvanceCounter			29	/* MK_SysSstAdvanceCounter */
#define MK_SC_SstStopCounter			30	/* MK_SysSstStopCounter */
#define MK_SC_GetAppModeVoteOfCore		31	/* MK_SysGetAppModeVoteOfCore */

#define MK_NSYSCALL						32	/* Number of direct microkernel system calls */

#endif
/* Editor settings; DO NOT DELETE
 * vi:set ts=4:
*/
