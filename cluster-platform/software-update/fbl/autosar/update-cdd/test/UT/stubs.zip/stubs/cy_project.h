#include "Std_Types.h"

void Cy_FlashInit(uint8 var);

Std_ReturnType FblFlashDrv_Erase(uint32 address, uint32 size);

//Std_ReturnType FblFlashDrv_Write(uint32 address, uint32 * size, uint8 * buffer);

uint8 FblFlashDrv_Write(uint32 addr, uint32 *pLen,  const uint8 *pBuffer);